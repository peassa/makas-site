// Makas — Premiere Pro ExtendScript köprüsü
// ExtendScript ES3'tür: let/const, ok fonksiyonları, şablon dizgileri, Array.indexOf ve JSON yoktur.
// Her fonksiyon JSON metni döndürür; hata durumunda { "error": "…" }.

var Makas = (function () {
  var TICKS = 254016000000;

  // --- JSON ---
  function esc(s) {
    var out = '';
    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i);
      var code = s.charCodeAt(i);
      if (c === '"') out += '\\"';
      else if (c === '\\') out += '\\\\';
      else if (c === '\n') out += '\\n';
      else if (c === '\r') out += '\\r';
      else if (c === '\t') out += '\\t';
      else if (code < 32) out += '\\u' + ('0000' + code.toString(16)).slice(-4);
      else out += c;
    }
    return out;
  }

  function toJSON(v) {
    if (v === null || v === undefined) return 'null';
    var t = typeof v;
    if (t === 'number') return isFinite(v) ? String(v) : 'null';
    if (t === 'boolean') return v ? 'true' : 'false';
    if (t === 'string') return '"' + esc(v) + '"';
    if (v instanceof Array) {
      var a = [];
      for (var i = 0; i < v.length; i++) a.push(toJSON(v[i]));
      return '[' + a.join(',') + ']';
    }
    var parts = [];
    for (var k in v) {
      if (v.hasOwnProperty(k) && typeof v[k] !== 'function') parts.push('"' + esc(k) + '":' + toJSON(v[k]));
    }
    return '{' + parts.join(',') + '}';
  }

  function ok(o) {
    return toJSON(o);
  }

  function fail(msg) {
    return toJSON({ error: String(msg) });
  }

  function guard(fn) {
    return function () {
      try {
        return fn.apply(null, arguments);
      } catch (e) {
        return fail((e && e.message) || String(e));
      }
    };
  }

  // --- Yardımcılar ---
  function round(n) {
    return Math.round(n * 100) / 100;
  }

  function secs(t) {
    return t ? Number(t.seconds) : 0;
  }

  function activeSeq() {
    if (!app.project) throw new Error('Açık proje yok');
    var s = app.project.activeSequence;
    if (!s) throw new Error('Etkin sekans yok. Zaman çizelgesinde bir sekans açın.');
    return s;
  }

  function normPath(p) {
    return String(p || '').replace(/\\/g, '/').toLowerCase();
  }

  function findItemByPath(item, target) {
    if (!item || !item.children) return null;
    for (var i = 0; i < item.children.numItems; i++) {
      var c = item.children[i];
      if (!c) continue;
      if (c.type === ProjectItemType.BIN) {
        var found = findItemByPath(c, target);
        if (found) return found;
      } else {
        var mp = '';
        try {
          mp = c.getMediaPath();
        } catch (e) {
          mp = '';
        }
        if (mp && normPath(mp) === target) return c;
      }
    }
    return null;
  }

  function importAndFind(path) {
    var target = normPath(path);
    var existing = findItemByPath(app.project.rootItem, target);
    if (existing) return existing;
    var bin = app.project.getInsertionBin();
    var before = bin ? bin.children.numItems : 0;
    app.project.importFiles([path], true, bin, false);
    var item = findItemByPath(app.project.rootItem, target);
    if (!item && bin && bin.children.numItems > before) item = bin.children[bin.children.numItems - 1];
    if (!item) throw new Error('Dosya projeye eklenemedi: ' + path);
    return item;
  }

  function itemDuration(item) {
    try {
      var d = secs(item.getOutPoint()) - secs(item.getInPoint());
      if (d > 0) return d;
    } catch (e) {}
    return 5;
  }

  function trackBusy(track, start, end) {
    for (var j = 0; j < track.clips.numItems; j++) {
      var c = track.clips[j];
      if (secs(c.start) < end && secs(c.end) > start) return true;
    }
    return false;
  }

  /** [start, end] aralığında boş olan ilk parça; yoksa yeni parça eklenir. */
  function freeTrack(seq, kind, start, end, minIndex) {
    var tracks = kind === 'audio' ? seq.audioTracks : seq.videoTracks;
    for (var i = minIndex; i < tracks.numTracks; i++) {
      if (!trackBusy(tracks[i], start, end)) return i;
    }
    addTrack(seq, kind);
    tracks = kind === 'audio' ? seq.audioTracks : seq.videoTracks;
    return tracks.numTracks - 1;
  }

  function addTrack(seq, kind) {
    var before = kind === 'audio' ? seq.audioTracks.numTracks : seq.videoTracks.numTracks;
    app.enableQE();
    var q = qe.project.getActiveSequence();
    // addTracks(video, videoSonrası, ses, sesTürü, sesSonrası, submix, submixTürü, submixSonrası)
    if (kind === 'audio') q.addTracks(0, 0, 1, 1, before, 0, 0, 0);
    else q.addTracks(1, before, 0);
    var after = kind === 'audio' ? seq.audioTracks.numTracks : seq.videoTracks.numTracks;
    if (after <= before) throw new Error('Yeni parça eklenemedi; lütfen boş bir parça ekleyip tekrar deneyin.');
  }

  // --- Sürükleyip bırakılan geçişi kesime oturtma ---
  function isMakasClip(c) {
    return /Makas Gecis/.test(String(c.name || ''));
  }

  function clipMediaPath(c) {
    try {
      return c.projectItem ? normPath(c.projectItem.getMediaPath()) : '';
    } catch (e) {
      return '';
    }
  }

  /** Sekansta bu dosyadan gelen klipler (video ve ses parçalarında). */
  function clipsOfFile(s, file) {
    var target = normPath(file);
    var out = [];
    var groups = [['video', s.videoTracks], ['audio', s.audioTracks]];
    for (var g = 0; g < groups.length; g++) {
      var tracks = groups[g][1];
      for (var i = 0; i < tracks.numTracks; i++) {
        var tr = tracks[i];
        for (var j = 0; j < tr.clips.numItems; j++) {
          var c = tr.clips[j];
          if (!isMakasClip(c) || clipMediaPath(c) !== target) continue;
          out.push({ kind: groups[g][0], track: i, clip: c, start: round(secs(c.start)) });
        }
      }
    }
    return out;
  }

  function dropKey(m) {
    return m.kind + ':' + m.track + ':' + m.start;
  }

  function inList(list, v) {
    for (var i = 0; i < (list ? list.length : 0); i++) if (list[i] === v) return true;
    return false;
  }

  function trackInfo(tracks, maxClips) {
    var out = [];
    for (var i = 0; i < tracks.numTracks; i++) {
      var tr = tracks[i];
      var n = tr.clips.numItems;
      var clips = [];
      for (var j = 0; j < n && j < maxClips; j++) {
        var c = tr.clips[j];
        clips.push({ name: c.name, start: round(secs(c.start)), end: round(secs(c.end)), enabled: !c.disabled });
      }
      out.push({ index: i + 1, name: tr.name, items: n, clips: clips });
    }
    return out;
  }

  // --- Dışa açık işlevler ---
  return {
    ping: guard(function () {
      return ok({ ok: true, app: app.name, version: app.version });
    }),

    getSequence: guard(function () {
      if (!app.project || !app.project.activeSequence) return ok({ ok: false });
      var s = app.project.activeSequence;
      var tpf = Number(s.timebase);
      var dur = Number(s.end) / TICKS;
      var inOut = null;
      try {
        var ip = s.getInPointAsTime ? secs(s.getInPointAsTime()) : Number(s.getInPoint());
        var op = s.getOutPointAsTime ? secs(s.getOutPointAsTime()) : Number(s.getOutPoint());
        // İşaret konmamışsa Premiere sürüme göre sekansın başını/sonunu ya da eksi bir değer döndürür
        if (!(ip > 0)) ip = 0;
        if (!(op > 0) || op > dur) op = dur;
        if (op > ip && (ip > 0.01 || op < dur - 0.05)) inOut = { start: round(ip), end: round(op) };
      } catch (e) {
        inOut = null;
      }
      return ok({
        ok: true,
        id: s.sequenceID,
        name: s.name,
        duration: round(Number(s.end) / TICKS),
        fps: tpf ? round(TICKS / tpf) : 0,
        width: s.frameSizeHorizontal,
        height: s.frameSizeVertical,
        playhead: round(secs(s.getPlayerPosition())),
        video: trackInfo(s.videoTracks, 60),
        audio: trackInfo(s.audioTracks, 60),
        inOut: inOut
      });
    }),

    // Kesim yerleri: ilk dört video parçasındaki klip başlangıçları (sn). getSequence yalnızca ilk 60 klibi verir;
    // geçişlerin kesime oturması ve "tüm kesimlere ekle" için tam liste gerekir.
    getCuts: guard(function () {
      var s = activeSeq();
      var tracks = [];
      for (var i = 0; i < s.videoTracks.numTracks && i < 4; i++) {
        var tr = s.videoTracks[i];
        var starts = [];
        for (var j = 0; j < tr.clips.numItems && j < 3000; j++) starts.push(round(secs(tr.clips[j].start)));
        tracks.push(starts);
      }
      return ok({ tracks: tracks });
    }),

    // Sürükleme başlarken: bu dosyadan sekansta zaten duran klipler (sonradan bırakılan ayırt edilsin)
    beginDrop: guard(function (file) {
      var ms = clipsOfFile(activeSeq(), file);
      var keys = [];
      for (var i = 0; i < ms.length; i++) keys.push(dropKey(ms[i]));
      return ok({ known: keys });
    }),

    // Bırakılan geçişi bulur ve en yakın kesime oturtur: bırakılan klip kaldırılır, aynı geçiş "Ekle"nin
    // kullandığı yolla tam kesime (görüntü boş bir üst parçaya, ses boş bir ses parçasına) konur.
    settleDrop: guard(function (file, videoPath, audioPath, mid, known, reach) {
      var s = activeSeq();
      var all = clipsOfFile(s, file);
      var fresh = [];
      var video = null;
      for (var i = 0; i < all.length; i++) {
        if (inList(known, dropKey(all[i]))) continue;
        fresh.push(all[i]);
        if (!video && all[i].kind === 'video') video = all[i];
      }
      if (!video) return ok({ state: 'waiting' });
      var half = Number(mid) > 0 ? Number(mid) : 0;
      var center = video.start + half;
      var cut = null;
      for (var v = 0; v < s.videoTracks.numTracks && v < 4; v++) {
        var tr = s.videoTracks[v];
        for (var j = 0; j < tr.clips.numItems && j < 3000; j++) {
          var c = tr.clips[j];
          if (isMakasClip(c)) continue;
          var st = secs(c.start);
          if (st > 0.05 && (cut === null || Math.abs(st - center) < Math.abs(cut - center))) cut = st;
        }
      }
      if (cut === null || Math.abs(cut - center) > (Number(reach) > 0 ? Number(reach) : 2.5)) return ok({ state: 'kept', reason: 'no-cut', time: video.start });
      try {
        for (var k = 0; k < fresh.length; k++) fresh[k].clip.remove(false, false);
      } catch (e) {
        return ok({ state: 'kept', reason: 'no-delete', time: video.start });
      }
      var at = Math.max(0, cut - half);
      var vItem = importAndFind(videoPath || file);
      var vIdx = freeTrack(s, 'video', at, at + itemDuration(vItem), 1);
      s.videoTracks[vIdx].overwriteClip(vItem, at);
      if (audioPath) {
        var aItem = importAndFind(audioPath);
        var aIdx = freeTrack(s, 'audio', at, at + itemDuration(aItem), 0);
        s.audioTracks[aIdx].overwriteClip(aItem, at);
      }
      return ok({ state: 'placed', time: round(cut), track: vIdx + 1 });
    }),

    exportXml: guard(function (path) {
      var s = activeSeq();
      s.exportAsFinalCutProXML(path, 1);
      if (!new File(path).exists) throw new Error('Sekans XML olarak dışa aktarılamadı');
      return ok({ xmlPath: path, name: s.name });
    }),

    importXml: guard(function (path, name) {
      var before = {};
      var i;
      for (i = 0; i < app.project.sequences.numSequences; i++) before[app.project.sequences[i].sequenceID] = true;
      app.project.importFiles([path], true, app.project.getInsertionBin(), false);
      var found = null;
      for (i = 0; i < app.project.sequences.numSequences; i++) {
        var sq = app.project.sequences[i];
        if (!before[sq.sequenceID] && (!found || sq.name === name)) found = sq;
      }
      if (!found) throw new Error('Yeni sekans içe aktarılamadı');
      app.project.openSequence(found.sequenceID);
      return ok({ name: found.name, id: found.sequenceID });
    }),

    revertSequence: guard(function (created, original) {
      var c = null;
      var o = null;
      for (var i = 0; i < app.project.sequences.numSequences; i++) {
        var sq = app.project.sequences[i];
        if (sq.name === created) c = sq;
        else if (sq.name === original) o = sq;
      }
      if (!c) throw new Error('"' + created + '" sekansı bulunamadı');
      if (o) app.project.openSequence(o.sequenceID);
      app.project.deleteSequence(c);
      return ok({ deleted: true, restored: Boolean(o) });
    }),

    addCaptions: guard(function (srtPath) {
      var s = activeSeq();
      var item = importAndFind(srtPath);
      var placed = false;
      try {
        placed = s.createCaptionTrack(item, 0, Sequence.CAPTION_FORMAT_SUBTITLE) !== false;
      } catch (e) {
        placed = false;
      }
      return ok({ placed: placed });
    }),

    placeOverlay: guard(function (path, at) {
      var s = activeSeq();
      var item = importAndFind(path);
      var dur = itemDuration(item);
      var t = Number(at) > 0 ? Number(at) : 0;
      var idx = freeTrack(s, 'video', t, t + dur, 1);
      s.videoTracks[idx].overwriteClip(item, t);
      return ok({ track: idx + 1, time: round(t) });
    }),

    // when: sekansın başından saniye; verilmezse oynatma kafası
    insertClip: guard(function (path, kind, when) {
      var s = activeSeq();
      var item = importAndFind(path);
      var at = when !== null && when !== undefined && Number(when) >= 0 ? Number(when) : secs(s.getPlayerPosition());
      var dur = itemDuration(item);
      var audio = kind === 'audio';
      var idx = freeTrack(s, audio ? 'audio' : 'video', at, at + dur, audio ? 0 : 1);
      var track = audio ? s.audioTracks[idx] : s.videoTracks[idx];
      track.overwriteClip(item, at);
      return ok({ track: idx + 1, time: round(at) });
    }),

    setPlayhead: guard(function (seconds) {
      var s = activeSeq();
      s.setPlayerPosition(String(Math.round(Number(seconds) * TICKS)));
      return ok({ ok: true });
    })
  };
})();
