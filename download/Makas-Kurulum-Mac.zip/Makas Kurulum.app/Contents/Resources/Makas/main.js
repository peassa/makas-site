// Makas — DaVinci Resolve Workflow Integration eklentisi (Electron ana süreci).
//
// Resolve, Çalışma Alanı > Workflow Integrations > Makas seçildiğinde bu dosyayı çalıştırır.
// Motor (altyazı, kesim, SFX Lab) bu süreçte çalışır; arayüz preload köprüsü üzerinden çağırır.
// Resolve API'si WorkflowIntegration.node modülüyle kullanılır (Resolve'un örnek eklentisinden
// kopyalanır; kurulum betiği bunu yapar).

'use strict';

const { app, BrowserWindow, dialog, ipcMain, nativeImage, shell } = require('electron');
const fs = require('fs');
const path = require('path');
const { createResolveHost } = require('./resolve-host.js');

const PLUGIN_ID = 'com.makas.resolve';
const UI_DIR = path.join(__dirname, 'ui');

let win = null;
let service = null;
let resolveObj = null;
let wiModule;

function loadWorkflowIntegration() {
  if (wiModule !== undefined) return wiModule;
  try {
    // MAKAS_WI_MODULE: Resolve olmadan denemek için sahte modül (geliştirme)
    wiModule = require(process.env.MAKAS_WI_MODULE || './WorkflowIntegration.node');
  } catch (e) {
    console.error('[Makas] WorkflowIntegration.node yüklenemedi:', e.message);
    wiModule = null;
  }
  return wiModule;
}

async function getResolve() {
  if (resolveObj) return resolveObj;
  const wi = loadWorkflowIntegration();
  if (!wi) throw new Error('Resolve bağlantı modülü (WorkflowIntegration.node) bulunamadı. Kurulumu yeniden çalıştırın.');
  // Yeni sürümlerde Promise tabanlı işlevler, eskilerde eşzamanlı olanlar var
  const ok = wi.InitializePromise ? await wi.InitializePromise(PLUGIN_ID) : await wi.Initialize(PLUGIN_ID);
  if (!ok) throw new Error('DaVinci Resolve bağlantıyı kabul etmedi. Eklentiler yalnızca DaVinci Resolve Studio\'da çalışır.');
  resolveObj = wi.GetResolvePromise ? await wi.GetResolvePromise() : await wi.GetResolve();
  if (!resolveObj) throw new Error('DaVinci Resolve\'a bağlanılamadı');
  return resolveObj;
}

function startEngine() {
  const { createService } = require('./engine/makas-engine.cjs');
  return createService({ fontsDir: path.join(UI_DIR, 'fonts'), installDir: __dirname, host: 'resolve' });
}

const errorText = (e) => String((e && e.message) || e || 'Bilinmeyen hata');

/** Tanılama günlüğü: <veri klasörü>/makas-resolve.log (1 MB'ı geçince sıfırlanır). */
function makeLogger(dataDir) {
  const file = path.join(dataDir, 'makas-resolve.log');
  return (msg) => {
    try {
      if (fs.existsSync(file) && fs.statSync(file).size > 1e6) fs.writeFileSync(file, '');
      fs.appendFileSync(file, `${new Date().toISOString()} ${msg}\n`);
    } catch {
      /* günlük yazılamazsa önemli değil */
    }
  };
}

function createWindow() {
  win = new BrowserWindow({
    width: 480,
    height: 860,
    minWidth: 360,
    minHeight: 480,
    title: 'Makas',
    backgroundColor: '#0c0c11',
    // Resolve'un üzerinde yüzen bir panel gibi davranır; üst çubuktaki raptiyeyle kapatılabilir
    alwaysOnTop: true,
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });
  win.setAlwaysOnTop(true, 'floating');
  win.once('ready-to-show', () => win.show());
  // Arayüzdeki bağlantılar Makas penceresinde değil, tarayıcıda açılır
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://')) {
      e.preventDefault();
      if (/^https?:\/\//.test(url)) shell.openExternal(url);
    }
  });
  win.on('closed', () => {
    win = null;
  });
  win.loadFile(path.join(UI_DIR, 'index.html'));
}

const FALLBACK_ICON = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

/** Sürüklenebilecek dosya: Makas'ın veri klasöründe duran, var olan bir video ya da ses. */
function draggable(file) {
  try {
    const abs = path.resolve(String(file));
    const root = path.resolve(service.config.dataDir) + path.sep;
    const out = path.resolve(service.config.outputDir) + path.sep;
    if (!abs.startsWith(root) && !abs.startsWith(out)) return null;
    if (!/\.(mov|mp4|wav|mp3|png|jpg)$/i.test(abs) || !fs.statSync(abs).isFile()) return null;
    return abs;
  } catch {
    return null;
  }
}

function registerIpc(host, log = () => {}) {
  // Sonuç arayüze döner: sürükleme başlatılamazsa kullanıcı nedenini görür (sessizce hiçbir şey olmaması yerine)
  ipcMain.handle('makas:drag', (e, file) => {
    const abs = draggable(file);
    if (!abs) {
      log(`Sürükleme reddedildi: ${file}`);
      return { __error: 'Dosya bulunamadı; geçişi yeniden seçip tekrar deneyin.' };
    }
    try {
      let icon = nativeImage.createFromPath(path.join(__dirname, 'surukle.png'));
      // macOS boş simgeyle sürüklemeyi reddeder: simge yüklenemezse tek noktalık yedek simge kullanılır
      if (icon.isEmpty()) icon = nativeImage.createFromDataURL(FALLBACK_ICON);
      else icon = icon.resize({ width: 48, height: 48 });
      e.sender.startDrag({ file: abs, icon });
      return { ok: true };
    } catch (err) {
      log(`HATA sürükleme: ${errorText(err)}`);
      return { __error: errorText(err) };
    }
  });
  ipcMain.handle('makas:call', async (_e, method, params) => {
    try {
      return await service.call(String(method), params ?? {});
    } catch (e) {
      log(`HATA ${method}: ${errorText(e)}`);
      return { __error: errorText(e) };
    }
  });
  ipcMain.handle('makas:host', async (_e, method, params) => {
    const fn = host[method];
    if (typeof fn !== 'function') return { __error: `Bilinmeyen işlem: ${method}` };
    try {
      const r = await fn(params ?? {});
      return r === undefined ? null : r;
    } catch (e) {
      log(`HATA ${method}: ${errorText(e)}`);
      return { __error: errorText(e) };
    }
  });
}

const uiActions = {
  async pickFiles({ title = 'Dosya seç', extensions, multiple = false }) {
    const filters = extensions?.length ? [{ name: 'Dosyalar', extensions: extensions.map((x) => String(x).replace(/^\./, '')) }] : [];
    const r = await dialog.showOpenDialog(win, { title, filters, properties: ['openFile', ...(multiple ? ['multiSelections'] : [])] });
    return r.canceled ? [] : r.filePaths;
  },
  async pickFolder({ title = 'Klasör seç' }) {
    const r = await dialog.showOpenDialog(win, { title, properties: ['openDirectory', 'createDirectory'] });
    return r.canceled ? null : r.filePaths[0] ?? null;
  },
  openUrl(url) {
    if (/^https?:\/\//.test(String(url))) shell.openExternal(String(url));
  },
  setPinned(pinned) {
    win?.setAlwaysOnTop(pinned, 'floating');
    return { pinned };
  },
  quit() {
    // Yanıt arayüze ulaşsın diye kısa bir gecikmeyle kapan
    setTimeout(() => app.quit(), 300);
    return { quitting: true };
  },
};

app.whenReady().then(async () => {
  try {
    service = startEngine();
  } catch (e) {
    dialog.showErrorBox('Makas', `Motor başlatılamadı:\n${errorText(e)}`);
    app.quit();
    return;
  }
  const st = await service.call('app.status').catch(() => null);
  const dataDir = st?.dataDir ?? app.getPath('userData');
  const cacheDir = path.join(dataDir, 'cache');
  const log = makeLogger(dataDir);
  log(`Makas açıldı (${st?.version ?? '?'})`);
  registerIpc(
    createResolveHost({
      getResolve,
      cacheDir,
      ui: uiActions,
      log,
      buildXml: (desc) => service.call('source.fromClips', desc),
      planXml: (xmlPath) => service.call('source.timelinePlan', { xmlPath }),
    }),
    log,
  );
  createWindow();
  // Resolve'a bağlanmayı erkenden dene; hata olursa arayüz sekans bilgisinde gösterir
  getResolve().catch((e) => console.error('[Makas]', errorText(e)));
});

app.on('window-all-closed', () => {
  try {
    wiModule?.CleanUp?.();
  } catch {
    /* yok sayılır */
  }
  app.quit();
});
