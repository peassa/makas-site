// Makas — Resolve penceresi ile ana süreç arasındaki köprü.
// Resolve 19.0.2'den beri eklentiler sandbox + contextIsolation ile çalışır; arayüz Node'a
// erişemez, yalnızca buradaki iki işlevi görür.

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('makas', {
  /** Motor işlevleri (altyazı, kesim, SFX Lab…) */
  call: (method, params) => ipcRenderer.invoke('makas:call', method, params ?? {}),
  /** Resolve zaman çizelgesi işlemleri */
  host: (method, params) => ipcRenderer.invoke('makas:host', method, params ?? {}),
  /** Makas'ın hazırladığı bir dosyayı pencereden dışarı (zaman çizelgesine) sürüklemeyi başlatır */
  drag: (file) => ipcRenderer.invoke('makas:drag', String(file ?? '')),
});
