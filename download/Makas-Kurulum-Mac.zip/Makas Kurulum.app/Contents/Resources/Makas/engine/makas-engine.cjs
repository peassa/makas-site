var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// engine/service.js
var service_exports = {};
__export(service_exports, {
  createService: () => createService,
  listDirectory: () => listDirectory
});
module.exports = __toCommonJS(service_exports);

// <define:__MAKAS_LICENSE__>
var define_MAKAS_LICENSE_default = { url: "https://makas-lisans.thepeassa.workers.dev", publicKey: "kMycJkas/8UcBSOCc5/4WUMrC0sn89AhYc3lbCu0+nE=", site: "https://makasai.net" };

// engine/service.js
var import_node_fs15 = require("fs");
var import_node_path14 = require("path");
var import_node_os8 = require("os");

// engine/config.js
var import_node_crypto = require("crypto");
var import_node_fs = require("fs");
var import_node_os = require("os");
var import_node_path = require("path");
var APP_NAME = "Makas";
var APP_VERSION = "0.1.0";
var DEFAULT_PORT = 47820;
function defaultDataDir() {
  if (process.env.MAKAS_HOME) return process.env.MAKAS_HOME;
  const home = (0, import_node_os.homedir)();
  switch ((0, import_node_os.platform)()) {
    case "darwin":
      return (0, import_node_path.join)(home, "Library", "Application Support", APP_NAME);
    case "win32":
      return (0, import_node_path.join)(process.env.APPDATA ?? (0, import_node_path.join)(home, "AppData", "Roaming"), APP_NAME);
    default:
      return (0, import_node_path.join)(process.env.XDG_CONFIG_HOME ?? (0, import_node_path.join)(home, ".config"), APP_NAME.toLowerCase());
  }
}
var DEFAULT_SETTINGS = {
  port: DEFAULT_PORT,
  ffmpegPath: "",
  ffprobePath: "",
  whisperPath: "",
  model: "large-v3-turbo-q5_0",
  translateModel: "medium-q5_0",
  language: "tr",
  threads: 0,
  // 0 = otomatik
  useDtw: true,
  prompt: "Merhaba, bug\xFCn sizlere anlataca\u011F\u0131m.",
  outputDir: "",
  libraryFolders: [],
  freesoundToken: "",
  favorites: [],
  // SFX Lab: yöneticinin bulut kütüphanesi (herkese açık katalog adresi)
  sfxCatalogUrl: "",
  sfxFavorites: [],
  // Yalnızca yönetici bilgisayarında doldurulur (Cloudflare R2 / S3)
  sfxAdmin: null,
  // Geliştirici modu: yönetici ayarlarını (SFX Lab yükleme, güncelleme anahtarı) gösterir.
  // null = otomatik (SFX Lab yöneticisi tanımlıysa açık)
  devMode: null,
  // Arayüz tercihleri (son kullanılan altyazı stili vb.)
  ui: {},
  // Uygulama içi güncelleme: GitHub erişim anahtarı (salt okunur), depo ve dal
  update: { token: "", repo: "", branch: "", lastCheck: null }
};
var Config = class {
  constructor(dataDir = defaultDataDir()) {
    this.dataDir = dataDir;
    this.dirs = {
      models: (0, import_node_path.join)(dataDir, "models"),
      cache: (0, import_node_path.join)(dataDir, "cache"),
      transcripts: (0, import_node_path.join)(dataDir, "transcripts"),
      output: (0, import_node_path.join)(dataDir, "output"),
      freesound: (0, import_node_path.join)(dataDir, "library", "Freesound"),
      tools: (0, import_node_path.join)(dataDir, "tools")
    };
    for (const d of [dataDir, ...Object.values(this.dirs)]) (0, import_node_fs.mkdirSync)(d, { recursive: true });
    this.settingsPath = (0, import_node_path.join)(dataDir, "settings.json");
    this.tokenPath = (0, import_node_path.join)(dataDir, "token");
    this.settings = { ...DEFAULT_SETTINGS, ...this.#readJson(this.settingsPath, {}) };
    this.token = this.#ensureToken();
  }
  #readJson(path, fallback) {
    try {
      return JSON.parse((0, import_node_fs.readFileSync)(path, "utf8"));
    } catch {
      return fallback;
    }
  }
  #ensureToken() {
    if ((0, import_node_fs.existsSync)(this.tokenPath)) {
      const t = (0, import_node_fs.readFileSync)(this.tokenPath, "utf8").trim();
      if (/^[0-9a-f]{32,}$/.test(t)) return t;
    }
    const token = (0, import_node_crypto.randomBytes)(24).toString("hex");
    (0, import_node_fs.writeFileSync)(this.tokenPath, token, { mode: 384 });
    try {
      (0, import_node_fs.chmodSync)(this.tokenPath, 384);
    } catch {
    }
    return token;
  }
  get outputDir() {
    return this.settings.outputDir || this.dirs.output;
  }
  update(patch) {
    const allowed = Object.keys(DEFAULT_SETTINGS);
    for (const [k, v] of Object.entries(patch ?? {})) {
      if (allowed.includes(k)) this.settings[k] = v;
    }
    this.save();
    return this.settings;
  }
  save() {
    (0, import_node_fs.writeFileSync)(this.settingsPath, JSON.stringify(this.settings, null, 2));
  }
  /** Arayüze gönderilen ayarlar (gizli anahtar maskelenir). */
  publicSettings() {
    const s = { ...this.settings };
    s.freesoundToken = s.freesoundToken ? "\u2022\u2022\u2022\u2022" + s.freesoundToken.slice(-4) : "";
    if (s.sfxAdmin) {
      const secret = s.sfxAdmin.secretAccessKey ?? "";
      s.sfxAdmin = { ...s.sfxAdmin, secretAccessKey: secret ? "\u2022\u2022\u2022\u2022" + secret.slice(-4) : "" };
    }
    if (s.update) s.update = { ...s.update, token: s.update.token ? "\u2022\u2022\u2022\u2022" + s.update.token.slice(-4) : "" };
    s.dataDir = this.dataDir;
    s.effectiveOutputDir = this.outputDir;
    return s;
  }
};

// engine/tools.js
var import_node_fs2 = require("fs");
var import_node_path2 = require("path");
var import_node_os2 = require("os");

// engine/proc.js
var import_node_child_process = require("child_process");
var ProcessError = class extends Error {
  constructor(message, { code, stderr } = {}) {
    super(message);
    this.code = code;
    this.stderr = stderr;
  }
};
function run(cmd, args, opts = {}) {
  return new Promise((resolve3, reject) => {
    var _a;
    const child2 = (0, import_node_child_process.spawn)(cmd, args, {
      cwd: opts.cwd,
      env: opts.env ? { ...process.env, ...opts.env } : process.env,
      windowsHide: true
    });
    const stdout = [];
    let stderr = "";
    let partial = "";
    const onAbort = () => child2.kill("SIGKILL");
    (_a = opts.signal) == null ? void 0 : _a.addEventListener("abort", onAbort, { once: true });
    child2.stdout.on("data", (chunk) => {
      if (opts.onStdout) opts.onStdout(chunk);
      else stdout.push(chunk);
    });
    child2.stderr.on("data", (chunk) => {
      const text = chunk.toString("utf8");
      stderr = (stderr + text).slice(-2e4);
      if (opts.onStderrLine) {
        partial += text;
        const lines = partial.split(/\r?\n|\r/);
        partial = lines.pop();
        for (const l of lines) opts.onStderrLine(l);
      }
    });
    child2.on("error", (err) => {
      var _a2;
      (_a2 = opts.signal) == null ? void 0 : _a2.removeEventListener("abort", onAbort);
      reject(new ProcessError(`${cmd} \xE7al\u0131\u015Ft\u0131r\u0131lamad\u0131: ${err.message}`, { code: err.code }));
    });
    child2.on("close", (code) => {
      var _a2, _b;
      (_a2 = opts.signal) == null ? void 0 : _a2.removeEventListener("abort", onAbort);
      if ((_b = opts.signal) == null ? void 0 : _b.aborted) return reject(new ProcessError("\u0130\u015Flem iptal edildi", { code: "ABORTED" }));
      const out = Buffer.concat(stdout);
      if (code === 0) resolve3({ code, stdout: out, stderr });
      else reject(new ProcessError(`${cmd} hata ile bitti (kod ${code}): ${stderr.trim().split("\n").slice(-3).join(" | ")}`, { code, stderr }));
    });
  });
}

// engine/tools.js
var EXE = (0, import_node_os2.platform)() === "win32" ? ".exe" : "";
var FFMPEG_FULL_DIRS = (0, import_node_os2.platform)() === "darwin" ? ["/opt/homebrew/opt/ffmpeg-full/bin", "/usr/local/opt/ffmpeg-full/bin"] : [];
var EXTRA_DIRS = (0, import_node_os2.platform)() === "darwin" ? [...FFMPEG_FULL_DIRS, "/opt/homebrew/bin", "/usr/local/bin", "/opt/local/bin"] : (0, import_node_os2.platform)() === "win32" ? ["C:\\ffmpeg\\bin", "C:\\Program Files\\ffmpeg\\bin"] : ["/usr/local/bin", "/usr/bin"];
var CANDIDATES = {
  ffmpeg: ["ffmpeg"],
  ffprobe: ["ffprobe"],
  whisper: ["whisper-cli", "whisper-cpp", "whisper"]
};
function searchPath(names, extraDirs) {
  const dirs = [...(process.env.PATH ?? "").split(import_node_path2.delimiter), ...extraDirs].filter(Boolean);
  for (const name of names) {
    for (const dir of dirs) {
      const p = (0, import_node_path2.join)(dir, name + EXE);
      if ((0, import_node_fs2.existsSync)(p)) return p;
    }
  }
  return null;
}
var Tools = class {
  constructor(config) {
    this.config = config;
    this.cache = {};
    this.filterCache = /* @__PURE__ */ new Map();
    this.diskPath = config.dataDir ? (0, import_node_path2.join)(config.dataDir, "tools-cache.json") : null;
    this.disk = this.#loadDisk();
  }
  /** ffmpeg'in derlendiği filtreler (ör. altyazı için "ass"). */
  #loadDisk() {
    try {
      return this.diskPath && (0, import_node_fs2.existsSync)(this.diskPath) ? JSON.parse((0, import_node_fs2.readFileSync)(this.diskPath, "utf8")) : {};
    } catch {
      return {};
    }
  }
  #saveDisk() {
    try {
      if (this.diskPath) (0, import_node_fs2.writeFileSync)(this.diskPath, JSON.stringify(this.disk));
    } catch {
    }
  }
  /** Dosyanın kimliği: yol + boyut + değişme zamanı (güncellenince önbellek geçersiz olur). */
  #sig(path) {
    try {
      const st = (0, import_node_fs2.statSync)(path);
      return `${path}|${st.size}|${Math.round(st.mtimeMs)}`;
    } catch {
      return null;
    }
  }
  /** Önbellekli program çıktısı: aynı dosya için yalnızca bir kez çalıştırılır. */
  async #cached(kind, path, compute) {
    const sig = this.#sig(path);
    const key = `${kind}:${path}`;
    const hit = this.disk[key];
    if (sig && hit && hit.sig === sig) return hit.value;
    const value = await compute();
    if (sig) {
      this.disk[key] = { sig, value };
      this.#saveDisk();
    }
    return value;
  }
  async ffmpegFilters(path) {
    if (!this.filterCache.has(path)) {
      this.filterCache.set(
        path,
        this.#cached(
          "filters",
          path,
          () => run(path, ["-hide_banner", "-filters"]).then((r) => [...(r.stdout.toString() + r.stderr).matchAll(/^\s*[TSC.|]{2,3}\s+(\S+)\s/gm)].map((m2) => m2[1])).catch(() => [])
        ).then((list) => new Set(list))
      );
    }
    return this.filterCache.get(path);
  }
  /**
   * Animasyonlu altyazı için libass'lı (ass filtresi olan) ffmpeg. Önce ayarlardaki/bulunan
   * ffmpeg, sonra Homebrew ffmpeg-full ve gömülü araçlar denenir.
   */
  async ffmpegWithSubtitles() {
    const candidates = [this.resolve("ffmpeg"), ...FFMPEG_FULL_DIRS.map((d) => (0, import_node_path2.join)(d, "ffmpeg")), searchPath(["ffmpeg"], [this.config.dirs.tools, (0, import_node_path2.join)(this.config.dirs.tools, "bin")])];
    for (const p of [...new Set(candidates.filter(Boolean))]) {
      if ((0, import_node_fs2.existsSync)(p) && (await this.ffmpegFilters(p)).has("ass")) return p;
    }
    return null;
  }
  /** @param {'ffmpeg'|'ffprobe'|'whisper'} name */
  resolve(name) {
    const configured = this.config.settings[`${name}Path`];
    if (configured && (0, import_node_fs2.existsSync)(configured)) return configured;
    if (this.cache[name] && (0, import_node_fs2.existsSync)(this.cache[name])) return this.cache[name];
    const bundled = searchPath(CANDIDATES[name], [this.config.dirs.tools, (0, import_node_path2.join)(this.config.dirs.tools, "bin")]);
    const found = bundled ?? searchPath(CANDIDATES[name], EXTRA_DIRS);
    this.cache[name] = found;
    return found;
  }
  require(name) {
    const p = this.resolve(name);
    if (!p) {
      const hint = {
        ffmpeg: `ffmpeg kurulu de\u011Fil. macOS: "brew install ffmpeg", Windows: ffmpeg.org adresinden indirip Ayarlar'dan yolunu se\xE7in.`,
        ffprobe: "ffprobe bulunamad\u0131 (ffmpeg ile birlikte gelir).",
        whisper: `whisper.cpp bulunamad\u0131. macOS: "brew install whisper-cpp", Windows: whisper.cpp s\xFCr\xFCm sayfas\u0131ndan whisper-bin-x64.zip indirip Ayarlar'dan whisper-cli.exe yolunu se\xE7in.`
      }[name];
      const err = new Error(hint);
      err.status = 412;
      throw err;
    }
    return p;
  }
  async status() {
    var _a;
    const out = {};
    for (const name of ["ffmpeg", "ffprobe", "whisper"]) {
      const path = this.resolve(name);
      let version = null;
      if (path) {
        try {
          const args = name === "whisper" ? ["--version"] : ["-version"];
          version = await this.#cached("version", path, async () => {
            const r = await run(path, args);
            return (r.stdout.toString() + r.stderr).trim().split("\n")[0].slice(0, 120);
          });
        } catch (e) {
          version = name === "whisper" ? "s\xFCr\xFCm bilinmiyor" : null;
          if (name !== "whisper") out[name] = { path, version, error: e.message };
        }
      }
      out[name] ??= { path, version, ok: Boolean(path) };
      out[name].ok = Boolean(path);
    }
    if ((_a = out.ffmpeg) == null ? void 0 : _a.ok) {
      const sub = await this.ffmpegWithSubtitles();
      out.ffmpeg.subtitles = Boolean(sub);
      out.ffmpeg.subtitlesPath = sub;
    }
    return out;
  }
};

// engine/media.js
var import_node_crypto2 = require("crypto");
var import_node_fs3 = require("fs");
var import_node_path3 = require("path");

// core/ranges.js
var EPS = 1e-9;
function limitToRange(keep, [start, end], duration) {
  const inside = keep.map(([a, b]) => [Math.max(a, start), Math.min(b, end)]).filter(([a, b]) => b > a);
  return normalizeRanges([[0, start], [end, duration], ...inside]);
}
function normalizeRanges(ranges, gap = 0) {
  const sorted = ranges.filter(([s, e]) => e - s > EPS).map(([s, e]) => [s, e]).sort((a, b) => a[0] - b[0]);
  const out = [];
  for (const r of sorted) {
    const last = out[out.length - 1];
    if (last && r[0] <= last[1] + gap + EPS) {
      last[1] = Math.max(last[1], r[1]);
    } else {
      out.push(r);
    }
  }
  return out;
}
function createTimeMapper(keepRanges) {
  const keeps = normalizeRanges(keepRanges);
  const offsets = [];
  let acc = 0;
  for (const [s, e] of keeps) {
    offsets.push(acc);
    acc += e - s;
  }
  function find(t) {
    let lo = 0;
    let hi = keeps.length - 1;
    while (lo <= hi) {
      const mid = lo + hi >> 1;
      const [s, e] = keeps[mid];
      if (t < s - EPS) hi = mid - 1;
      else if (t > e + EPS) lo = mid + 1;
      else return mid;
    }
    return -1;
  }
  return {
    keeps,
    duration: acc,
    map(t) {
      const i = find(t);
      if (i < 0) return null;
      return offsets[i] + Math.min(Math.max(t - keeps[i][0], 0), keeps[i][1] - keeps[i][0]);
    },
    /** Orijinal bir aralığı kesilmiş zaman çizelgesindeki parçalara dönüştürür. */
    mapRange(s, e) {
      const out = [];
      keeps.forEach(([ks, ke], i) => {
        const a = Math.max(s, ks);
        const b = Math.min(e, ke);
        if (b - a > EPS) out.push([offsets[i] + (a - ks), offsets[i] + (b - ks)]);
      });
      return out;
    }
  };
}

// core/audio.js
var SILENCE_DB = -100;
function downsampleEnvelope(env, factor) {
  if (factor <= 1) return env;
  const n = Math.ceil(env.length / factor);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let max = SILENCE_DB;
    for (let j = i * factor; j < Math.min(env.length, (i + 1) * factor); j++) if (env[j] > max) max = env[j];
    out[i] = max;
  }
  return out;
}
function combineEnvelopes(envs) {
  const len = Math.max(0, ...envs.map((e) => e.length));
  const out = new Float32Array(len).fill(SILENCE_DB);
  for (const e of envs) for (let i = 0; i < e.length; i++) if (e[i] > out[i]) out[i] = e[i];
  return out;
}
function percentile(values, p) {
  const arr = Array.from(values).filter((v) => v > SILENCE_DB + 1).sort((a, b) => a - b);
  if (!arr.length) return SILENCE_DB;
  const idx = Math.min(arr.length - 1, Math.max(0, Math.round(p / 100 * (arr.length - 1))));
  return arr[idx];
}
function autoThreshold(env) {
  const floor = percentile(env, 10);
  const speech = percentile(env, 95);
  if (speech <= SILENCE_DB + 1) return { threshold: -45, floor, speech };
  const range = Math.max(0, speech - floor);
  let threshold;
  if (range < 10) {
    threshold = Math.max(speech - 20, -50);
  } else {
    threshold = floor + range * 0.35;
    threshold = Math.min(threshold, speech - 12);
    threshold = Math.max(threshold, floor + 4);
  }
  return { threshold: Math.round(threshold * 10) / 10, floor, speech };
}
function activeRegions(env, { windowSec = 0.01, threshold, minSilence = 0.3, minSpeech = 0.12 } = {}) {
  const regions = [];
  let start = -1;
  for (let i = 0; i <= env.length; i++) {
    const on = i < env.length && env[i] >= threshold;
    if (on && start < 0) start = i;
    if (!on && start >= 0) {
      regions.push([start * windowSec, i * windowSec]);
      start = -1;
    }
  }
  const bridged = normalizeRanges(regions, minSilence);
  return bridged.filter(([s, e]) => e - s >= minSpeech);
}
function detectSilence(env, opts = {}) {
  const windowSec = opts.windowSec ?? 0.01;
  const duration = opts.duration ?? env.length * windowSec;
  const auto = autoThreshold(env);
  const threshold = opts.threshold ?? auto.threshold;
  const minSilence = opts.minSilence ?? 0.5;
  const padBefore = opts.padBefore ?? 0.12;
  const padAfter = opts.padAfter ?? 0.18;
  const minSpeech = opts.minSpeech ?? 0.12;
  const active = activeRegions(env, { windowSec, threshold, minSilence: 0.05, minSpeech });
  const padded = active.map(([s, e]) => [Math.max(0, s - padBefore), Math.min(duration, e + padAfter)]);
  const keep = normalizeRanges(padded, minSilence);
  const silences = [];
  let cursor = 0;
  for (const [s, e] of keep) {
    if (s > cursor) silences.push([cursor, s]);
    cursor = e;
  }
  if (cursor < duration) silences.push([cursor, duration]);
  const removed = silences.reduce((n, [s, e]) => n + (e - s), 0);
  return { keep, silences, threshold, floor: auto.floor, speech: auto.speech, duration, removed };
}

// engine/media.js
var ANALYSIS_RATE = 16e3;
var Media = class {
  constructor(tools, config) {
    this.tools = tools;
    this.config = config;
  }
  async probe(path) {
    var _a;
    if (!(0, import_node_fs3.existsSync)(path)) throw Object.assign(new Error(`Dosya bulunamad\u0131: ${path}`), { status: 404 });
    const ffprobe = this.tools.require("ffprobe");
    const r = await run(ffprobe, ["-v", "error", "-print_format", "json", "-show_streams", "-show_format", path]);
    const info = JSON.parse(r.stdout.toString("utf8"));
    const streams = info.streams ?? [];
    const video = streams.find((s) => {
      var _a2;
      return s.codec_type === "video" && !((_a2 = s.disposition) == null ? void 0 : _a2.attached_pic);
    });
    const audio = streams.find((s) => s.codec_type === "audio");
    const fps = video ? parseRate(video.avg_frame_rate) || parseRate(video.r_frame_rate) : 0;
    return {
      path,
      name: (0, import_node_path3.basename)(path),
      duration: Number(((_a = info.format) == null ? void 0 : _a.duration) ?? (audio == null ? void 0 : audio.duration) ?? (video == null ? void 0 : video.duration) ?? 0),
      hasVideo: Boolean(video),
      width: (video == null ? void 0 : video.width) ?? 0,
      height: (video == null ? void 0 : video.height) ?? 0,
      fps: fps || 25,
      hasAudio: Boolean(audio),
      audioChannels: (audio == null ? void 0 : audio.channels) ?? 0,
      sampleRate: Number((audio == null ? void 0 : audio.sample_rate) ?? 0)
    };
  }
  /**
   * Görüntüdeki hareketin yatay ağırlık merkezi (0 sol – 1 sağ): konuşan kişi (baş, ağız, eller)
   * hareket eder, arka plan durağandır. Belirgin hareket yoksa null.
   */
  async motionCenter(path, { start = 0, duration = 10, width = 64, fps = 4, srcWidth = 1920, srcHeight = 1080, signal } = {}) {
    const ffmpeg = this.tools.require("ffmpeg");
    const height = Math.max(2, Math.round(width * srcHeight / srcWidth / 2) * 2);
    const args = ["-hide_banner", "-loglevel", "error", "-nostdin"];
    if (start > 0) args.push("-ss", start.toFixed(3));
    args.push("-t", Math.max(0.5, Math.min(duration, 60)).toFixed(3), "-i", path, "-an", "-vf", `fps=${fps},scale=${width}:${height}:flags=area,format=gray`, "-f", "rawvideo", "-pix_fmt", "gray", "pipe:1");
    const r = await run(ffmpeg, args, { signal, maxBuffer: 64 * 1024 * 1024 });
    const buf = Buffer.isBuffer(r.stdout) ? r.stdout : Buffer.from(r.stdout);
    const frame = width * height;
    const n = Math.floor(buf.length / frame);
    if (n < 2) return null;
    const col = new Float64Array(width);
    let total = 0;
    for (let f = 1; f < n; f++) {
      const cur = f * frame;
      const prev = cur - frame;
      for (let i = 0; i < frame; i++) {
        const d = Math.abs(buf[cur + i] - buf[prev + i]);
        if (d > 10) {
          col[i % width] += d;
          total += d;
        }
      }
    }
    if (total < frame * 0.5) return null;
    let sum = 0;
    for (let x = 0; x < width; x++) sum += (x + 0.5) * col[x];
    return sum / total / width;
  }
  /** Bir kareyi küçültülmüş ham RGB olarak okur (renk ölçümü için). Görsellerde time verilmez. */
  async grabRgb(path, { time = null, width = 160, signal } = {}) {
    if (!(0, import_node_fs3.existsSync)(path)) throw Object.assign(new Error(`Dosya bulunamad\u0131: ${path}`), { status: 404 });
    const ffmpeg = this.tools.require("ffmpeg");
    const args = ["-hide_banner", "-loglevel", "error", "-nostdin"];
    if (time != null && time > 0) args.push("-ss", time.toFixed(3));
    args.push("-i", path, "-frames:v", "1", "-vf", `scale=${width}:-2:flags=area`, "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1");
    const r = await run(ffmpeg, args, { signal });
    return r.stdout;
  }
  /** ffmpeg ile mono 16 kHz PCM akışı başlatır; her parça onChunk(Int16Array) ile gelir. */
  async decodePcm(path, { start = 0, duration = null, channel = null, onChunk, signal }) {
    const ffmpeg = this.tools.require("ffmpeg");
    const args = ["-hide_banner", "-loglevel", "error", "-nostdin"];
    if (start > 0) args.push("-ss", start.toFixed(3));
    args.push("-i", path);
    if (duration != null) args.push("-t", Math.max(0, duration).toFixed(3));
    args.push("-vn", "-sn", "-dn");
    if (channel != null) args.push("-af", `pan=mono|c0=c${channel}`);
    else args.push("-ac", "1");
    args.push("-ar", String(ANALYSIS_RATE), "-f", "s16le", "-acodec", "pcm_s16le", "pipe:1");
    let rest = null;
    await run(ffmpeg, args, {
      signal,
      onStdout: (buf) => {
        let data = rest ? Buffer.concat([rest, buf]) : buf;
        const usable = data.length - data.length % 2;
        rest = usable < data.length ? data.subarray(usable) : null;
        if (usable) {
          const copy = Buffer.from(data.subarray(0, usable));
          onChunk(new Int16Array(copy.buffer, copy.byteOffset, usable / 2));
        }
      }
    });
  }
  /**
   * Dosyanın tamamı için dBFS zarfı (önbellekli).
   * @returns {Promise<Float32Array>}
   */
  async fileEnvelope(path, { channel = null, windowSec = 0.01, signal, onProgress } = {}) {
    const st = (0, import_node_fs3.statSync)(path);
    const key = (0, import_node_crypto2.createHash)("sha1").update(`${path}|${st.size}|${st.mtimeMs}|${channel}|${windowSec}|v1`).digest("hex");
    const cacheDir = (0, import_node_path3.join)(this.config.dirs.cache, "env");
    (0, import_node_fs3.mkdirSync)(cacheDir, { recursive: true });
    const cachePath = (0, import_node_path3.join)(cacheDir, `${key}.f32`);
    if ((0, import_node_fs3.existsSync)(cachePath)) {
      const buf = (0, import_node_fs3.readFileSync)(cachePath);
      return new Float32Array(buf.buffer, buf.byteOffset, buf.byteLength / 4);
    }
    const win = Math.round(ANALYSIS_RATE * windowSec);
    const values = [];
    let sum = 0;
    let count = 0;
    let total = 0;
    const info = onProgress ? await this.probe(path).catch(() => null) : null;
    const expected = (info == null ? void 0 : info.duration) ? info.duration * ANALYSIS_RATE : 0;
    await this.decodePcm(path, {
      channel,
      signal,
      onChunk: (samples) => {
        for (let i = 0; i < samples.length; i++) {
          const v = samples[i] / 32768;
          sum += v * v;
          if (++count === win) {
            const rms = Math.sqrt(sum / win);
            values.push(rms > 1e-5 ? 20 * Math.log10(rms) : SILENCE_DB);
            sum = 0;
            count = 0;
          }
        }
        total += samples.length;
        if (expected && onProgress) onProgress(Math.min(1, total / expected));
      }
    });
    if (count > 0) {
      const rms = Math.sqrt(sum / count);
      values.push(rms > 1e-5 ? 20 * Math.log10(rms) : SILENCE_DB);
    }
    const env = Float32Array.from(values);
    (0, import_node_fs3.writeFileSync)(cachePath, Buffer.from(env.buffer));
    return env;
  }
  /**
   * Zaman çizelgesindeki bir ses parçasının zarfı (sekans zamanında).
   * @param sources audioTrackSources() çıktısı
   */
  async trackEnvelope(sources, durationSec, { windowSec = 0.01, signal, onProgress } = {}) {
    const len = Math.ceil(durationSec / windowSec);
    const env = new Float32Array(len).fill(SILENCE_DB);
    let done = 0;
    for (const src of sources) {
      const fileEnv = await this.fileEnvelope(src.path, {
        channel: src.channel,
        windowSec,
        signal,
        onProgress: onProgress ? (p) => onProgress((done + p) / sources.length) : void 0
      });
      const from = Math.round(src.sourceIn / windowSec);
      const to = Math.round(src.sourceOut / windowSec);
      const at = Math.round(src.timelineStart / windowSec);
      for (let i = from, j = at; i < to && j < len; i++, j++) {
        if (j >= 0 && i >= 0 && i < fileEnv.length && fileEnv[i] > env[j]) env[j] = fileEnv[i];
      }
      done++;
    }
    return env;
  }
  /**
   * Bir ya da birkaç ses parçasını (sekans zamanında) 16 kHz mono WAV'a döker.
   * @param tracks audioTrackSources() dizilerinin dizisi
   */
  async renderTracksWav(tracks, durationSec, outPath, { signal, onProgress } = {}) {
    const totalSamples = Math.ceil(durationSec * ANALYSIS_RATE);
    const mix = new Int16Array(totalSamples);
    const allSources = tracks.flat();
    let done = 0;
    for (const sources of tracks) {
      for (const src of sources) {
        let pos = Math.round(src.timelineStart * ANALYSIS_RATE);
        const end = Math.min(totalSamples, Math.round(src.timelineEnd * ANALYSIS_RATE));
        await this.decodePcm(src.path, {
          start: src.sourceIn,
          duration: src.sourceOut - src.sourceIn,
          channel: src.channel,
          signal,
          onChunk: (samples) => {
            for (let i = 0; i < samples.length && pos < end; i++, pos++) {
              if (pos >= 0) mix[pos] = Math.max(-32768, Math.min(32767, mix[pos] + samples[i]));
            }
          }
        });
        done++;
        onProgress == null ? void 0 : onProgress(done / allSources.length);
      }
    }
    writeWav16(outPath, mix);
    return outPath;
  }
  /** Zaman çizelgesinin yalnızca [start, end] aralığını WAV'a döker (önizleme için). */
  async renderWindowWav(tracks, start, end, outPath, { signal } = {}) {
    const total = Math.ceil((end - start) * ANALYSIS_RATE);
    const mix = new Int16Array(total);
    for (const src of tracks.flat()) {
      const a = Math.max(start, src.timelineStart);
      const b = Math.min(end, src.timelineEnd);
      if (b <= a) continue;
      let pos = Math.round((a - start) * ANALYSIS_RATE);
      const stop = Math.min(total, Math.round((b - start) * ANALYSIS_RATE));
      await this.decodePcm(src.path, {
        start: src.sourceIn + (a - src.timelineStart),
        duration: b - a,
        channel: src.channel,
        signal,
        onChunk: (samples) => {
          for (let i = 0; i < samples.length && pos < stop; i++, pos++) {
            mix[pos] = Math.max(-32768, Math.min(32767, mix[pos] + samples[i]));
          }
        }
      });
    }
    writeWav16(outPath, mix);
    return outPath;
  }
  /** Bir dosyanın sesini 16 kHz mono WAV olarak çıkarır (whisper girdisi). */
  async extractWav(path, outPath, { start = 0, duration = null, channel = null, signal } = {}) {
    const ffmpeg = this.tools.require("ffmpeg");
    const args = ["-hide_banner", "-loglevel", "error", "-nostdin", "-y"];
    if (start > 0) args.push("-ss", start.toFixed(3));
    args.push("-i", path);
    if (duration != null) args.push("-t", duration.toFixed(3));
    args.push("-vn", "-sn", "-dn");
    if (channel != null) args.push("-af", `pan=mono|c0=c${channel}`);
    else args.push("-ac", "1");
    args.push("-ar", String(ANALYSIS_RATE), "-c:a", "pcm_s16le", outPath);
    await run(ffmpeg, args, { signal });
    return outPath;
  }
};
function parseRate(text) {
  if (!text) return 0;
  const [a, b] = String(text).split("/").map(Number);
  if (!b) return a || 0;
  return a / b;
}
function writeWav16(path, samples, sampleRate = ANALYSIS_RATE) {
  const dataBytes = samples.length * 2;
  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + dataBytes, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(1, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * 2, 28);
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write("data", 36);
  header.writeUInt32LE(dataBytes, 40);
  const fd = (0, import_node_fs3.openSync)(path, "w");
  try {
    (0, import_node_fs3.writeSync)(fd, header);
    if (samples instanceof Int16Array) {
      (0, import_node_fs3.writeSync)(fd, Buffer.from(samples.buffer, samples.byteOffset, samples.byteLength));
      return;
    }
    const chunk = 1 << 16;
    for (let i = 0; i < samples.length; i += chunk) {
      const n = Math.min(chunk, samples.length - i);
      const buf = Buffer.alloc(n * 2);
      for (let j = 0; j < n; j++) {
        const v = Math.max(-1, Math.min(1, samples[i + j]));
        buf.writeInt16LE(Math.round(v * 32767), j * 2);
      }
      (0, import_node_fs3.writeSync)(fd, buf);
    }
  } finally {
    (0, import_node_fs3.closeSync)(fd);
  }
}

// engine/whisper.js
var import_node_fs5 = require("fs");
var import_promises = require("fs/promises");
var import_node_path4 = require("path");
var import_node_os3 = require("os");

// core/transcript.js
var SPECIAL_TOKEN = /^\s*(\[_[^\]]*\]|<\|[^|]*\|>)\s*$/;
var NON_SPEECH = /^[[(♪*].*[\])♪*]$/;
function parseWhisperJson(json, { offset = 0, removeNonSpeech = true } = {}) {
  var _a, _b;
  const data = typeof json === "string" ? JSON.parse(json) : json;
  const segments = [];
  const words = [];
  for (const [segIndex, seg] of (data.transcription ?? []).entries()) {
    const segStart = seg.offsets.from / 1e3 + offset;
    const segEnd = seg.offsets.to / 1e3 + offset;
    const segWords = [];
    let current = null;
    if (Array.isArray(seg.tokens) && seg.tokens.length) {
      for (const tok of seg.tokens) {
        const text = tok.text ?? "";
        if (!text || SPECIAL_TOKEN.test(text)) continue;
        const hasTime = tok.offsets && tok.offsets.from >= 0 && tok.offsets.to >= 0;
        const t0 = hasTime ? tok.offsets.from / 1e3 + offset : null;
        const t1 = hasTime ? tok.offsets.to / 1e3 + offset : null;
        const dtw = Number.isFinite(tok.t_dtw) && tok.t_dtw >= 0 ? tok.t_dtw / 100 + offset : null;
        const startsWord = /^\s/.test(text) || !current;
        if (startsWord) {
          if (current) segWords.push(current);
          current = { text: text.trim(), start: t0, end: t1, dtw, probs: [tok.p ?? 1] };
        } else {
          current.text += text;
          if (current.start == null) current.start = t0;
          if (current.dtw == null) current.dtw = dtw;
          if (t1 != null) current.end = t1;
          current.probs.push(tok.p ?? 1);
        }
      }
      if (current) segWords.push(current);
      applyDtw(segWords, segEnd);
    } else {
      const parts = String(seg.text ?? "").trim().split(/\s+/).filter(Boolean);
      const totalChars = parts.reduce((n, p) => n + p.length, 0) || 1;
      let t = segStart;
      for (const p of parts) {
        const d = (segEnd - segStart) * p.length / totalChars;
        segWords.push({ text: p, start: t, end: t + d, probs: [1] });
        t += d;
      }
    }
    const cleaned = fixWordTimes(
      segWords.filter((w) => w.text && !(removeNonSpeech && NON_SPEECH.test(w.text))),
      segStart,
      segEnd
    ).map(({ probs, dtw, ...w }) => ({ ...w, seg: segIndex, p: round3(probs.reduce((a, b) => a + b, 0) / probs.length) }));
    if (cleaned.length) {
      segments.push({ start: cleaned[0].start, end: cleaned[cleaned.length - 1].end, text: cleaned.map((w) => w.text).join(" ") });
      words.push(...cleaned);
    }
  }
  return { language: ((_a = data.result) == null ? void 0 : _a.language) ?? ((_b = data.params) == null ? void 0 : _b.language) ?? null, segments, words };
}
function applyDtw(words, segEnd) {
  if (!words.length || words.some((w) => w.dtw == null)) return;
  for (let i = 1; i < words.length; i++) if (words[i].dtw < words[i - 1].dtw) return;
  words.forEach((w, i) => {
    const next = words[i + 1];
    w.start = w.dtw;
    w.end = next ? Math.max(w.dtw + 0.05, next.dtw) : Math.max(w.dtw + 0.15, Math.min(segEnd, w.dtw + 1));
  });
}
function alignToSpeech(words, env, { windowSec = 0.01, threshold, minGap = 0.25 } = {}) {
  if (!words.length || !(env == null ? void 0 : env.length) || !Number.isFinite(threshold)) return words;
  const regions = activeRegions(env, { windowSec, threshold, minSilence: 0.2, minSpeech: 0.08 });
  if (!regions.length) return words;
  const voicedAt = (t) => regions.some(([a, b]) => a <= t && t < b);
  const groups = [];
  for (const w of words) {
    const last = groups[groups.length - 1];
    if (last && last[0].seg === w.seg && w.seg != null) last.push(w);
    else groups.push([w]);
  }
  const out = [];
  let prevEnd = 0;
  for (const g of groups) {
    const s0 = g[0].start;
    const e0 = g[g.length - 1].end;
    let onset = s0;
    let tail2 = e0;
    if (!voicedAt(s0)) {
      const next = regions.find(([a]) => a > s0);
      if (next && next[0] < e0 - 0.05 && next[0] - s0 >= minGap) onset = next[0];
    }
    if (!voicedAt(e0 - 0.01)) {
      const prev = [...regions].reverse().find(([, b]) => b < e0);
      if (prev && prev[1] > onset + 0.1 && e0 - prev[1] >= minGap) tail2 = prev[1];
    }
    onset = Math.max(onset, prevEnd);
    if (tail2 - onset < 0.05 || onset === s0 && tail2 === e0) {
      out.push(...g);
      prevEnd = Math.max(prevEnd, e0);
      continue;
    }
    const k = (tail2 - onset) / Math.max(0.01, e0 - s0);
    for (const w of g) out.push({ ...w, start: round3(onset + (w.start - s0) * k), end: round3(onset + (w.end - s0) * k) });
    prevEnd = out[out.length - 1].end;
  }
  return out;
}
function round3(n) {
  return Math.round(n * 1e3) / 1e3;
}
function fixWordTimes(words, segStart, segEnd) {
  const n = words.length;
  for (let i = 0; i < n; i++) {
    const w = words[i];
    if (w.start == null) w.start = i > 0 ? words[i - 1].end : segStart;
    if (w.end == null) w.end = w.start;
  }
  let prevEnd = segStart;
  for (const w of words) {
    w.start = Math.min(Math.max(w.start, prevEnd, segStart), segEnd);
    w.end = Math.min(Math.max(w.end, w.start), segEnd);
    prevEnd = w.start;
  }
  for (let i = 0; i < n; i++) {
    const w = words[i];
    if (w.end - w.start < 0.02) {
      const limit = i + 1 < n ? words[i + 1].start : segEnd;
      w.end = Math.max(w.end, Math.min(w.start + 0.2, limit));
    }
  }
  return words;
}
function remapWords(words, keepRanges) {
  const mapper = createTimeMapper(keepRanges);
  const out = [];
  for (const w of words) {
    const parts = mapper.mapRange(w.start, w.end);
    if (!parts.length) continue;
    const kept = parts.reduce((n, [a, b]) => n + (b - a), 0);
    if (kept < (w.end - w.start) * 0.5) continue;
    out.push({ ...w, start: parts[0][0], end: parts[parts.length - 1][1] });
  }
  return out;
}
function wordsToText(words) {
  return words.map((w) => w.text).join(" ").replace(/\s+([,.!?;:…])/g, "$1");
}

// engine/net.js
var import_node_fs4 = require("fs");
var import_node_http = __toESM(require("http"), 1);
var import_node_https = __toESM(require("https"), 1);
var import_node_zlib = require("zlib");
function request(url, opts = {}) {
  const { method = "GET", headers = {}, body, signal, timeoutMs = 6e4, maxRedirects = 5 } = opts;
  return new Promise((resolve3, reject) => {
    const u = new URL(url);
    const lib = u.protocol === "http:" ? import_node_http.default : import_node_https.default;
    const payload = body == null ? null : Buffer.isBuffer(body) ? body : Buffer.from(String(body));
    const req = lib.request(
      u,
      {
        method,
        headers: { "User-Agent": "Makas/1.0", ...payload ? { "Content-Length": payload.length } : {}, ...headers }
      },
      (res) => {
        const status = res.statusCode ?? 0;
        if (status >= 300 && status < 400 && res.headers.location && maxRedirects > 0) {
          res.resume();
          const next = new URL(res.headers.location, u);
          const nextHeaders = next.origin === u.origin ? headers : Object.fromEntries(Object.entries(headers).filter(([k]) => k.toLowerCase() !== "authorization"));
          request(next.toString(), {
            ...opts,
            headers: nextHeaders,
            maxRedirects: maxRedirects - 1,
            method: status === 303 ? "GET" : method,
            body: status === 303 ? null : body
          }).then(resolve3, reject);
          return;
        }
        if (opts.onResponse) {
          opts.onResponse(res, status, u.toString()).then(resolve3, reject);
          return;
        }
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => resolve3({ status, headers: res.headers, body: Buffer.concat(chunks) }));
        res.on("error", reject);
      }
    );
    req.setTimeout(timeoutMs, () => req.destroy(new Error("Ba\u011Flant\u0131 zaman a\u015F\u0131m\u0131na u\u011Frad\u0131")));
    req.on("error", (e) => reject((signal == null ? void 0 : signal.aborted) ? new Error("\u0130ptal edildi") : e));
    signal == null ? void 0 : signal.addEventListener("abort", () => req.destroy(new Error("\u0130ptal edildi")), { once: true });
    if (payload) req.write(payload);
    req.end();
  });
}
function maybeGunzip(buf) {
  return buf && buf.length > 2 && buf[0] === 31 && buf[1] === 139 ? (0, import_node_zlib.gunzipSync)(buf) : buf;
}
async function requestJson(url, opts = {}) {
  const r = await request(url, { ...opts, headers: { Accept: "application/json", "Accept-Encoding": "gzip", ...opts.headers ?? {} } });
  r.body = maybeGunzip(r.body);
  let data = null;
  try {
    data = r.body.length ? JSON.parse(r.body.toString("utf8")) : null;
  } catch {
    data = null;
  }
  return { status: r.status, headers: r.headers, data, raw: r.body };
}
function downloadFile(url, dest, { onProgress, signal, headers, timeoutMs = 12e4 } = {}) {
  const tmp = `${dest}.part`;
  return request(url, {
    headers,
    signal,
    timeoutMs,
    onResponse: (res, status) => new Promise((resolve3, reject) => {
      if (status < 200 || status >= 300) {
        res.resume();
        reject(Object.assign(new Error(`\u0130ndirilemedi (HTTP ${status})`), { status }));
        return;
      }
      const total = Number(res.headers["content-length"]) || 0;
      let received = 0;
      const out = (0, import_node_fs4.createWriteStream)(tmp);
      res.on("data", (c) => {
        received += c.length;
        if (total && onProgress) onProgress(Math.min(0.999, received / total), received, total);
      });
      res.on("error", (e) => {
        out.destroy();
        (0, import_node_fs4.rmSync)(tmp, { force: true });
        reject(e);
      });
      out.on("error", (e) => {
        (0, import_node_fs4.rmSync)(tmp, { force: true });
        reject(e);
      });
      out.on("finish", () => {
        try {
          (0, import_node_fs4.renameSync)(tmp, dest);
          resolve3({ status, headers: res.headers, bytes: received, path: dest });
        } catch (e) {
          reject(e);
        }
      });
      res.pipe(out);
    })
  }).catch((e) => {
    (0, import_node_fs4.rmSync)(tmp, { force: true });
    throw e;
  });
}
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function probeDownload(url, { headers, signal, timeoutMs = 3e4 } = {}) {
  return request(url, {
    headers: { ...headers, Range: "bytes=0-0" },
    signal,
    timeoutMs,
    onResponse: async (res, status, finalUrl) => {
      var _a;
      if (status === 206) {
        res.resume();
        const total = Number((_a = /\/(\d+)\s*$/.exec(String(res.headers["content-range"] ?? ""))) == null ? void 0 : _a[1]) || 0;
        return { ranges: total > 0, total, url: finalUrl };
      }
      res.destroy();
      if (status >= 200 && status < 300) return { ranges: false, total: Number(res.headers["content-length"]) || 0, url: finalUrl };
      throw Object.assign(new Error(`\u0130ndirilemedi (HTTP ${status})`), { status });
    }
  });
}
function fetchRange(url, fd, from, to, { headers, signal, idleMs, onBytes }) {
  return request(url, {
    headers: { ...headers, Range: `bytes=${from}-${to}` },
    signal,
    timeoutMs: idleMs,
    onResponse: (res, status) => new Promise((resolve3, reject) => {
      if (status !== 206) {
        res.destroy();
        reject(Object.assign(new Error(`B\xF6l\xFCm indirilemedi (HTTP ${status})`), { status }));
        return;
      }
      let pos = from;
      let writing = false;
      let ended = false;
      let failed = false;
      const fail = (e) => {
        if (failed) return;
        failed = true;
        reject(e);
      };
      res.on("data", (chunk) => {
        const n = Math.max(0, Math.min(chunk.length, to + 1 - pos));
        if (!n) return;
        res.pause();
        writing = true;
        (0, import_node_fs4.write)(fd, chunk, 0, n, pos, (err) => {
          writing = false;
          if (err) {
            res.destroy();
            fail(err);
            return;
          }
          pos += n;
          onBytes(n);
          if (ended) resolve3();
          else res.resume();
        });
      });
      res.on("end", () => {
        ended = true;
        if (!writing) resolve3();
      });
      res.on("error", fail);
      res.on("close", () => {
        if (!res.complete) fail(new Error("Ba\u011Flant\u0131 kesildi"));
      });
    })
  });
}
async function downloadFileFast(url, dest, { onProgress, signal, headers, connections = 6, partSize = 16 * 1024 * 1024, idleMs = 3e4 } = {}) {
  const tmp = `${dest}.part`;
  const statePath = `${tmp}.json`;
  let probe = await probeDownload(url, { headers, signal });
  if (!probe.ranges || probe.total < partSize * 2) {
    (0, import_node_fs4.rmSync)(statePath, { force: true });
    return downloadFile(probe.url || url, dest, { onProgress, signal, headers, timeoutMs: idleMs * 4 });
  }
  const total = probe.total;
  let state = null;
  try {
    state = JSON.parse((0, import_node_fs4.readFileSync)(statePath, "utf8"));
  } catch {
    state = null;
  }
  if (!state || state.total !== total || !(0, import_node_fs4.existsSync)(tmp) || (0, import_node_fs4.statSync)(tmp).size !== total) {
    const parts = [];
    for (let start = 0; start < total; start += partSize) parts.push({ start, end: Math.min(total, start + partSize) - 1, done: 0 });
    state = { url, total, parts };
    const fd0 = (0, import_node_fs4.openSync)(tmp, "w");
    (0, import_node_fs4.ftruncateSync)(fd0, total);
    (0, import_node_fs4.closeSync)(fd0);
  }
  const saveState = () => {
    try {
      (0, import_node_fs4.writeFileSync)(statePath, JSON.stringify(state));
    } catch {
    }
  };
  saveState();
  let received = state.parts.reduce((n, p) => n + p.done, 0);
  const report = () => onProgress == null ? void 0 : onProgress(Math.min(0.999, received / total), received, total);
  report();
  const saver = setInterval(saveState, 1e3);
  const fd = (0, import_node_fs4.openSync)(tmp, "r+");
  let finalUrl = probe.url;
  let refreshing = null;
  const refreshUrl = async () => {
    refreshing ??= probeDownload(url, { headers, signal }).then((p) => {
      finalUrl = p.url;
    }).finally(() => {
      refreshing = null;
    });
    return refreshing;
  };
  const queue = state.parts.filter((p) => p.start + p.done <= p.end);
  async function worker() {
    for (; ; ) {
      const part = queue.shift();
      if (!part) return;
      let attempts = 0;
      while (part.start + part.done <= part.end) {
        if (signal == null ? void 0 : signal.aborted) throw new Error("\u0130ptal edildi");
        const before = part.done;
        try {
          await fetchRange(finalUrl, fd, part.start + part.done, part.end, {
            headers,
            signal,
            idleMs,
            onBytes: (n) => {
              part.done += n;
              received += n;
              report();
            }
          });
          if (part.done === before && ++attempts > 6) throw new Error("\u0130ndirme ilerlemiyor");
        } catch (e) {
          if (signal == null ? void 0 : signal.aborted) throw new Error("\u0130ptal edildi");
          attempts += 1;
          if (attempts > 6) throw e;
          if (e.status === 403 || e.status === 410 || e.status === 401) await refreshUrl().catch(() => {
          });
          await sleep(Math.min(8e3, 700 * attempts));
        }
      }
    }
  }
  try {
    await Promise.all(Array.from({ length: Math.min(connections, queue.length) }, () => worker()));
  } finally {
    clearInterval(saver);
    (0, import_node_fs4.closeSync)(fd);
    saveState();
  }
  if (received < total) throw new Error("\u0130ndirme tamamlanamad\u0131");
  (0, import_node_fs4.rmSync)(statePath, { force: true });
  (0, import_node_fs4.renameSync)(tmp, dest);
  onProgress == null ? void 0 : onProgress(1, total, total);
  return { bytes: total, path: dest };
}
function partialDownload(dest) {
  try {
    const st = JSON.parse((0, import_node_fs4.readFileSync)(`${dest}.part.json`, "utf8"));
    const done = st.parts.reduce((n, p) => n + p.done, 0);
    return st.total ? done / st.total : null;
  } catch {
    return null;
  }
}
function progressReporter(cb, { intervalMs = 250 } = {}) {
  let last = 0;
  let lastBytes = null;
  let lastTime = 0;
  let speed = 0;
  return (p, received, total) => {
    const now = Date.now();
    if (p < 1 && now - last < intervalMs) return;
    last = now;
    if (lastBytes != null && now > lastTime) {
      const inst = (received - lastBytes) * 1e3 / (now - lastTime);
      speed = speed ? speed * 0.8 + inst * 0.2 : inst;
    }
    lastBytes = received;
    lastTime = now;
    const mb = (n) => Math.round(n / 1e6);
    let msg = total ? `${mb(received)} / ${mb(total)} MB` : `${mb(received)} MB`;
    if (speed > 0) {
      msg += ` \xB7 ${(speed / 1e6).toFixed(1).replace(".", ",")} MB/sn`;
      if (total) {
        const left = (total - received) / speed;
        msg += left > 90 ? ` \xB7 ~${Math.ceil(left / 60)} dk` : left > 2 ? ` \xB7 ~${Math.ceil(left)} sn` : "";
      }
    }
    cb(p, msg);
  };
}

// engine/whisper.js
var HF = process.env.MAKAS_MODEL_BASE || "https://huggingface.co/ggerganov/whisper.cpp/resolve/main";
var MODEL_CATALOG = [
  {
    id: "large-v3-turbo-q5_0",
    file: "ggml-large-v3-turbo-q5_0.bin",
    sizeMB: 547,
    dtw: "large.v3.turbo",
    label: "Turbo (\xF6nerilen): h\u0131zl\u0131 ve T\xFCrk\xE7ede \xE7ok iyi",
    canTranslate: false
  },
  {
    id: "large-v3-turbo",
    file: "ggml-large-v3-turbo.bin",
    sizeMB: 1550,
    dtw: "large.v3.turbo",
    label: "Turbo tam hassasiyet: biraz daha do\u011Fru, 3 kat b\xFCy\xFCk",
    canTranslate: false
  },
  {
    id: "medium-q5_0",
    file: "ggml-medium-q5_0.bin",
    sizeMB: 514,
    dtw: "medium",
    label: "Medium: \u0130ngilizceye \xE7eviri i\xE7in \xF6nerilen",
    canTranslate: true
  },
  {
    id: "large-v3-q5_0",
    file: "ggml-large-v3-q5_0.bin",
    sizeMB: 1031,
    dtw: "large.v3",
    label: "Large v3: en iyi \xE7eviri kalitesi, yava\u015F",
    canTranslate: true
  },
  { id: "small", file: "ggml-small.bin", sizeMB: 466, dtw: "small", label: "Small: zay\u0131f bilgisayarlar i\xE7in", canTranslate: true },
  { id: "base", file: "ggml-base.bin", sizeMB: 142, dtw: "base", label: "Base: h\u0131zl\u0131 deneme", canTranslate: true }
];
var Whisper = class {
  constructor(tools, config) {
    this.tools = tools;
    this.config = config;
  }
  modelPath(id) {
    const entry = MODEL_CATALOG.find((m2) => m2.id === id);
    const file = entry ? entry.file : id;
    const p = (0, import_node_path4.join)(this.config.dirs.models, file);
    return (0, import_node_fs5.existsSync)(p) ? p : null;
  }
  listModels() {
    const files = (0, import_node_fs5.existsSync)(this.config.dirs.models) ? (0, import_node_fs5.readdirSync)(this.config.dirs.models) : [];
    const known = MODEL_CATALOG.map((m2) => {
      const installed = files.includes(m2.file);
      const partial = installed ? null : partialDownload((0, import_node_path4.join)(this.config.dirs.models, `${m2.file}.download`));
      return { ...m2, installed, partial, path: installed ? (0, import_node_path4.join)(this.config.dirs.models, m2.file) : null };
    });
    const custom = files.filter((f) => f.endsWith(".bin") && !MODEL_CATALOG.some((m2) => m2.file === f)).map((f) => ({
      id: f,
      file: f,
      sizeMB: Math.round((0, import_node_fs5.statSync)((0, import_node_path4.join)(this.config.dirs.models, f)).size / 1e6),
      label: `Elle eklenen model (${f})`,
      installed: true,
      canTranslate: !/turbo/i.test(f),
      path: (0, import_node_path4.join)(this.config.dirs.models, f)
    }));
    return [...known, ...custom];
  }
  /** Model dosyasını Hugging Face'ten indirir. */
  async download(id, { onProgress, signal } = {}) {
    const entry = MODEL_CATALOG.find((m2) => m2.id === id);
    if (!entry) throw new Error(`Bilinmeyen model: ${id}`);
    const dest = (0, import_node_path4.join)(this.config.dirs.models, entry.file);
    if ((0, import_node_fs5.existsSync)(dest)) return dest;
    const tmp = `${dest}.download`;
    try {
      await downloadFileFast(`${HF}/${entry.file}`, tmp, { signal, onProgress });
      assertGgml(tmp);
      (0, import_node_fs5.renameSync)(tmp, dest);
    } catch (e) {
      (0, import_node_fs5.rmSync)(tmp, { force: true });
      throw e;
    }
    return dest;
  }
  /** Kullanıcının başka yoldan indirdiği model dosyasını kopyalar. */
  importModel(path) {
    assertGgml(path);
    const dest = (0, import_node_path4.join)(this.config.dirs.models, (0, import_node_path4.basename)(path));
    (0, import_node_fs5.copyFileSync)(path, dest);
    return dest;
  }
  /**
   * @param {{wavPath:string, model?:string, language?:string, translate?:boolean, prompt?:string, offset?:number, signal?:AbortSignal, onProgress?:(p:number)=>void}} opts
   */
  async transcribe(opts) {
    const exe = this.tools.require("whisper");
    const s = this.config.settings;
    const modelId = opts.model ?? (opts.translate ? s.translateModel : s.model);
    const modelPath = this.modelPath(modelId) ?? this.#anyInstalled(opts.translate);
    if (!modelPath) {
      const err = new Error("Hen\xFCz bir konu\u015Fma tan\u0131ma modeli y\xFCkl\xFC de\u011Fil. Ayarlar > Modeller b\xF6l\xFCm\xFCnden bir model indirin.");
      err.status = 412;
      throw err;
    }
    const entry = MODEL_CATALOG.find((m2) => modelPath.endsWith(m2.file));
    const outBase = opts.wavPath.replace(/\.wav$/i, "") + ".whisper";
    const threads = s.threads > 0 ? s.threads : Math.max(1, Math.min(8, (0, import_node_os3.cpus)().length - 1));
    const base = ["-m", modelPath, "-f", opts.wavPath, "-l", opts.language ?? s.language ?? "tr", "-ojf", "-of", outBase, "-pp", "-t", String(threads), "-sns"];
    if (opts.translate) base.push("-tr");
    const prompt = opts.prompt ?? s.prompt;
    if (prompt && !opts.translate) base.push("--prompt", prompt);
    const attempt = async (useDtw) => {
      const args = [...base];
      if (useDtw && (entry == null ? void 0 : entry.dtw)) args.push("-dtw", entry.dtw, "-nfa");
      await run(exe, args, {
        signal: opts.signal,
        onStderrLine: (line) => {
          var _a;
          const m2 = /progress\s*=\s*(\d+)%/.exec(line);
          if (m2) (_a = opts.onProgress) == null ? void 0 : _a.call(opts, Math.min(1, Number(m2[1]) / 100));
        }
      });
    };
    try {
      await attempt(s.useDtw);
    } catch (e) {
      if (!s.useDtw || e.code === "ABORTED") throw e;
      await attempt(false);
    }
    const json = await (0, import_promises.readFile)(`${outBase}.json`, "utf8");
    return { ...parseWhisperJson(json, { offset: opts.offset ?? 0 }), model: (0, import_node_path4.basename)(modelPath) };
  }
  #anyInstalled(needTranslate) {
    var _a;
    const installed = this.listModels().filter((m2) => m2.installed && (!needTranslate || m2.canTranslate));
    return ((_a = installed[0]) == null ? void 0 : _a.path) ?? null;
  }
};
function assertGgml(path) {
  const fd = (0, import_node_fs5.openSync)(path, "r");
  const buf = Buffer.alloc(4);
  try {
    (0, import_node_fs5.readSync)(fd, buf, 0, 4, 0);
  } finally {
    (0, import_node_fs5.closeSync)(fd);
  }
  const magic = buf.toString("latin1");
  if (magic !== "lmgg" && magic !== "ggml") throw new Error("Bu dosya bir whisper.cpp (ggml) modeli de\u011Fil");
}

// engine/jobs.js
var import_node_crypto3 = require("crypto");
var HEAVY = /* @__PURE__ */ new Set(["transcribe", "render-captions"]);
var JobManager = class {
  /** @param {{onError?:(type:string, message:string)=>void}} opts */
  constructor({ onError } = {}) {
    this.onError = onError;
    this.jobs = /* @__PURE__ */ new Map();
    this.heavyQueue = Promise.resolve();
  }
  /**
   * @param {string} type
   * @param {(ctx:{signal:AbortSignal, progress:(p:number, msg?:string)=>void})=>Promise<any>} fn
   */
  start(type, fn, meta = {}) {
    const controller = new AbortController();
    const job = {
      id: (0, import_node_crypto3.randomUUID)().slice(0, 8),
      type,
      meta,
      status: "queued",
      progress: 0,
      message: "S\u0131rada",
      result: null,
      error: null,
      createdAt: Date.now(),
      finishedAt: null,
      controller
    };
    this.jobs.set(job.id, job);
    const runJob = async () => {
      var _a;
      if (controller.signal.aborted) return;
      job.status = "running";
      job.message = "\xC7al\u0131\u015F\u0131yor";
      try {
        job.result = await fn({
          signal: controller.signal,
          progress: (p, msg) => {
            if (Number.isFinite(p)) job.progress = Math.max(0, Math.min(1, p));
            if (msg) job.message = msg;
          }
        });
        job.status = "done";
        job.progress = 1;
        job.message = "Tamamland\u0131";
      } catch (e) {
        job.status = controller.signal.aborted ? "cancelled" : "error";
        job.error = controller.signal.aborted ? "\u0130ptal edildi" : e.message;
        job.message = job.error;
        if (job.status === "error") (_a = this.onError) == null ? void 0 : _a.call(this, type, e.message);
      } finally {
        job.finishedAt = Date.now();
        this.#prune();
      }
    };
    if (HEAVY.has(type)) this.heavyQueue = this.heavyQueue.then(runJob);
    else runJob();
    return this.view(job);
  }
  get(id) {
    const job = this.jobs.get(id);
    return job ? this.view(job) : null;
  }
  list() {
    return [...this.jobs.values()].sort((a, b) => b.createdAt - a.createdAt).map((j) => this.view(j));
  }
  cancel(id) {
    const job = this.jobs.get(id);
    if (!job) return false;
    job.controller.abort();
    if (job.status === "queued") {
      job.status = "cancelled";
      job.message = "\u0130ptal edildi";
    }
    return true;
  }
  view(job) {
    const { controller, ...rest } = job;
    return rest;
  }
  #prune() {
    const done = [...this.jobs.values()].filter((j) => j.finishedAt).sort((a, b) => a.finishedAt - b.finishedAt);
    while (done.length > 50) this.jobs.delete(done.shift().id);
  }
};

// engine/library.js
var import_node_fs6 = require("fs");
var import_promises2 = require("fs/promises");
var import_node_path5 = require("path");

// core/text.js
var FOLD_MAP = { \u00E7: "c", \u011F: "g", \u0131: "i", i: "i", \u00F6: "o", \u015F: "s", \u00FC: "u", \u00E2: "a", \u00EE: "i", \u00FB: "u" };
function foldText(text) {
  return String(text).toLocaleLowerCase("tr-TR").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[çğıöşüâîû]/g, (ch) => FOLD_MAP[ch] ?? ch).replace(/[^a-z0-9]+/g, " ").trim();
}
function tokenize(text) {
  const folded = foldText(text);
  return folded ? folded.split(" ") : [];
}
function upperTr(text) {
  return String(text).toLocaleUpperCase("tr-TR");
}
function lowerTr(text) {
  return String(text).toLocaleLowerCase("tr-TR");
}
var SENTENCE_END = /[.!?…]["'”’)]*$/;
var CLAUSE_END = /[,;:]["'”’)]*$/;
function endsSentence(word) {
  return SENTENCE_END.test(word);
}
function endsClause(word) {
  return CLAUSE_END.test(word);
}
function stripPunctuation(word) {
  return word.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}'’]+$/gu, "");
}
function derivedName(name, suffix) {
  let base = String(name ?? "").trim();
  for (let prev = ""; prev !== base; ) {
    prev = base;
    base = base.replace(/\s*\(\d+\)$/, "").replace(/\s+-\s+(Kesilmiş|Makas)$/i, "").trim();
  }
  return `${base || "Sekans"} - ${suffix}`;
}

// engine/library.js
var KINDS = {
  sfx: { label: "Ses efekti", ext: [".wav", ".mp3", ".aif", ".aiff", ".flac", ".ogg", ".m4a", ".aac"] },
  overlay: { label: "Overlay / video", ext: [".mov", ".mp4", ".webm", ".m4v", ".mxf"] },
  image: { label: "G\xF6rsel", ext: [".png", ".jpg", ".jpeg", ".gif", ".webp", ".psd", ".tif", ".tiff"] },
  mogrt: { label: "Hareketli grafik (.mogrt)", ext: [".mogrt"] },
  preset: { label: "\xD6n ayar", ext: [".prfpset", ".ffx", ".setting", ".drfx"] },
  lut: { label: "LUT", ext: [".cube", ".3dl"] }
};
var EXT_TO_KIND = new Map(Object.entries(KINDS).flatMap(([k, v]) => v.ext.map((e) => [e, k])));
var SKIP_DIRS = /* @__PURE__ */ new Set(["node_modules", "__MACOSX", ".git", "$RECYCLE.BIN", "System Volume Information"]);
var MAX_FILES = 3e5;
function kindOf(path) {
  return EXT_TO_KIND.get((0, import_node_path5.extname)(path).toLowerCase()) ?? null;
}
var Library = class {
  constructor(config) {
    this.config = config;
    this.indexPath = (0, import_node_path5.join)(config.dataDir, "library-index.json");
    this.items = [];
    this.byPath = /* @__PURE__ */ new Map();
    this.#load();
  }
  #load() {
    if (!(0, import_node_fs6.existsSync)(this.indexPath)) return;
    try {
      const data = JSON.parse((0, import_node_fs6.readFileSync)(this.indexPath, "utf8"));
      this.items = (data.items ?? []).map((it) => ({ ...it, _tokens: tokenize(`${it.name} ${it.tags.join(" ")}`) }));
      this.byPath = new Map(this.items.map((it) => [it.path, it]));
    } catch {
      this.items = [];
    }
  }
  #save() {
    const items = this.items.map(({ _tokens, ...it }) => it);
    (0, import_node_fs6.writeFileSync)(this.indexPath, JSON.stringify({ version: 1, savedAt: Date.now(), items }));
  }
  folders() {
    const list = [...this.config.settings.libraryFolders];
    if (!list.some((f) => f.path === this.config.dirs.freesound)) {
      list.push({ path: this.config.dirs.freesound, kind: "sfx", builtin: true, label: "Freesound indirmeleri" });
    }
    return list.map((f) => ({ ...f, exists: (0, import_node_fs6.existsSync)(f.path), count: this.items.filter((i) => i.root === f.path).length }));
  }
  addFolder(path, kind = "auto") {
    const abs = (0, import_node_path5.resolve)(path);
    if (!(0, import_node_fs6.existsSync)(abs)) throw Object.assign(new Error(`Klas\xF6r bulunamad\u0131: ${abs}`), { status: 404 });
    const folders = this.config.settings.libraryFolders.filter((f) => f.path !== abs);
    folders.push({ path: abs, kind });
    this.config.update({ libraryFolders: folders });
    return this.folders();
  }
  removeFolder(path) {
    this.config.update({ libraryFolders: this.config.settings.libraryFolders.filter((f) => f.path !== path) });
    this.items = this.items.filter((i) => i.root !== path);
    this.byPath = new Map(this.items.map((it) => [it.path, it]));
    this.#save();
    return this.folders();
  }
  /** Tüm klasörleri tarar ve dizini yeniden kurar. */
  async scan({ signal, progress } = {}) {
    const folders = this.folders().filter((f) => f.exists);
    const items = [];
    for (const [fi, folder] of folders.entries()) {
      progress == null ? void 0 : progress(fi / Math.max(1, folders.length), `Taran\u0131yor: ${(0, import_node_path5.basename)(folder.path)}`);
      await this.#walk(folder.path, folder, items, signal);
    }
    this.items = items;
    this.byPath = new Map(items.map((it) => [it.path, it]));
    this.#save();
    return { count: items.length, byKind: this.stats() };
  }
  async #walk(dir, folder, out, signal) {
    if (signal == null ? void 0 : signal.aborted) throw new Error("\u0130ptal edildi");
    let entries;
    try {
      entries = await (0, import_promises2.readdir)(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries) {
      if (out.length >= MAX_FILES) return;
      if (e.name.startsWith(".") || SKIP_DIRS.has(e.name)) continue;
      const full = (0, import_node_path5.join)(dir, e.name);
      if (e.isDirectory()) {
        await this.#walk(full, folder, out, signal);
      } else if (e.isFile()) {
        const kind = kindOf(e.name);
        if (!kind || folder.kind && folder.kind !== "auto" && folder.kind !== kind && !(folder.kind === "overlay" && kind === "image")) continue;
        const item = await this.#makeItem(full, folder.path, kind);
        if (item) out.push(item);
      }
    }
  }
  async #makeItem(path, root, kind) {
    let st;
    try {
      st = await (0, import_promises2.stat)(path);
    } catch {
      return null;
    }
    const rel = (0, import_node_path5.relative)(root, (0, import_node_path5.dirname)(path));
    const tags = rel && rel !== "." ? rel.split(import_node_path5.sep).filter(Boolean) : [];
    const name = (0, import_node_path5.basename)(path, (0, import_node_path5.extname)(path));
    const item = { path, root, name, ext: (0, import_node_path5.extname)(path).toLowerCase(), kind, size: st.size, mtime: Math.round(st.mtimeMs), tags };
    const sidecar = `${path}.json`;
    if ((0, import_node_fs6.existsSync)(sidecar)) {
      try {
        const meta = JSON.parse((0, import_node_fs6.readFileSync)(sidecar, "utf8"));
        item.meta = meta;
        if (Array.isArray(meta.tags)) item.tags = [.../* @__PURE__ */ new Set([...item.tags, ...meta.tags.slice(0, 15)])];
      } catch {
      }
    }
    item._tokens = tokenize(`${item.name} ${item.tags.join(" ")}`);
    return item;
  }
  /** Tek dosyayı dizine ekler (ör. Freesound indirmesi). */
  async addFile(path, root) {
    const kind = kindOf(path);
    if (!kind) return null;
    const item = await this.#makeItem(path, root, kind);
    if (!item) return null;
    if (this.byPath.has(path)) this.items = this.items.filter((i) => i.path !== path);
    this.items.push(item);
    this.byPath.set(path, item);
    this.#save();
    return this.#public(item);
  }
  stats() {
    const out = {};
    for (const it of this.items) out[it.kind] = (out[it.kind] ?? 0) + 1;
    return out;
  }
  /**
   * Arama: her sorgu kelimesi, dosya adı ya da klasör etiketlerinden birinin başıyla eşleşmeli.
   * Türkçe karakterler sadeleştirilir ("şelale" = "selale").
   */
  search({ q = "", kind = null, limit = 60, offset = 0, favoritesOnly = false } = {}) {
    const terms = tokenize(q);
    const favs = new Set(this.config.settings.favorites);
    const results = [];
    for (const it of this.items) {
      if (kind === "assets") {
        if (it.kind === "sfx") continue;
      } else if (kind && kind !== "all" && it.kind !== kind && !(kind === "overlay" && it.kind === "image")) continue;
      if (favoritesOnly && !favs.has(it.path)) continue;
      let score = 0;
      let ok = true;
      const nameTokens = tokenize(it.name);
      for (const t of terms) {
        const inName = nameTokens.some((n) => n.startsWith(t));
        const inAny = inName || it._tokens.some((n) => n.startsWith(t));
        if (!inAny) {
          ok = false;
          break;
        }
        score += inName ? 3 : 1;
        if (nameTokens.includes(t)) score += 1;
      }
      if (!ok) continue;
      if (favs.has(it.path)) score += 0.5;
      results.push({ it, score });
    }
    results.sort((a, b) => b.score - a.score || a.it.name.localeCompare(b.it.name, "tr"));
    return {
      total: results.length,
      items: results.slice(offset, offset + limit).map(({ it }) => ({ ...this.#public(it), favorite: favs.has(it.path) }))
    };
  }
  #public(it) {
    const { _tokens, ...rest } = it;
    return rest;
  }
  setFavorite(path, on) {
    const favs = new Set(this.config.settings.favorites);
    if (on) favs.add(path);
    else favs.delete(path);
    this.config.update({ favorites: [...favs] });
    return on;
  }
  /** Bir yolun okunmasına izin var mı? (yalnızca kütüphane klasörleri ve uygulama dizini) */
  isAllowedPath(path) {
    const abs = (0, import_node_path5.resolve)(path);
    const roots = [...this.folders().map((f) => f.path), this.config.dataDir, this.config.outputDir].map((r) => (0, import_node_path5.resolve)(r));
    return roots.some((r) => abs === r || abs.startsWith(r + import_node_path5.sep));
  }
  /** Freesound kayıtları için atıf (credit) metni. */
  attributions() {
    const lines = [];
    for (const it of this.items) {
      const m2 = it.meta;
      if ((m2 == null ? void 0 : m2.source) !== "freesound" || /cc0|creative commons 0/i.test(m2.license ?? "")) continue;
      lines.push(`"${m2.name}" \u2014 ${m2.username} (${m2.url}) \u2014 ${m2.licenseName ?? m2.license}`);
    }
    return lines;
  }
};

// engine/freesound.js
var import_node_fs7 = require("fs");
var import_node_path6 = require("path");
var API = "https://freesound.org/apiv2";
var FIELDS = "id,name,tags,duration,previews,license,username,url,avg_rating,num_downloads,description";
function licenseName(url = "") {
  if (/zero|cc0|publicdomain/i.test(url)) return "CC0 (at\u0131f gerekmez)";
  if (/by-nc/i.test(url)) return "CC BY-NC (ticari kullan\u0131m yok, at\u0131f gerekli)";
  if (/by\//i.test(url) || /by$/i.test(url)) return "CC BY (at\u0131f gerekli)";
  if (/sampling/i.test(url)) return "Sampling+";
  return url;
}
function isCommercialSafe(url = "") {
  return !/by-nc|sampling/i.test(url);
}
function slug(text) {
  return String(text).normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/[^A-Za-z0-9._-]+/g, "_").replace(/_+/g, "_").slice(0, 60).replace(/^_|_$/g, "");
}
var Freesound = class {
  constructor(config, library) {
    this.config = config;
    this.library = library;
  }
  #token() {
    const t = this.config.settings.freesoundToken;
    if (!t) {
      const err = new Error("Freesound API anahtar\u0131 girilmemi\u015F. Ayarlar > Freesound b\xF6l\xFCm\xFCnden ekleyin (freesound.org/apiv2/apply adresinden \xFCcretsiz al\u0131n\u0131r).");
      err.status = 412;
      throw err;
    }
    return t;
  }
  async search({ q, page = 1, pageSize = 30, commercialOnly = false, maxDuration = 0 }) {
    const params = new URLSearchParams({ query: q ?? "", page: String(page), page_size: String(pageSize), fields: FIELDS, token: this.#token() });
    const filters = [];
    if (commercialOnly) filters.push('license:("Creative Commons 0" OR "Attribution")');
    if (maxDuration > 0) filters.push(`duration:[0 TO ${maxDuration}]`);
    if (filters.length) params.set("filter", filters.join(" "));
    let res = await requestJson(`${API}/search/text/?${params}`);
    if (res.status === 404) res = await requestJson(`${API}/search/?${params}`);
    if (res.status === 401) throw Object.assign(new Error("Freesound API anahtar\u0131 ge\xE7ersiz"), { status: 401 });
    if (res.status < 200 || res.status >= 300 || !res.data) throw new Error(`Freesound aramas\u0131 ba\u015Far\u0131s\u0131z (HTTP ${res.status})`);
    const data = res.data;
    return {
      total: data.count ?? 0,
      page,
      items: (data.results ?? []).map((s) => {
        var _a, _b;
        return {
          id: s.id,
          name: s.name,
          tags: s.tags ?? [],
          duration: s.duration,
          username: s.username,
          url: s.url,
          license: s.license,
          licenseName: licenseName(s.license),
          commercialSafe: isCommercialSafe(s.license),
          preview: ((_a = s.previews) == null ? void 0 : _a["preview-hq-mp3"]) ?? ((_b = s.previews) == null ? void 0 : _b["preview-lq-mp3"]) ?? null,
          rating: s.avg_rating,
          downloads: s.num_downloads
        };
      })
    };
  }
  /** Sesin HQ MP3 önizlemesini kütüphaneye indirir ve lisans bilgisini yanına yazar. */
  async download(sound) {
    if (!(sound == null ? void 0 : sound.preview) || !/^https:\/\/([a-z0-9-]+\.)?freesound\.org\//.test(sound.preview)) {
      throw Object.assign(new Error("Ge\xE7ersiz Freesound \xF6nizleme adresi"), { status: 400 });
    }
    const dir = this.config.dirs.freesound;
    (0, import_node_fs7.mkdirSync)(dir, { recursive: true });
    const file = (0, import_node_path6.join)(dir, `${slug(sound.name) || "ses"}_fs${Number(sound.id)}.mp3`);
    if (!(0, import_node_fs7.existsSync)(file)) {
      await downloadFile(sound.preview, file);
      (0, import_node_fs7.writeFileSync)(
        `${file}.json`,
        JSON.stringify(
          {
            source: "freesound",
            id: sound.id,
            name: sound.name,
            username: sound.username,
            url: sound.url,
            license: sound.license,
            licenseName: licenseName(sound.license),
            tags: sound.tags ?? [],
            downloadedAt: (/* @__PURE__ */ new Date()).toISOString()
          },
          null,
          2
        )
      );
    }
    return this.library.addFile(file, dir);
  }
};

// engine/bridge.js
var import_node_crypto4 = require("crypto");
var ONLINE_MS = 35e3;
var Bridge = class {
  constructor() {
    this.hosts = /* @__PURE__ */ new Map();
    this.pending = /* @__PURE__ */ new Map();
  }
  #host(name) {
    if (!this.hosts.has(name)) this.hosts.set(name, { name, info: null, lastSeen: 0, queue: [], waiters: [] });
    return this.hosts.get(name);
  }
  hello(name, info) {
    const h = this.#host(name);
    h.info = info ?? null;
    h.lastSeen = Date.now();
    return { ok: true };
  }
  status() {
    const now = Date.now();
    const out = {};
    for (const [name, h] of this.hosts) out[name] = { online: now - h.lastSeen < ONLINE_MS, info: h.info, lastSeen: h.lastSeen };
    return out;
  }
  isOnline(name) {
    const h = this.hosts.get(name);
    return Boolean(h && Date.now() - h.lastSeen < ONLINE_MS);
  }
  /** Köprü bir sonraki komutu bekler; zaman aşımında null döner. */
  poll(name, timeoutMs = 25e3) {
    const h = this.#host(name);
    h.lastSeen = Date.now();
    if (h.queue.length) return Promise.resolve(h.queue.shift());
    return new Promise((resolve3) => {
      const waiter = (cmd) => {
        clearTimeout(timer);
        resolve3(cmd);
      };
      const timer = setTimeout(() => {
        h.waiters = h.waiters.filter((w) => w !== waiter);
        h.lastSeen = Date.now();
        resolve3(null);
      }, timeoutMs);
      h.waiters.push(waiter);
    });
  }
  /** Arayüzden köprüye komut gönderir ve sonucunu bekler. */
  call(name, method, params = {}, timeoutMs = 12e4) {
    if (!this.isOnline(name)) {
      const err = new Error(
        name === "resolve" ? "DaVinci Resolve ba\u011Fl\u0131 de\u011Fil. Resolve i\xE7inde \xC7al\u0131\u015Fma Alan\u0131 > Betikler > Makas K\xF6pr\xFCs\xFC'n\xFC \xE7al\u0131\u015Ft\u0131r\u0131n." : `${name} ba\u011Fl\u0131 de\u011Fil`
      );
      err.status = 409;
      return Promise.reject(err);
    }
    const id = (0, import_node_crypto4.randomUUID)();
    const cmd = { id, method, params };
    return new Promise((resolve3, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(Object.assign(new Error(`${name} yan\u0131t vermedi (${method})`), { status: 504 }));
      }, timeoutMs);
      this.pending.set(id, { resolve: resolve3, reject, timer });
      const h = this.#host(name);
      const waiter = h.waiters.shift();
      if (waiter) waiter(cmd);
      else h.queue.push(cmd);
    });
  }
  result({ id, ok, result, error }) {
    const p = this.pending.get(id);
    if (!p) return false;
    clearTimeout(p.timer);
    this.pending.delete(id);
    if (ok) p.resolve(result);
    else p.reject(Object.assign(new Error(error || "K\xF6pr\xFCde hata"), { status: 502 }));
    return true;
  }
};

// engine/workflows.js
var import_node_crypto5 = require("crypto");
var import_node_fs9 = require("fs");
var import_node_path8 = require("path");

// core/time.js
function pad(n, width = 2) {
  return String(n).padStart(width, "0");
}
function splitMs(seconds) {
  const totalMs = Math.max(0, Math.round(seconds * 1e3));
  const ms = totalMs % 1e3;
  const totalSec = Math.floor(totalMs / 1e3);
  return { h: Math.floor(totalSec / 3600), m: Math.floor(totalSec % 3600 / 60), s: totalSec % 60, ms };
}
function formatSrtTime(seconds) {
  const { h, m: m2, s, ms } = splitMs(seconds);
  return `${pad(h)}:${pad(m2)}:${pad(s)},${pad(ms, 3)}`;
}
function formatVttTime(seconds) {
  const { h, m: m2, s, ms } = splitMs(seconds);
  return `${pad(h)}:${pad(m2)}:${pad(s)}.${pad(ms, 3)}`;
}
function formatAssTime(seconds) {
  const totalCs = Math.max(0, Math.round(seconds * 100));
  const cs = totalCs % 100;
  const totalSec = Math.floor(totalCs / 100);
  return `${Math.floor(totalSec / 3600)}:${pad(Math.floor(totalSec % 3600 / 60))}:${pad(totalSec % 60)}.${pad(cs)}`;
}
function fpsFromRate(timebase, ntsc) {
  return ntsc ? timebase * 1e3 / 1001 : timebase;
}
function rateFromFps(fps) {
  const rounded = Math.round(fps);
  const ntsc = Math.abs(fps - rounded) > 1e-3 && Math.abs(fps - rounded * 1e3 / 1001) < 0.01;
  return { timebase: rounded, ntsc };
}

// core/captions.js
var CAPTION_PRESETS = {
  // Yatay video, klasik iki satır.
  standart: { maxCharsPerLine: 42, maxLines: 2, maxWords: 0, maxDuration: 6, minDuration: 1, gapSplit: 0.8 },
  // Dikey video / sosyal medya, kısa tek satır.
  // Türkçe kelimeler uzun olduğundan satır sınırı İngilizce araçlara göre biraz geniş tutuldu.
  sosyal: { maxCharsPerLine: 22, maxLines: 1, maxWords: 3, maxDuration: 2.5, minDuration: 0.4, gapSplit: 0.4 },
  // Her kelime ayrı.
  kelime: { maxCharsPerLine: 30, maxLines: 1, maxWords: 1, maxDuration: 2, minDuration: 0.25, gapSplit: 0.3 }
};
var DEFAULTS = {
  ...CAPTION_PRESETS.standart,
  letterCase: "none",
  // none | upper | lower
  removePunctuation: false,
  minGap: 0.04
  // ardışık altyazılar arasında bırakılan en küçük boşluk (sn)
};
function buildCaptions(words, options = {}) {
  const preset = options.preset ? CAPTION_PRESETS[options.preset] ?? {} : {};
  const opts = { ...DEFAULTS, ...preset, ...options };
  const capacity = opts.maxCharsPerLine * opts.maxLines;
  const prepared = words.map((w) => ({ ...w, original: String(w.text).trim(), text: transformWord(w.text, opts) })).filter((w) => w.text.length > 0);
  const groups = [];
  let current = [];
  const charsOf = (ws) => ws.reduce((n, w) => n + w.text.length, 0) + Math.max(0, ws.length - 1);
  for (let i = 0; i < prepared.length; i++) {
    const w = prepared[i];
    if (current.length) {
      const prev = current[current.length - 1];
      const tooLong = charsOf([...current, w]) > capacity;
      const tooMany = opts.maxWords > 0 && current.length >= opts.maxWords;
      const tooSlow = w.end - current[0].start > opts.maxDuration;
      const paused = w.start - prev.end > opts.gapSplit;
      if (tooLong || tooMany || tooSlow || paused) {
        groups.push(current);
        current = [];
      }
    }
    current.push(w);
    const chars = charsOf(current);
    if (endsSentence(w.original) && chars >= capacity * 0.3) {
      groups.push(current);
      current = [];
    } else if (endsClause(w.original) && chars >= capacity * 0.6) {
      groups.push(current);
      current = [];
    }
  }
  if (current.length) groups.push(current);
  const segments = groups.map((ws) => {
    const text = ws.map((w) => w.text).join(" ");
    return {
      start: ws[0].start,
      end: ws[ws.length - 1].end,
      text,
      lines: wrapLines(ws.map((w) => w.text), opts.maxCharsPerLine, opts.maxLines),
      words: ws.map(({ text: t, start, end }) => ({ text: t, start, end }))
    };
  });
  if (opts.extendWords) {
    for (const seg of segments) {
      for (let k = 0; k + 1 < seg.words.length; k++) seg.words[k].end = Math.max(seg.words[k].end, seg.words[k + 1].start);
    }
  }
  if (opts.extendCaptions) {
    for (let i = 0; i + 1 < segments.length; i++) {
      const gap = segments[i + 1].start - segments[i].end;
      if (gap > 0 && gap <= (opts.maxExtend ?? 1.5)) segments[i].end = segments[i + 1].start - opts.minGap;
    }
  }
  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];
    const next = segments[i + 1];
    const limit = next ? next.start - opts.minGap : Infinity;
    if (seg.end - seg.start < opts.minDuration) seg.end = Math.min(seg.start + opts.minDuration, Math.max(limit, seg.end));
    if (next && seg.end > next.start - opts.minGap) seg.end = Math.max(seg.start + 0.05, next.start - opts.minGap);
  }
  return segments;
}
function transformWord(text, opts) {
  let t = String(text).trim();
  if (opts.removePunctuation) t = stripPunctuation(t);
  if (opts.letterCase === "upper") t = upperTr(t);
  else if (opts.letterCase === "lower") t = lowerTr(t);
  return t;
}
function wrapLines(words, maxChars, maxLines) {
  const joined = words.join(" ");
  if (maxLines <= 1 || joined.length <= maxChars || words.length < 2) return [joined];
  if (maxLines === 2) {
    let best = null;
    for (let i = 1; i < words.length; i++) {
      const a = words.slice(0, i).join(" ");
      const b = words.slice(i).join(" ");
      const over = Math.max(0, a.length - maxChars) + Math.max(0, b.length - maxChars);
      const punctBonus = /[,.;:!?…]$/.test(words[i - 1]) ? 3 : 0;
      const score = over * 100 + Math.abs(a.length - b.length) - punctBonus + (a.length > b.length ? 1 : 0);
      if (!best || score < best.score) best = { score, lines: [a, b] };
    }
    return best.lines;
  }
  const lines = [];
  let line = "";
  for (const w of words) {
    if (line && (line + " " + w).length > maxChars && lines.length < maxLines - 1) {
      lines.push(line);
      line = w;
    } else {
      line = line ? `${line} ${w}` : w;
    }
  }
  if (line) lines.push(line);
  return lines;
}
function toSrt(segments) {
  return segments.map((s, i) => `${i + 1}
${formatSrtTime(s.start)} --> ${formatSrtTime(s.end)}
${(s.lines ?? [s.text]).join("\n")}`).join("\n\n") + "\n";
}
function toVtt(segments) {
  const body = segments.map((s) => `${formatVttTime(s.start)} --> ${formatVttTime(s.end)}
${(s.lines ?? [s.text]).join("\n")}`).join("\n\n");
  return `WEBVTT

${body}
`;
}

// core/ass.js
var ASS_STYLES = {
  klasik: {
    label: "Klasik",
    shadowOpacity: 0.7,
    font: "Montserrat Bold",
    size: 0.056,
    color: "#FFFFFF",
    outlineColor: "#000000",
    outline: 28e-4,
    shadow: 35e-4,
    position: "bottom",
    margin: 0.075,
    animation: "fade",
    words: 0,
    upper: false
  },
  vurgu: {
    label: "Vurgu",
    activePop: true,
    shadowOpacity: 0.7,
    font: "Montserrat ExtraBold",
    size: 0.082,
    color: "#FFFFFF",
    highlightColor: "#FFE14A",
    outlineColor: "#000000",
    outline: 42e-4,
    shadow: 4e-3,
    position: "middle-low",
    margin: 0.24,
    animation: "highlight",
    popScale: 112,
    words: 3,
    upper: true
  },
  renkli: {
    label: "Renkli",
    activePop: true,
    shadowOpacity: 0.7,
    font: "Montserrat Black",
    size: 0.09,
    color: "#FFFFFF",
    highlightColor: "#4ADE80",
    colorCycle: ["#4ADE80", "#FFE14A", "#F472B6", "#38BDF8"],
    outlineColor: "#000000",
    outline: 45e-4,
    shadow: 4e-3,
    position: "middle-low",
    margin: 0.25,
    animation: "highlight",
    popScale: 114,
    words: 2,
    upper: true
  },
  // Söylenen kelimeler renklenir; henüz söylenmeyenler soluk kalır
  karaoke: {
    label: "Karaoke",
    font: "Poppins ExtraBold",
    size: 0.082,
    color: "#FFFFFF",
    highlightColor: "#FFE14A",
    inactiveOpacity: 0.55,
    outlineColor: "#000000",
    outline: 42e-4,
    shadow: 35e-4,
    position: "middle-low",
    margin: 0.24,
    animation: "karaoke",
    words: 4,
    upper: true
  },
  pop: {
    label: "Pop",
    shadowOpacity: 0.7,
    font: "Anton",
    size: 0.12,
    color: "#FFFFFF",
    outlineColor: "#000000",
    outline: 45e-4,
    shadow: 5e-3,
    position: "middle",
    margin: 0,
    animation: "pop",
    words: 1,
    upper: true
  },
  // Beyaz yazı, arkasında renkli parlama; söylenen kelime parlamanın rengini alır
  neon: {
    label: "Neon",
    font: "Poppins",
    bold: true,
    size: 0.085,
    color: "#FFFFFF",
    highlightColor: "#F472B6",
    outlineColor: "#F472B6",
    outline: 0,
    glow: 6,
    shadow: 0,
    position: "middle-low",
    margin: 0.24,
    animation: "highlight",
    popScale: 108,
    words: 3,
    upper: true
  },
  kutu: {
    label: "Kutu",
    font: "Poppins",
    bold: true,
    size: 0.052,
    color: "#FFFFFF",
    boxColor: "#000000B8",
    outline: 0.012,
    shadow: 0,
    position: "bottom",
    margin: 0.08,
    animation: "pop",
    box: true,
    words: 0,
    upper: false
  },
  minimal: {
    label: "Minimal",
    shadowOpacity: 0.75,
    font: "Poppins",
    bold: true,
    size: 0.046,
    color: "#FFFFFF",
    outlineColor: "#000000",
    outline: 0,
    shadow: 3e-3,
    position: "bottom",
    margin: 0.07,
    animation: "fade",
    words: 0,
    upper: false
  },
  sinema: {
    label: "Sinema",
    shadowOpacity: 0.75,
    font: "Bebas Neue",
    size: 0.074,
    spacing: 3e-3,
    color: "#F5F5F5",
    outlineColor: "#000000",
    outline: 0,
    shadow: 35e-4,
    position: "bottom",
    margin: 0.09,
    animation: "fade",
    words: 0,
    upper: true
  },
  // Söylenen kelimenin arkasında hafif eğik sarı kutu; kutu kelimeden kelimeye kayar
  kututakip: {
    label: "Kutu takip",
    font: "Poppins ExtraBold",
    size: 0.095,
    color: "#FFFFFF",
    outlineColor: "#000000",
    outline: 26e-4,
    shadow: 45e-4,
    shadowOpacity: 0.75,
    position: "middle-low",
    margin: 0.2,
    animation: "highlight",
    activeMode: "box",
    boxColor: "#FFE14A",
    boxTextColor: "#14101C",
    boxTilt: 2,
    boxScale: 106,
    boxRadius: 0.18,
    popScale: 100,
    words: 3,
    lines: 1,
    upper: true
  },
  // Kutu her kelimede zıplayarak gelir
  kutupop: {
    label: "Kutu pop",
    font: "Montserrat ExtraBold",
    size: 0.09,
    color: "#FFFFFF",
    outlineColor: "#000000",
    outline: 26e-4,
    shadow: 45e-4,
    shadowOpacity: 0.7,
    position: "middle-low",
    margin: 0.22,
    animation: "highlight",
    activeMode: "box",
    boxColor: "#4ADE80",
    boxTextColor: "#0B1F12",
    boxTilt: 2,
    boxScale: 106,
    popScale: 100,
    activePop: true,
    words: 3,
    lines: 1,
    upper: true
  },
  // Büyük ve kalın; söylenen kelime renklenip öne fırlar
  viral: {
    label: "Viral",
    shadowOpacity: 0.75,
    font: "Poppins ExtraBold",
    size: 0.1,
    color: "#FFFFFF",
    highlightColor: "#FFE14A",
    outlineColor: "#000000",
    outline: 5e-3,
    shadow: 45e-4,
    position: "middle",
    margin: 0,
    animation: "highlight",
    popScale: 122,
    activePop: true,
    words: 2,
    upper: true
  },
  // Her kelime tek başına, ekranın ortasında
  tekkelime: {
    label: "Tek kelime",
    shadowOpacity: 0.75,
    font: "Poppins ExtraBold",
    size: 0.14,
    color: "#FFE14A",
    outlineColor: "#000000",
    outline: 5e-3,
    shadow: 5e-3,
    position: "middle",
    margin: 0,
    animation: "pop",
    words: 1,
    upper: true
  },
  // Yuvarlak köşeli koyu şerit üzerinde sade yazı; söylenen kelime renklenir
  siyahserit: {
    label: "Siyah \u015Ferit",
    font: "Poppins SemiBold",
    size: 0.056,
    color: "#FFFFFF",
    highlightColor: "#FFE14A",
    boxColor: "#000000B4",
    outline: 0.014,
    shadow: 0,
    position: "middle-low",
    margin: 0.22,
    animation: "highlight",
    box: true,
    words: 4,
    upper: false
  }
};
var ALIASES = { vurgulu: "vurgu", kutulu: "kutu" };
function toAssColor(hex) {
  const m2 = /^#?([0-9a-f]{6})([0-9a-f]{2})?$/i.exec(String(hex).trim());
  if (!m2) throw new Error(`Ge\xE7ersiz renk: ${hex}`);
  const rr = m2[1].slice(0, 2);
  const gg = m2[1].slice(2, 4);
  const bb = m2[1].slice(4, 6);
  const opacity = m2[2] ? parseInt(m2[2], 16) : 255;
  const alpha = (255 - opacity).toString(16).padStart(2, "0");
  return `&H${alpha}${bb}${gg}${rr}`.toUpperCase();
}
function overrideColor(hex) {
  return `&H${toAssColor(hex).slice(4)}&`;
}
function escapeText(text) {
  return String(text).replace(/[{}]/g, "").replace(/\\/g, "/");
}
function roundedRect(w, h, r) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  const k = r * 0.4477;
  const f = (x) => Math.round(x * 10) / 10;
  return [
    `m ${f(r)} 0`,
    `l ${f(w - r)} 0`,
    `b ${f(w - k)} 0 ${f(w)} ${f(k)} ${f(w)} ${f(r)}`,
    `l ${f(w)} ${f(h - r)}`,
    `b ${f(w)} ${f(h - k)} ${f(w - k)} ${f(h)} ${f(w - r)} ${f(h)}`,
    `l ${f(r)} ${f(h)}`,
    `b ${f(k)} ${f(h)} 0 ${f(h - k)} 0 ${f(h - r)}`,
    `l 0 ${f(r)}`,
    `b 0 ${f(k)} ${f(k)} 0 ${f(r)} 0`
  ].join(" ");
}
function fitSize(segments, size, spacing, metrics, width, extra = 0) {
  let widest = 0;
  for (const seg of segments) for (const line of seg.lines ?? [seg.text]) widest = Math.max(widest, metrics.width(String(line), size, spacing));
  const room = width * 0.92 - extra;
  return widest > room ? Math.max(8, Math.floor(size * room / widest)) : size;
}
function assAlpha(opacity) {
  const a = Math.round((1 - Math.max(0, Math.min(1, opacity))) * 255);
  return `&H${a.toString(16).padStart(2, "0").toUpperCase()}&`;
}
function refSize(width, height) {
  return Math.min(height, Math.round(width * 0.9));
}
function buildBoxAss(segments, { width, height, st, metrics }) {
  var _a;
  const ref = refSize(width, height);
  const px = (ratio) => Math.max(0, Math.round(ratio * ref));
  const spacing = Math.round((st.spacing ?? 0) * ref * 10) / 10;
  const strip = Boolean(st.box);
  const nominal = px(st.size);
  const outline = strip ? 0 : px(st.outline ?? 0);
  const shadow = Math.round((st.shadow ?? 0) * ref * 10) / 10;
  const shadowOpacity = st.shadowOpacity ?? 0.45;
  const shadowLayer = !strip && shadow > 0 && shadowOpacity > 0;
  const shadowOff = Math.max(1, Math.round(shadow * 1.2));
  const margin = st.position === "middle" ? 0 : Math.round((st.margin ?? 0.07) * height);
  const cx = Math.round(width / 2);
  const back = `&H${assAlpha(shadowOpacity).slice(2, 4)}000000`;
  const tilt = st.boxTilt ? `\\frz${st.boxTilt}` : "";
  const boxScale = st.boxScale ?? 100;
  const wordBox = strip ? `\\1c${overrideColor(st.wordBoxColor ?? "#A855F7")}\\1a&H00&` : "";
  const header = [
    "[Script Info]",
    "ScriptType: v4.00+",
    `PlayResX: ${width}`,
    `PlayResY: ${height}`,
    "WrapStyle: 2",
    "ScaledBorderAndShadow: yes",
    "YCbCr Matrix: None",
    "",
    "[V4+ Styles]",
    "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
    `Style: Default,${st.font},${nominal},${toAssColor(st.color)},${toAssColor(st.color)},${toAssColor(st.outlineColor ?? "#000000")},${back},${st.bold ? -1 : 0},0,0,0,100,100,${spacing},0,1,${outline},${shadow},5,0,0,0,1`,
    `Style: Box,${st.font},${nominal},${toAssColor(st.boxColor ?? "#A855F7")},${toAssColor(st.boxColor ?? "#A855F7")},&H00000000,${back},0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1`,
    "",
    "[Events]",
    "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"
  ];
  const events = [];
  const ev = (layer, style, start, end, text) => events.push(`Dialogue: ${layer},${formatAssTime(start)},${formatAssTime(end)},${style},,0,0,0,,${text}`);
  const inactive = st.inactiveOpacity != null && st.inactiveOpacity < 1 ? `\\1a${assAlpha(st.inactiveOpacity)}` : "";
  const activeText = overrideColor(st.boxTextColor ?? "#FFFFFF");
  const highlight = st.animation === "highlight";
  const mode = highlight ? st.activeMode ?? "color" : "none";
  const cycle = ((_a = st.colorCycle) == null ? void 0 : _a.length) ? st.colorCycle : null;
  const popScale = st.popScale ?? 100;
  const glowColor = overrideColor(st.glowColor ?? st.outlineColor ?? st.highlightColor ?? "#22D3EE");
  segments.forEach((seg, segIndex) => {
    const lineWords = (seg.lines ?? [seg.text]).map((l) => l.split(" ").filter(Boolean));
    const flat = lineWords.flat();
    const words = seg.words && seg.words.length === flat.length ? seg.words : flat.map(() => null);
    const nLines = lineWords.length;
    const size = fitSize([seg], nominal, spacing, metrics, width, strip ? nominal : 0);
    const fs = size !== nominal ? `\\fs${size}` : "";
    const pitch = Math.round(size * (st.lineHeight ?? 1.08));
    const shadowBlur = Math.max(2, Math.round(size * 0.06));
    const padX = Math.round(size * (st.boxPadX ?? 0.2));
    const padY = Math.round(size * (st.boxPadY ?? 0.13));
    const radius = Math.round(size * (st.boxRadius ?? 0.2));
    const spaceW = metrics.width(" ", size, spacing) + (mode === "color" ? size * Math.max(0, popScale - 104) * 0.9 / 100 : 0);
    const baselineFromCenter = size * (metrics.ascent - (metrics.ascent + metrics.descent) / 2);
    const glowLayers = st.glow ? [
      `\\1a&HFF&\\shad0\\bord${Math.max(3, Math.round(size * 0.14))}\\3c${glowColor}\\3a&H9C&\\blur${Math.round(size * 0.22)}`,
      `\\1a&HFF&\\shad0\\bord${Math.max(2, Math.round(size * 0.045))}\\3c${glowColor}\\3a&H48&\\blur${Math.max(2, Math.round(size * 0.07))}`
    ] : null;
    const block = nLines * pitch;
    let firstCenter;
    if (st.position === "top") firstCenter = margin + pitch / 2;
    else if (st.position === "middle") firstCenter = height / 2 - block / 2 + pitch / 2;
    else firstCenter = height - margin - block + pitch / 2;
    const placed = [];
    lineWords.forEach((lw, li) => {
      const widths = lw.map((w) => metrics.width(w, size, spacing));
      const lineW = widths.reduce((a, b) => a + b, 0) + spaceW * Math.max(0, lw.length - 1);
      const y = Math.round(firstCenter + li * pitch);
      let x = cx - lineW / 2;
      lw.forEach((w, wi) => {
        placed.push({ text: w, line: li, x, w: widths[wi], y });
        x += widths[wi] + spaceW;
      });
    });
    const lineText = (li, activeIdx) => placed.map((p, i) => ({ ...p, i })).filter((p) => p.line === li).map((p) => p.i !== activeIdx || mode === "none" ? escapeText(p.text) : `{\\alpha&HFF&}${escapeText(p.text)}{\\alpha&H00&${inactive}}`).join(" ");
    const timed = highlight && words[0] != null;
    const spans = timed ? words.map((w, k) => ({ k, start: k === 0 ? seg.start : w.start, end: k + 1 < words.length ? words[k + 1].start : seg.end })) : [{ k: -1, start: seg.start, end: seg.end }];
    spans.forEach(({ k, start, end }, n) => {
      if (end - start <= 5e-3) return;
      let intro = n === 0 ? "\\fad(70,0)" : "";
      if (n === 0 && st.animation === "pop") intro = "\\fad(40,0)\\fscx70\\fscy70\\t(0,100,\\fscx106\\fscy106)\\t(100,170,\\fscx100\\fscy100)";
      if (n === 0 && st.animation === "fade") intro = "\\fad(120,0)";
      const outro = n === spans.length - 1 ? `\\fad(0,${st.animation === "fade" ? 100 : 60})` : "";
      if (strip) {
        const lineW = (li) => {
          const ps = placed.filter((q) => q.line === li);
          return ps[ps.length - 1].x + ps[ps.length - 1].w - ps[0].x;
        };
        const sw = Math.round(Math.max(...lineWords.map((_, li) => lineW(li))) + size * 1.04);
        const sh = Math.round(nLines * pitch + size * 0.46);
        const sy = Math.round(firstCenter + (nLines - 1) * pitch / 2 + size * ((metrics.ascent - metrics.descent) / 2 - metrics.capHeight / 2 + 0.05));
        ev(0, "Box", start, end, `{\\an5\\pos(${cx},${sy})${intro}${outro}\\p1}${roundedRect(sw, sh, Math.round(size * 0.4))}{\\p0}`);
      }
      for (let li = 0; li < nLines; li++) {
        const y = placed.find((p2) => p2.line === li).y;
        const whole = escapeText(lineWords[li].join(" "));
        if (glowLayers) for (const g of glowLayers) ev(0, "Default", start, end, `{\\an5\\pos(${cx},${y})${g}${fs}${intro}${outro}}${whole}`);
        else if (shadowLayer) ev(0, "Default", start, end, `{\\an5\\pos(${cx},${y + shadowOff})\\1a&HFF&\\shad0\\bord${shadowBlur}\\3c&H000000&\\3a${assAlpha(shadowOpacity * 0.55)}\\blur${shadowBlur}${fs}${intro}${outro}}${whole}`);
        ev(2, "Default", start, end, `{\\an5\\pos(${cx},${y})\\shad0${inactive}${fs}${intro}${outro}}${lineText(li, k)}`);
      }
      if (k < 0 || mode === "none") return;
      const p = placed[k];
      const wx = Math.round(p.x + p.w / 2);
      if (mode === "color") {
        const hl = overrideColor(cycle ? cycle[(segIndex + k) % cycle.length] : st.highlightColor ?? "#FFD400");
        const grow = st.activePop ? `\\fscx82\\fscy82\\t(0,80,\\fscx${popScale + 4}\\fscy${popScale + 4})\\t(80,150,\\fscx${popScale}\\fscy${popScale})` : popScale !== 100 ? `\\t(0,70,\\fscx${popScale}\\fscy${popScale})` : "";
        const edge = st.glow ? `\\bord${Math.max(1, Math.round(size * 0.035))}\\3c&H000000&\\3a&H78&\\blur1` : "";
        ev(3, "Default", start, end, `{\\an5\\pos(${wx},${p.y})\\shad0\\c${hl}${edge}${fs}${grow}${intro}${outro}}${escapeText(p.text)}`);
        return;
      }
      const bw = Math.round(p.w + padX * 2);
      const top = p.y + baselineFromCenter - size * metrics.capHeight - padY;
      const lowerCase = p.text !== p.text.toLocaleUpperCase("tr-TR");
      const bh = Math.round(size * metrics.capHeight + padY * 2 + (lowerCase ? size * 0.07 : 0));
      const bx = Math.round(p.x - padX);
      const by = Math.round(top);
      const shape = roundedRect(bw, bh, radius);
      const prev = n > 0 ? placed[spans[n - 1].k] : null;
      const B = boxScale;
      let anim;
      let wordAnim;
      if (st.activePop) {
        const grow = `\\fscx${Math.round(B * 0.7)}\\fscy${Math.round(B * 0.7)}\\t(0,70,\\fscx${B + 8}\\fscy${B + 8})\\t(70,140,\\fscx${B}\\fscy${B})`;
        anim = `\\an5\\pos(${bx + bw / 2},${by + bh / 2})${grow}`;
        wordAnim = grow;
      } else if (prev && prev.line === p.line) {
        const pw = Math.round(prev.w + padX * 2);
        const sx = Math.round(pw / bw * B * 10) / 10;
        anim = `\\an5\\move(${Math.round(prev.x - padX + pw / 2)},${by + bh / 2},${bx + bw / 2},${by + bh / 2},0,90)\\fscy${B}\\fscx${sx}\\t(0,90,\\fscx${B})`;
        wordAnim = `\\fscx${B}\\fscy${B}`;
      } else {
        const grow = `\\fscx${Math.round(B * 0.85)}\\fscy${Math.round(B * 0.85)}\\t(0,80,\\fscx${B}\\fscy${B})`;
        anim = `\\an5\\pos(${bx + bw / 2},${by + bh / 2})${grow}`;
        wordAnim = grow;
      }
      ev(1, "Box", start, end, `{${anim}${tilt}${wordBox}${intro}${outro}\\p1}${shape}{\\p0}`);
      ev(3, "Default", start, end, `{\\an5\\pos(${wx},${p.y})\\shad0\\bord0\\c${activeText}${fs}${tilt}${wordAnim}${intro}${outro}}${escapeText(p.text)}`);
    });
  });
  return `${header.join("\n")}
${events.join("\n")}
`;
}
var ALIGN = { bottom: 2, "middle-low": 2, middle: 5, top: 8 };
function resolveStyle(style) {
  const get = (name) => ASS_STYLES[ALIASES[name] ?? name];
  if (!style) return { ...ASS_STYLES.klasik };
  if (typeof style === "string") return { ...get(style) ?? ASS_STYLES.klasik };
  const base = style.base ? get(style.base) ?? ASS_STYLES.klasik : ASS_STYLES.klasik;
  const merged = { ...base };
  for (const [k, v] of Object.entries(style)) if (v !== void 0 && v !== null && v !== "") merged[k] = v;
  return merged;
}
function buildAss(segments, { width = 1920, height = 1080, style, measure } = {}) {
  const st = resolveStyle(style);
  const fontMetrics = measure ? measure(st.font) : null;
  if (fontMetrics && st.animation !== "karaoke") return buildBoxAss(segments, { width, height, st, metrics: fontMetrics });
  const ref = refSize(width, height);
  const px = (ratio) => Math.max(0, Math.round(ratio * ref));
  const spacingPx = Math.round((st.spacing ?? 0) * ref * 10) / 10;
  const fontSize = fontMetrics ? fitSize(segments, px(st.size), spacingPx, fontMetrics, width) : px(st.size);
  const outline = st.box ? Math.max(4, px(st.outline)) : px(st.outline);
  const primary = toAssColor(st.animation === "karaoke" ? st.highlightColor ?? st.color : st.color);
  const dim = st.animation === "karaoke" && st.inactiveOpacity != null && st.inactiveOpacity < 1 && /^#[0-9a-f]{6}$/i.test(st.color);
  const secondary = toAssColor(dim ? `${st.color}${Math.round(st.inactiveOpacity * 255).toString(16).padStart(2, "0")}` : st.color);
  const outlineColor = toAssColor(st.box ? st.boxColor ?? "#000000B3" : st.outlineColor ?? "#000000");
  const shadowAlpha = Math.round(Math.max(0, Math.min(1, st.shadowOpacity ?? 0.6)) * 255).toString(16).padStart(2, "0");
  const backColor = toAssColor(st.box ? st.boxColor ?? "#000000B3" : st.shadowColor ?? `#000000${shadowAlpha}`);
  const borderStyle = st.box ? 3 : 1;
  const alignment = ALIGN[st.position] ?? 2;
  const marginV = st.position === "middle" ? 0 : Math.round((st.margin ?? 0.07) * height);
  const spacing = spacingPx;
  const header = [
    "[Script Info]",
    "ScriptType: v4.00+",
    `PlayResX: ${width}`,
    `PlayResY: ${height}`,
    "WrapStyle: 2",
    "ScaledBorderAndShadow: yes",
    "YCbCr Matrix: None",
    "",
    "[V4+ Styles]",
    "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
    `Style: Default,${st.font},${fontSize},${primary},${secondary},${outlineColor},${backColor},${st.bold ? -1 : 0},0,0,0,100,100,${spacing},0,${borderStyle},${outline},${px(st.shadow ?? 0)},${alignment},${px(0.05)},${px(0.05)},${marginV},1`,
    "",
    "[Events]",
    "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"
  ];
  const glow = st.glow ? `\\blur${st.glow}` : "";
  const events = [];
  const dialogue = (start, end, text) => events.push(`Dialogue: 0,${formatAssTime(start)},${formatAssTime(end)},Default,,0,0,0,,${glow ? `{${glow}}` : ""}${text}`);
  segments.forEach((seg, segIndex) => {
    var _a;
    const lineWords = (seg.lines ?? [seg.text]).map((l) => l.split(" ").filter(Boolean));
    const flat = lineWords.flat();
    const words = seg.words && seg.words.length === flat.length ? seg.words : null;
    const join15 = (render) => {
      let i = 0;
      return lineWords.map((lw) => lw.map((w) => render(escapeText(w), i++)).join(" ")).join("\\N");
    };
    switch (st.animation) {
      case "highlight": {
        if (!words) {
          dialogue(seg.start, seg.end, `{\\fad(80,60)}${join15((w) => w)}`);
          break;
        }
        const cycle = ((_a = st.colorCycle) == null ? void 0 : _a.length) ? st.colorCycle : null;
        const base = overrideColor(st.color);
        const scale = st.popScale ?? 100;
        const mode = st.activeMode ?? "color";
        const boxBord = Math.max(6, Math.round(fontSize * 0.2));
        const restore = `\\c${base}\\3c${overrideColor(st.outlineColor ?? "#000000")}\\bord${outline}\\shad${px(st.shadow ?? 0)}\\fscx100\\fscy100`;
        words.forEach((w, k) => {
          const start = k === 0 ? seg.start : w.start;
          const end = k + 1 < words.length ? words[k + 1].start : seg.end;
          if (end - start <= 5e-3) return;
          const hlHex = cycle ? cycle[(segIndex + k) % cycle.length] : st.highlightColor ?? "#FFD400";
          const grow = st.activePop && scale !== 100 ? `\\fscx100\\fscy100\\t(0,90,\\fscx${scale}\\fscy${scale})` : `\\fscx${scale}\\fscy${scale}`;
          let on;
          if (mode === "box") on = `\\c${overrideColor(st.boxTextColor ?? "#FFFFFF")}\\3c${overrideColor(st.boxColor ?? "#A855F7")}\\bord${boxBord}\\shad0${grow}`;
          else if (mode === "none") on = "";
          else on = `\\c${overrideColor(hlHex)}${grow}`;
          const intro = k === 0 ? "{\\fscx85\\fscy85\\t(0,90,\\fscx100\\fscy100)}" : "";
          const text = join15((t, i) => i === k && on ? `{${on}}${t}{${restore}}` : t);
          dialogue(start, end, intro + text);
        });
        break;
      }
      case "karaoke": {
        if (!words) {
          dialogue(seg.start, seg.end, join15((w) => w));
          break;
        }
        const lead = Math.max(0, Math.round((words[0].start - seg.start) * 100));
        const text = join15((t, i) => {
          const w = words[i];
          const next = i + 1 < words.length ? words[i + 1].start : seg.end;
          const cs = Math.max(1, Math.round((next - w.start) * 100));
          return `{\\kf${cs}}${t}`;
        });
        dialogue(seg.start, seg.end, (lead ? `{\\k${lead}}` : "") + text);
        break;
      }
      case "pop":
        dialogue(seg.start, seg.end, `{\\fscx70\\fscy70\\t(0,100,\\fscx106\\fscy106)\\t(100,170,\\fscx100\\fscy100)}${join15((w) => w)}`);
        break;
      case "fade":
        dialogue(seg.start, seg.end, `{\\fad(120,100)}${join15((w) => w)}`);
        break;
      default:
        dialogue(seg.start, seg.end, join15((w) => w));
    }
  });
  return `${header.join("\n")}
${events.join("\n")}
`;
}

// core/multicam.js
var DEFAULTS2 = {
  windowSec: 0.05,
  minShot: 2,
  // bir çekimin en kısa süresi (sn)
  dominanceDb: 6,
  // iki kişi aynı anda konuşuyorsa baskınlık farkı
  overlapToWide: true,
  // eşit seviyede üst üste konuşmada geniş plan
  silenceToWide: 0,
  // bu süreden uzun sessizlikte geniş plana geç (0 = kapalı)
  lead: 0.15,
  // geçişi konuşmadan biraz önce yap (sn)
  maxShot: 0,
  // tek çekim bu süreyi aşarsa araya geniş plan koy (0 = kapalı)
  cutawayLength: 2.5,
  minSilence: 0.35,
  minSpeech: 0.25
};
function planMulticam(speakers, options = {}) {
  var _a;
  const opts = { ...DEFAULTS2, ...options };
  const { windowSec } = opts;
  if (!speakers.length) throw new Error("En az bir konu\u015Fmac\u0131 gerekli");
  const frames = Math.max(...speakers.map((s) => s.env.length));
  const duration = opts.duration ?? frames * windowSec;
  const wide = opts.wideCamera ?? null;
  const thresholds = {};
  const active = speakers.map((sp) => {
    const threshold = sp.threshold ?? autoThreshold(sp.env).threshold;
    thresholds[sp.id] = threshold;
    const arr = new Uint8Array(frames);
    for (const [s, e] of activeRegions(sp.env, {
      windowSec,
      threshold,
      minSilence: opts.minSilence,
      minSpeech: opts.minSpeech
    })) {
      for (let i = Math.floor(s / windowSec); i < Math.min(frames, Math.ceil(e / windowSec)); i++) arr[i] = 1;
    }
    return arr;
  });
  const labels = new Array(frames);
  for (let t = 0; t < frames; t++) {
    const on = [];
    speakers.forEach((sp, i) => {
      if (active[i][t]) on.push({ sp, level: sp.env[t] ?? -100 });
    });
    if (on.length === 0) labels[t] = "none";
    else if (on.length === 1) labels[t] = on[0].sp.camera;
    else {
      on.sort((a, b) => b.level - a.level);
      labels[t] = on[0].level - on[1].level >= opts.dominanceDb ? on[0].sp.camera : "overlap";
    }
  }
  let runs = [];
  for (let t = 0; t < frames; t++) {
    const last = runs[runs.length - 1];
    if (last && last.label === labels[t]) last.end = t + 1;
    else runs.push({ label: labels[t], start: t, end: t + 1 });
  }
  const firstCam = ((_a = runs.find((r) => r.label !== "none" && r.label !== "overlap")) == null ? void 0 : _a.label) ?? wide ?? speakers[0].camera;
  let prevCam = null;
  for (const r of runs) {
    const len = (r.end - r.start) * windowSec;
    if (r.label === "overlap") r.camera = wide && opts.overlapToWide ? wide : prevCam ?? firstCam;
    else if (r.label === "none") r.camera = wide && opts.silenceToWide > 0 && len >= opts.silenceToWide ? wide : prevCam ?? firstCam;
    else r.camera = r.label;
    prevCam = r.camera;
  }
  runs = mergeSameCamera(runs);
  const minFrames = Math.max(1, Math.round(opts.minShot / windowSec));
  for (; ; ) {
    let idx = -1;
    let shortest = Infinity;
    runs.forEach((r2, i) => {
      const len = r2.end - r2.start;
      if (len < minFrames && len < shortest && runs.length > 1) {
        shortest = len;
        idx = i;
      }
    });
    if (idx < 0) break;
    const r = runs[idx];
    const prev = runs[idx - 1];
    const next = runs[idx + 1];
    if (!prev) next.start = r.start;
    else if (!next || prev.camera === next.camera) prev.end = r.end;
    else if (prev.end - prev.start >= next.end - next.start) prev.end = r.end;
    else next.start = r.start;
    runs.splice(idx, 1);
    runs = mergeSameCamera(runs);
  }
  if (wide && opts.maxShot > 0) {
    const maxFrames = Math.round(opts.maxShot / windowSec);
    const cutFrames = Math.round(opts.cutawayLength / windowSec);
    const out = [];
    for (const r of runs) {
      const len = r.end - r.start;
      if (r.camera !== wide && len > maxFrames && len - cutFrames >= 2 * minFrames) {
        const mid = r.start + Math.floor((len - cutFrames) / 2);
        out.push({ ...r, end: mid }, { camera: wide, start: mid, end: mid + cutFrames }, { ...r, start: mid + cutFrames });
      } else out.push(r);
    }
    runs = out;
  }
  const leadFrames = Math.round(opts.lead / windowSec);
  for (let i = 1; i < runs.length && leadFrames > 0; i++) {
    const prev = runs[i - 1];
    const shift = Math.min(leadFrames, Math.max(0, prev.end - prev.start - minFrames));
    prev.end -= shift;
    runs[i].start -= shift;
  }
  const segments = runs.map((r, i) => ({
    start: r.start * windowSec,
    end: i === runs.length - 1 ? duration : r.end * windowSec,
    camera: r.camera
  }));
  if (segments.length) segments[0].start = 0;
  const stats = {};
  for (const s of segments) stats[s.camera] = (stats[s.camera] ?? 0) + (s.end - s.start);
  return { segments, duration, stats, thresholds, cuts: Math.max(0, segments.length - 1) };
}
function mergeSameCamera(runs) {
  const out = [];
  for (const r of runs) {
    const last = out[out.length - 1];
    if (last && last.camera === r.camera) last.end = r.end;
    else out.push({ ...r });
  }
  return out;
}

// core/xml.js
var ENTITY = { lt: "<", gt: ">", amp: "&", quot: '"', apos: "'" };
function decodeEntities(text) {
  if (!text.includes("&")) return text;
  return text.replace(/&(#x[0-9a-fA-F]+|#\d+|[a-zA-Z]+);/g, (m2, code) => {
    if (code[0] === "#") {
      const n = code[1] === "x" || code[1] === "X" ? parseInt(code.slice(2), 16) : parseInt(code.slice(1), 10);
      return Number.isFinite(n) ? String.fromCodePoint(n) : m2;
    }
    return ENTITY[code] ?? m2;
  });
}
function encodeText(text) {
  return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function encodeAttr(text) {
  return encodeText(text).replace(/"/g, "&quot;");
}
function parseXml(source) {
  const src = String(source).replace(/^﻿/, "");
  const doc = { type: "doc", children: [] };
  const stack = [doc];
  let i = 0;
  const top = () => stack[stack.length - 1];
  const fail = (msg) => {
    const line = src.slice(0, i).split("\n").length;
    throw new Error(`XML hatas\u0131 (sat\u0131r ${line}): ${msg}`);
  };
  while (i < src.length) {
    const lt = src.indexOf("<", i);
    if (lt < 0) {
      top().children.push({ type: "text", value: decodeEntities(src.slice(i)) });
      break;
    }
    if (lt > i) top().children.push({ type: "text", value: decodeEntities(src.slice(i, lt)) });
    i = lt;
    if (src.startsWith("<!--", i)) {
      const end = src.indexOf("-->", i + 4);
      if (end < 0) fail("kapanmam\u0131\u015F yorum");
      top().children.push({ type: "comment", value: src.slice(i + 4, end) });
      i = end + 3;
    } else if (src.startsWith("<![CDATA[", i)) {
      const end = src.indexOf("]]>", i + 9);
      if (end < 0) fail("kapanmam\u0131\u015F CDATA");
      top().children.push({ type: "cdata", value: src.slice(i + 9, end) });
      i = end + 3;
    } else if (src.startsWith("<?", i)) {
      const end = src.indexOf("?>", i + 2);
      if (end < 0) fail("kapanmam\u0131\u015F i\u015Flem talimat\u0131");
      top().children.push({ type: "pi", value: src.slice(i + 2, end) });
      i = end + 2;
    } else if (src.startsWith("<!", i)) {
      let depth = 0;
      let j = i + 2;
      for (; j < src.length; j++) {
        if (src[j] === "[") depth++;
        else if (src[j] === "]") depth--;
        else if (src[j] === ">" && depth <= 0) break;
      }
      top().children.push({ type: "doctype", value: src.slice(i + 2, j) });
      i = j + 1;
    } else if (src[i + 1] === "/") {
      const end = src.indexOf(">", i);
      if (end < 0) fail("kapanmam\u0131\u015F etiket");
      const name = src.slice(i + 2, end).trim();
      const node = stack.pop();
      if (!node || node.name !== name) fail(`beklenmeyen kapan\u0131\u015F </${name}>`);
      i = end + 1;
    } else {
      const m2 = /^<([A-Za-z_][\w.:-]*)/.exec(src.slice(i, i + 256));
      if (!m2) fail("ge\xE7ersiz etiket");
      const node = { type: "el", name: m2[1], attrs: {}, children: [] };
      i += m2[0].length;
      for (; ; ) {
        while (/\s/.test(src[i])) i++;
        if (src[i] === "/" && src[i + 1] === ">") {
          i += 2;
          node.selfClosing = true;
          top().children.push(node);
          break;
        }
        if (src[i] === ">") {
          i++;
          top().children.push(node);
          stack.push(node);
          break;
        }
        const am = /^([^\s=/>]+)\s*=\s*("([^"]*)"|'([^']*)')/.exec(src.slice(i, i + 4096));
        if (!am) fail(`ge\xE7ersiz \xF6znitelik <${node.name}>`);
        node.attrs[am[1]] = decodeEntities(am[3] ?? am[4]);
        i += am[0].length;
      }
    }
  }
  if (stack.length !== 1) fail(`kapanmam\u0131\u015F \xF6\u011Fe <${top().name}>`);
  return doc;
}
function serializeXml(node) {
  switch (node.type) {
    case "doc":
      return node.children.map(serializeXml).join("");
    case "text":
      return encodeText(node.value);
    case "comment":
      return `<!--${node.value}-->`;
    case "cdata":
      return `<![CDATA[${node.value}]]>`;
    case "pi":
      return `<?${node.value}?>`;
    case "doctype":
      return `<!${node.value}>`;
    case "el": {
      const attrs = Object.entries(node.attrs).map(([k, v]) => ` ${k}="${encodeAttr(v)}"`).join("");
      if (!node.children.length && node.selfClosing) return `<${node.name}${attrs}/>`;
      return `<${node.name}${attrs}>${node.children.map(serializeXml).join("")}</${node.name}>`;
    }
    default:
      throw new Error(`Bilinmeyen d\xFC\u011F\xFCm: ${node.type}`);
  }
}
function elements(node, name) {
  return ((node == null ? void 0 : node.children) ?? []).filter((c) => c.type === "el" && (name == null || c.name === name));
}
function child(node, name) {
  return ((node == null ? void 0 : node.children) ?? []).find((c) => c.type === "el" && c.name === name) ?? null;
}
function childPath(node, path) {
  let cur = node;
  for (const part of path.split("/")) {
    cur = child(cur, part);
    if (!cur) return null;
  }
  return cur;
}
function textOf(node) {
  if (!node) return "";
  return node.children.map((c) => c.type === "text" || c.type === "cdata" ? c.value : c.type === "el" ? textOf(c) : "").join("");
}
function childText(node, path, fallback = null) {
  const el = childPath(node, path);
  return el ? textOf(el).trim() : fallback;
}
function setText(node, value) {
  node.children = [{ type: "text", value: String(value) }];
  node.selfClosing = false;
}
function setChildText(node, name, value) {
  let el = child(node, name);
  if (!el) {
    el = createElement(name);
    node.children.push(el);
  }
  setText(el, value);
  return el;
}
function createElement(name, attrs = {}, children = []) {
  return {
    type: "el",
    name,
    attrs: { ...attrs },
    children: children.map((c) => typeof c === "string" ? { type: "text", value: c } : c)
  };
}
function cloneNode(node) {
  if (node.type !== "el" && node.type !== "doc") return { ...node };
  const copy = { ...node, children: node.children.map(cloneNode) };
  if (node.attrs) copy.attrs = { ...node.attrs };
  return copy;
}

// core/xmeml.js
var PPRO_TICKS_PER_SECOND = 254016e6;
var ITEM_TYPES = /* @__PURE__ */ new Set(["clipitem", "generatoritem"]);
function pathFromUrl(url) {
  if (!url) return null;
  let p = String(url).trim();
  p = p.replace(/^file:\/\/localhost/i, "").replace(/^file:\/\//i, "");
  try {
    p = decodeURIComponent(p);
  } catch {
  }
  if (/^\/[A-Za-z]:[\\/]/.test(p)) p = p.slice(1).replace(/\//g, "\\");
  else if (/^[A-Za-z]:\//.test(p)) p = p.replace(/\//g, "\\");
  return p;
}
function urlFromPath(path) {
  const win = /^[A-Za-z]:[\\/]/.test(path);
  const parts = path.replace(/\\/g, "/").split("/");
  const encoded = parts.map((seg, i) => win && i === 0 ? seg.replace(":", "%3a") : encodeURIComponent(seg)).join("/");
  return `file://localhost${win ? "/" : ""}${encoded}`;
}
function readRate(el) {
  const rate = child(el, "rate");
  if (!rate) return null;
  const timebase = Number(childText(rate, "timebase", "0"));
  const ntsc = /^true$/i.test(childText(rate, "ntsc", "FALSE"));
  return { timebase, ntsc, fps: fpsFromRate(timebase, ntsc) };
}
function num(el, name, fallback = 0) {
  const t = childText(el, name);
  if (t == null || t === "") return fallback;
  const n = Number(t);
  return Number.isFinite(n) ? n : fallback;
}
function findSequence(doc) {
  const root = elements(doc, "xmeml")[0];
  if (!root) throw new Error("Bu dosya FCP 7 XML (xmeml) de\u011Fil");
  const direct = elements(root, "sequence")[0];
  if (direct) return { root, sequence: direct };
  const stack = [...elements(root)];
  while (stack.length) {
    const el = stack.shift();
    if (el.name === "sequence") return { root, sequence: el };
    stack.push(...elements(el));
  }
  throw new Error("XML i\xE7inde sekans bulunamad\u0131");
}
function readTimeline(xmlText) {
  const doc = parseXml(xmlText);
  const { root, sequence } = findSequence(doc);
  const rate = readRate(sequence) ?? { timebase: 25, ntsc: false, fps: 25 };
  const media = child(sequence, "media");
  const videoEl = child(media, "video");
  const audioEl = child(media, "audio");
  const files = /* @__PURE__ */ new Map();
  const tl = {
    doc,
    root,
    sequence,
    name: childText(sequence, "name", "Sekans"),
    rate,
    fps: rate.fps,
    duration: num(sequence, "duration", 0),
    width: Number(childText(videoEl, "format/samplecharacteristics/width", "1920")),
    height: Number(childText(videoEl, "format/samplecharacteristics/height", "1080")),
    startFrame: Number(childText(sequence, "timecode/frame", "0")) || 0,
    video: [],
    audio: [],
    files,
    transitions: 0
  };
  const readTracks = (mediaEl, kind) => elements(mediaEl, "track").map((trackEl, ti) => {
    const track = { el: trackEl, kind, index: ti + 1, items: [], attrs: trackEl.attrs };
    for (const itemEl of elements(trackEl)) {
      if (itemEl.name === "transitionitem") {
        tl.transitions++;
        continue;
      }
      if (!ITEM_TYPES.has(itemEl.name)) continue;
      const fileEl = child(itemEl, "file");
      const fileId2 = (fileEl == null ? void 0 : fileEl.attrs.id) ?? null;
      if (fileEl && fileId2 && elements(fileEl).length && !files.has(fileId2)) {
        files.set(fileId2, {
          el: fileEl,
          id: fileId2,
          name: childText(fileEl, "name"),
          path: pathFromUrl(childText(fileEl, "pathurl")),
          rate: readRate(fileEl),
          duration: num(fileEl, "duration", 0),
          channels: Number(childText(fileEl, "media/audio/channelcount", "0")) || null,
          width: Number(childText(fileEl, "media/video/samplecharacteristics/width", "0")) || null,
          height: Number(childText(fileEl, "media/video/samplecharacteristics/height", "0")) || null
        });
      }
      const itemRate = readRate(itemEl) ?? rate;
      track.items.push({
        el: itemEl,
        kind: itemEl.name,
        id: itemEl.attrs.id ?? null,
        name: childText(itemEl, "name", ""),
        enabled: !/^false$/i.test(childText(itemEl, "enabled", "TRUE")),
        start: num(itemEl, "start", 0),
        end: num(itemEl, "end", 0),
        in: num(itemEl, "in", 0),
        out: num(itemEl, "out", 0),
        rate: itemRate,
        fileId: fileId2,
        sourceTrack: Number(childText(itemEl, "sourcetrack/trackindex", "1")) || 1,
        track
      });
    }
    return track;
  });
  tl.video = videoEl ? readTracks(videoEl, "video") : [];
  tl.audio = audioEl ? readTracks(audioEl, "audio") : [];
  for (const t of [...tl.video, ...tl.audio]) resolveTrackTimes(t, rate.fps);
  const maxEnd = Math.max(0, ...[...tl.video, ...tl.audio].flatMap((t) => t.items.map((i) => i.end)));
  if (!tl.duration || tl.duration < maxEnd) tl.duration = maxEnd;
  return tl;
}
function resolveTrackTimes(track, seqFps) {
  const items = track.items;
  items.forEach((it, i) => {
    const len = Math.round((it.out - it.in) * seqFps / it.rate.fps);
    if (it.start < 0 && it.end >= 0) it.start = it.end - len;
    if (it.end < 0 && it.start >= 0) it.end = it.start + len;
    if (it.start < 0 && it.end < 0) {
      const prev = items[i - 1];
      it.start = prev && prev.end >= 0 ? prev.end : 0;
      it.end = it.start + len;
    }
  });
}
function audioTrackSources(tl, trackIndex) {
  var _a;
  const track = tl.audio[trackIndex - 1];
  if (!track) throw new Error(`Ses par\xE7as\u0131 A${trackIndex} bulunamad\u0131`);
  const stereo = /stereo/i.test(((_a = track.attrs) == null ? void 0 : _a.premiereTrackType) ?? "");
  return track.items.filter((it) => {
    var _a2;
    return it.kind === "clipitem" && it.enabled && it.fileId && ((_a2 = tl.files.get(it.fileId)) == null ? void 0 : _a2.path);
  }).map((it) => {
    const file = tl.files.get(it.fileId);
    const channels = file.channels ?? 0;
    return {
      path: file.path,
      // Stereo parçada tüm kanallar karışır; aksi halde sourcetrack numarası kanalı belirtir.
      channel: !stereo && channels > 1 && it.sourceTrack <= channels ? it.sourceTrack - 1 : null,
      timelineStart: it.start / tl.fps,
      timelineEnd: it.end / tl.fps,
      sourceIn: it.in / it.rate.fps,
      sourceOut: it.out / it.rate.fps
    };
  });
}
function describeTimeline(tl) {
  const describeTrack = (t) => ({
    index: t.index,
    items: t.items.length,
    files: [...new Set(t.items.map((i) => {
      var _a;
      return (_a = tl.files.get(i.fileId)) == null ? void 0 : _a.name;
    }).filter(Boolean))],
    // Arayüzdeki küçük zaman çizelgesi için (en fazla 400 klip)
    clips: t.items.slice(0, 400).map((i) => {
      var _a;
      return {
        name: i.name || ((_a = tl.files.get(i.fileId)) == null ? void 0 : _a.name) || "",
        start: Math.round(i.start / tl.fps * 100) / 100,
        end: Math.round(i.end / tl.fps * 100) / 100,
        enabled: i.enabled
      };
    })
  });
  return {
    name: tl.name,
    fps: Math.round(tl.fps * 1e3) / 1e3,
    width: tl.width,
    height: tl.height,
    duration: tl.duration / tl.fps,
    video: tl.video.map(describeTrack),
    audio: tl.audio.map(describeTrack),
    transitions: tl.transitions
  };
}
function setNum(el, name, value) {
  const c = child(el, name);
  if (c) setChildText(el, name, String(Math.round(value)));
}
function ticksPerFrame(rate) {
  return Math.round(PPRO_TICKS_PER_SECOND / rate.fps);
}
function rebuildTrack(track, pieceFn, idMap, decorate) {
  const out = [];
  for (const node of track.el.children) {
    if (node.type !== "el" || !ITEM_TYPES.has(node.name)) {
      if (node.type === "el" && node.name === "transitionitem" && track.dropTransitions) continue;
      out.push(node);
      continue;
    }
    const item = track.items.find((i) => i.el === node);
    const pieces = item ? pieceFn(item) : null;
    if (pieces == null) {
      out.push(node);
      continue;
    }
    pieces.forEach((p) => {
      const el = cloneNode(node);
      const newId = `${item.id}-k${p.key}`;
      if (item.id) el.attrs.id = newId;
      idMap.set(`${item.id}|${p.key}`, newId);
      const ratio = (item.out - item.in) / Math.max(1, item.end - item.start);
      const srcIn = Math.round(item.in + (p.srcStart - item.start) * ratio);
      const srcOut = Math.round(srcIn + (p.end - p.start) * ratio);
      setNum(el, "start", p.start);
      setNum(el, "end", p.end);
      setNum(el, "in", srcIn);
      setNum(el, "out", srcOut);
      const tpf = ticksPerFrame(item.rate);
      if (child(el, "pproTicksIn")) setChildText(el, "pproTicksIn", String(srcIn * tpf));
      if (child(el, "pproTicksOut")) setChildText(el, "pproTicksOut", String(srcOut * tpf));
      if (p.enabled === false) setChildText(el, "enabled", "FALSE");
      decorate == null ? void 0 : decorate(el, p, item);
      el.__key = p.key;
      el.__origId = item.id;
      out.push(el);
    });
  }
  track.el.children = tidyWhitespace(out);
}
function tidyWhitespace(nodes) {
  const out = [];
  for (const n of nodes) {
    const prev = out[out.length - 1];
    if (n.type === "text" && !n.value.trim() && (prev == null ? void 0 : prev.type) === "text" && !prev.value.trim()) continue;
    if (n.type === "el" && (prev == null ? void 0 : prev.type) === "el") out.push({ type: "text", value: "\n" });
    out.push(n);
  }
  return out;
}
function finalizeTimeline(tl, idMap, extra = {}) {
  const positions = /* @__PURE__ */ new Map();
  const allIds = /* @__PURE__ */ new Set();
  for (const kind of ["video", "audio"]) {
    elements(child(child(tl.sequence, "media"), kind), "track").forEach((trackEl, ti) => {
      let ci = 0;
      for (const el of elements(trackEl)) {
        if (!ITEM_TYPES.has(el.name)) continue;
        ci++;
        if (el.attrs.id) {
          positions.set(el.attrs.id, { kind, trackIndex: ti + 1, clipIndex: ci });
          allIds.add(el.attrs.id);
        }
      }
    });
  }
  const seenFiles = /* @__PURE__ */ new Set();
  const visit = (el) => {
    for (const link of elements(el, "link")) {
      const ref = childText(link, "linkclipref");
      let target = null;
      if (el.__key != null) target = idMap.get(`${ref}|${el.__key}`) ?? null;
      else if (allIds.has(ref)) target = ref;
      if (!target) {
        el.children.splice(el.children.indexOf(link), 1);
        continue;
      }
      setChildText(link, "linkclipref", target);
      const pos = positions.get(target);
      if (pos) {
        if (child(link, "trackindex")) setChildText(link, "trackindex", String(pos.trackIndex));
        if (child(link, "clipindex")) setChildText(link, "clipindex", String(pos.clipIndex));
      }
    }
    const links = elements(el, "link");
    if (links.length === 1 && childText(links[0], "linkclipref") === el.attrs.id) {
      el.children.splice(el.children.indexOf(links[0]), 1);
    }
    const fileEl = child(el, "file");
    if (fileEl == null ? void 0 : fileEl.attrs.id) {
      const id = fileEl.attrs.id;
      const def = tl.files.get(id);
      if (!seenFiles.has(id)) {
        seenFiles.add(id);
        if (def && !elements(fileEl).length) el.children[el.children.indexOf(fileEl)] = cloneNode(def.el);
      } else if (elements(fileEl).length) {
        el.children[el.children.indexOf(fileEl)] = createElement("file", { id });
      }
    }
    delete el.__key;
    delete el.__origId;
  };
  for (const kind of ["video", "audio"]) {
    for (const trackEl of elements(child(child(tl.sequence, "media"), kind), "track")) {
      for (const el of elements(trackEl)) if (ITEM_TYPES.has(el.name)) visit(el);
    }
  }
  let maxEnd = 0;
  for (const kind of ["video", "audio"]) {
    for (const trackEl of elements(child(child(tl.sequence, "media"), kind), "track")) {
      for (const el of elements(trackEl)) if (ITEM_TYPES.has(el.name)) maxEnd = Math.max(maxEnd, Number(childText(el, "end", "0")));
    }
  }
  setChildText(tl.sequence, "duration", String(maxEnd));
  tl.duration = maxEnd;
  if (extra.name) setChildText(tl.sequence, "name", extra.name);
  const uuid = child(tl.sequence, "uuid");
  if (uuid) tl.sequence.children.splice(tl.sequence.children.indexOf(uuid), 1);
  if (tl.sequence.attrs.id) tl.sequence.attrs.id = `${tl.sequence.attrs.id}-makas`;
}
function applyScale(clipEl, percent) {
  for (const filter2 of elements(clipEl, "filter")) {
    const effect = child(filter2, "effect");
    if (childText(effect, "effectid") !== "basic") continue;
    for (const param2 of elements(effect, "parameter")) {
      if (childText(param2, "parameterid") === "scale") {
        const current = Number(childText(param2, "value", "100")) || 100;
        setChildText(param2, "value", String(Math.round(current * (percent / 100) * 100) / 100));
        return;
      }
    }
  }
  const param = createElement("parameter", { authoringApp: "PremierePro" }, [
    createElement("parameterid", {}, ["scale"]),
    createElement("name", {}, ["Scale"]),
    createElement("valuemin", {}, ["0"]),
    createElement("valuemax", {}, ["1000"]),
    createElement("value", {}, [String(percent)])
  ]);
  const filter = createElement("filter", {}, [
    createElement("effect", {}, [
      createElement("name", {}, ["Basic Motion"]),
      createElement("effectid", {}, ["basic"]),
      createElement("effectcategory", {}, ["motion"]),
      createElement("effecttype", {}, ["motion"]),
      createElement("mediatype", {}, ["video"]),
      param
    ])
  ]);
  const linkIdx = clipEl.children.findIndex((c) => c.type === "el" && (c.name === "link" || c.name === "logginginfo" || c.name === "labels"));
  if (linkIdx >= 0) clipEl.children.splice(linkIdx, 0, filter);
  else clipEl.children.push(filter);
}
function clipScale(clipEl) {
  for (const filter of elements(clipEl, "filter")) {
    const effect = child(filter, "effect");
    if (childText(effect, "effectid") !== "basic") continue;
    for (const param of elements(effect, "parameter")) {
      if (childText(param, "parameterid") === "scale") return Number(childText(param, "value", "100")) || 100;
    }
  }
  return 100;
}
function timelinePlan(tl) {
  const pieces = (tracks) => tracks.map(
    (t) => t.items.filter((it) => {
      var _a;
      return it.kind === "clipitem" && it.fileId && ((_a = tl.files.get(it.fileId)) == null ? void 0 : _a.path);
    }).map((it) => ({
      path: tl.files.get(it.fileId).path,
      name: it.name,
      start: it.start / tl.fps,
      end: it.end / tl.fps,
      srcIn: it.in / it.rate.fps,
      srcOut: it.out / it.rate.fps,
      enabled: it.enabled,
      scale: clipScale(it.el),
      srcWidth: tl.files.get(it.fileId).width,
      srcHeight: tl.files.get(it.fileId).height
    }))
  );
  return { name: tl.name, fps: tl.fps, width: tl.width, height: tl.height, duration: tl.duration / tl.fps, video: pieces(tl.video), audio: pieces(tl.audio) };
}
function rippleKeep(tl, keepRangesFrames, { name, zoom, split = false } = {}) {
  const rounded = keepRangesFrames.map(([s, e]) => [Math.round(s), Math.round(e)]);
  const keeps = split ? rounded.filter(([s, e]) => e > s).sort((a, b) => a[0] - b[0]) : normalizeRanges(rounded);
  const offsets = [];
  let acc = 0;
  for (const [s, e] of keeps) {
    offsets.push(acc);
    acc += e - s;
  }
  const idMap = /* @__PURE__ */ new Map();
  let removedTransitions = 0;
  const pieceFn = (item) => {
    const pieces = [];
    keeps.forEach(([ks, ke], k) => {
      const a = Math.max(item.start, ks);
      const b = Math.min(item.end, ke);
      if (b > a) pieces.push({ key: k, start: offsets[k] + (a - ks), end: offsets[k] + (b - ks), srcStart: a });
    });
    return pieces;
  };
  const zoomTracks = new Set((zoom == null ? void 0 : zoom.tracks) ?? [1]);
  const decorate = (el, piece, item) => {
    if (!(zoom == null ? void 0 : zoom.scale) || item.kind !== "clipitem" || !zoomTracks.has(item.track.index)) return;
    if (zoom.keys ? zoom.keys.has(piece.key) : piece.key % 2 === 1) applyScale(el, zoom.scale);
  };
  for (const track of [...tl.video, ...tl.audio]) {
    track.dropTransitions = true;
    removedTransitions += elements(track.el, "transitionitem").length;
    rebuildTrack(track, pieceFn, idMap, track.kind === "video" ? decorate : null);
  }
  for (const marker of elements(tl.sequence, "marker")) {
    const inF = Number(childText(marker, "in", "-1"));
    const k = keeps.findIndex(([s, e]) => inF >= s && inF < e);
    if (k < 0) tl.sequence.children.splice(tl.sequence.children.indexOf(marker), 1);
    else {
      const mapped = offsets[k] + (inF - keeps[k][0]);
      setChildText(marker, "in", String(mapped));
      const outF = Number(childText(marker, "out", "-1"));
      if (outF >= 0) setChildText(marker, "out", String(mapped + Math.max(0, outF - inF)));
    }
  }
  for (const tag of ["in", "out"]) {
    const el = child(tl.sequence, tag);
    if (el) tl.sequence.children.splice(tl.sequence.children.indexOf(el), 1);
  }
  finalizeTimeline(tl, idMap, { name: name ?? `${tl.name} - Kesilmi\u015F` });
  return { duration: acc, removedTransitions, pieces: idMap.size };
}
function applyMulticam(tl, segments, { cameraTracks, mode = "disable", name } = {}) {
  const cams = new Set(cameraTracks ?? [...new Set(segments.map((s) => Number(s.camera)))]);
  const segs = segments.map((s) => ({ start: Math.round(s.start), end: Math.round(s.end), camera: Number(s.camera) }));
  const idMap = /* @__PURE__ */ new Map();
  for (const track of tl.video) {
    if (!cams.has(track.index)) continue;
    rebuildTrack(
      track,
      (item) => {
        const pieces = [];
        segs.forEach((seg, k) => {
          const a = Math.max(item.start, seg.start);
          const b = Math.min(item.end, seg.end);
          if (b <= a) return;
          const on = seg.camera === track.index;
          if (!on && mode === "remove") return;
          pieces.push({ key: k, start: a, end: b, srcStart: a, enabled: on && item.enabled });
        });
        const covered = segs.length ? [segs[0].start, segs[segs.length - 1].end] : [0, 0];
        if (item.start < covered[0]) pieces.unshift({ key: "pre", start: item.start, end: Math.min(item.end, covered[0]), srcStart: item.start });
        if (item.end > covered[1]) pieces.push({ key: "post", start: Math.max(item.start, covered[1]), end: item.end, srcStart: Math.max(item.start, covered[1]) });
        return pieces;
      },
      idMap
    );
  }
  finalizeTimeline(tl, idMap, { name: name ?? `${tl.name} - MultiCam` });
  return { cuts: Math.max(0, segs.length - 1) };
}
function serializeTimeline(tl) {
  return serializeXml(tl.doc);
}
function buildSequenceFromMedia(media, { name } = {}) {
  var _a, _b;
  const fps = media.fps || 25;
  const { timebase, ntsc } = rateFromFps(fps);
  const frames = Math.max(1, Math.round(media.duration * fps));
  const rateEl2 = () => createElement("rate", {}, [createElement("timebase", {}, [String(timebase)]), createElement("ntsc", {}, [ntsc ? "TRUE" : "FALSE"])]);
  const seqName = name ?? media.name ?? "Sekans";
  const channels = Math.max(0, media.audioChannels || 0);
  const tpf = Math.round(PPRO_TICKS_PER_SECOND / fpsFromRate(timebase, ntsc));
  const fileMedia = createElement("media");
  if (media.hasVideo) {
    fileMedia.children.push(
      createElement("video", {}, [
        createElement("samplecharacteristics", {}, [
          rateEl2(),
          createElement("width", {}, [String(media.width || 1920)]),
          createElement("height", {}, [String(media.height || 1080)])
        ])
      ])
    );
  }
  if (channels) {
    fileMedia.children.push(
      createElement("audio", {}, [
        createElement("samplecharacteristics", {}, [
          createElement("depth", {}, ["16"]),
          createElement("samplerate", {}, [String(media.sampleRate || 48e3)])
        ]),
        createElement("channelcount", {}, [String(channels)])
      ])
    );
  }
  const fileEl = createElement("file", { id: "file-1" }, [
    createElement("name", {}, [media.name ?? "medya"]),
    createElement("pathurl", {}, [urlFromPath(media.path)]),
    rateEl2(),
    createElement("duration", {}, [String(frames)]),
    fileMedia
  ]);
  const clip = (id, mediatype, trackindex, links2, attrs = {}) => createElement("clipitem", { id, ...attrs }, [
    createElement("masterclipid", {}, ["masterclip-1"]),
    createElement("name", {}, [media.name ?? "medya"]),
    createElement("enabled", {}, ["TRUE"]),
    createElement("duration", {}, [String(frames)]),
    rateEl2(),
    createElement("start", {}, ["0"]),
    createElement("end", {}, [String(frames)]),
    createElement("in", {}, ["0"]),
    createElement("out", {}, [String(frames)]),
    createElement("pproTicksIn", {}, ["0"]),
    createElement("pproTicksOut", {}, [String(frames * tpf)]),
    createElement("file", { id: "file-1" }),
    ...mediatype === "audio" ? [createElement("sourcetrack", {}, [createElement("mediatype", {}, ["audio"]), createElement("trackindex", {}, [String(trackindex)])])] : [],
    ...links2.map(
      (l) => createElement("link", {}, [
        createElement("linkclipref", {}, [l.id]),
        createElement("mediatype", {}, [l.mediatype]),
        createElement("trackindex", {}, [String(l.track)]),
        createElement("clipindex", {}, ["1"]),
        ...l.mediatype === "audio" ? [createElement("groupindex", {}, ["1"])] : []
      ])
    )
  ]);
  const audioTracks = channels === 2 ? [{ id: "clipitem-a1", track: 1, source: 1, stereo: true }] : [];
  if (channels && channels !== 2) {
    for (let c = 1; c <= channels; c++) audioTracks.push({ id: `clipitem-a${c}`, track: c, source: c, stereo: false });
  }
  const links = [
    ...media.hasVideo ? [{ id: "clipitem-v1", mediatype: "video", track: 1 }] : [],
    ...audioTracks.map((a) => ({ id: a.id, mediatype: "audio", track: a.track }))
  ];
  const videoTracks = media.hasVideo ? [createElement("track", {}, [clip("clipitem-v1", "video", 1, links)])] : [];
  const firstClip = (_a = videoTracks[0]) == null ? void 0 : _a.children[0];
  const audioTrackEls = audioTracks.map(
    (a) => createElement("track", a.stereo ? { premiereTrackType: "Stereo" } : { premiereTrackType: "Mono" }, [
      clip(a.id, "audio", a.source, links, a.stereo ? { premiereChannelType: "stereo" } : {})
    ])
  );
  const holder = firstClip ?? ((_b = audioTrackEls[0]) == null ? void 0 : _b.children[0]);
  if (holder) holder.children[holder.children.findIndex((c) => c.name === "file")] = fileEl;
  const sequence = createElement("sequence", { id: "sequence-1" }, [
    createElement("duration", {}, [String(frames)]),
    rateEl2(),
    createElement("name", {}, [seqName]),
    createElement("media", {}, [
      createElement("video", {}, [
        createElement("format", {}, [
          createElement("samplecharacteristics", {}, [
            rateEl2(),
            createElement("width", {}, [String(media.width || 1920)]),
            createElement("height", {}, [String(media.height || 1080)]),
            createElement("pixelaspectratio", {}, ["square"])
          ])
        ]),
        ...videoTracks
      ]),
      createElement("audio", {}, [createElement("numOutputChannels", {}, ["2"]), ...audioTrackEls])
    ]),
    createElement("timecode", {}, [rateEl2(), createElement("string", {}, ["00:00:00:00"]), createElement("frame", {}, ["0"])])
  ]);
  const doc = {
    type: "doc",
    children: [
      { type: "pi", value: 'xml version="1.0" encoding="UTF-8"' },
      { type: "text", value: "\n" },
      { type: "doctype", value: "DOCTYPE xmeml" },
      { type: "text", value: "\n" },
      createElement("xmeml", { version: "4" }, [sequence]),
      { type: "text", value: "\n" }
    ]
  };
  return serializeXml(doc);
}
function buildSequenceFromClips(desc) {
  const fps = desc.fps || 25;
  const { timebase, ntsc } = rateFromFps(fps);
  const rateOf = (f) => {
    const r = rateFromFps(f || fps);
    return createElement("rate", {}, [createElement("timebase", {}, [String(r.timebase)]), createElement("ntsc", {}, [r.ntsc ? "TRUE" : "FALSE"])]);
  };
  const tpf = Math.round(PPRO_TICKS_PER_SECOND / fpsFromRate(timebase, ntsc));
  const files = new Map((desc.files ?? []).map((f) => [f.id, f]));
  const written = /* @__PURE__ */ new Set();
  let n = 0;
  const fileEl = (f) => {
    if (written.has(f.id)) return createElement("file", { id: f.id });
    written.add(f.id);
    const media = createElement("media");
    if (f.hasVideo) {
      media.children.push(
        createElement("video", {}, [
          createElement("samplecharacteristics", {}, [
            rateOf(f.fps),
            createElement("width", {}, [String(f.width || desc.width || 1920)]),
            createElement("height", {}, [String(f.height || desc.height || 1080)])
          ])
        ])
      );
    }
    if (f.audioChannels) {
      media.children.push(
        createElement("audio", {}, [
          createElement("samplecharacteristics", {}, [createElement("depth", {}, ["16"]), createElement("samplerate", {}, ["48000"])]),
          createElement("channelcount", {}, [String(f.audioChannels)])
        ])
      );
    }
    return createElement("file", { id: f.id }, [
      createElement("name", {}, [f.name ?? "medya"]),
      createElement("pathurl", {}, [urlFromPath(f.path)]),
      rateOf(f.fps),
      createElement("duration", {}, [String(Math.max(1, Math.round(f.frames || 0)))]),
      media
    ]);
  };
  const scaleFor = (f) => {
    if (!f.hasVideo || !f.width || !f.height) return 100;
    const W = desc.width || 1920;
    const H = desc.height || 1080;
    return (desc.fill ? Math.max(W / f.width, H / f.height) : Math.min(W / f.width, H / f.height)) * 100;
  };
  const clipEl = (it, kind) => {
    const f = files.get(it.fileId);
    if (!f) return null;
    const len = Math.max(1, Math.round(it.end - it.start));
    const inF = Math.max(0, Math.round((it.sourceIn || 0) * fps));
    n += 1;
    const el = createElement("clipitem", { id: `clipitem-${n}` }, [
      createElement("masterclipid", {}, [`masterclip-${f.id}`]),
      createElement("name", {}, [it.name || f.name || "klip"]),
      createElement("enabled", {}, [it.enabled === false ? "FALSE" : "TRUE"]),
      createElement("duration", {}, [String(Math.max(len + inF, Math.round((f.frames || 0) * fps / (f.fps || fps))))]),
      rateOf(fps),
      createElement("start", {}, [String(Math.round(it.start))]),
      createElement("end", {}, [String(Math.round(it.end))]),
      createElement("in", {}, [String(inF)]),
      createElement("out", {}, [String(inF + len)]),
      createElement("pproTicksIn", {}, [String(inF * tpf)]),
      createElement("pproTicksOut", {}, [String((inF + len) * tpf)]),
      fileEl(f),
      ...kind === "audio" ? [createElement("sourcetrack", {}, [createElement("mediatype", {}, ["audio"]), createElement("trackindex", {}, ["1"])])] : []
    ]);
    const sc = kind === "video" ? scaleFor(f) : 100;
    if (Math.abs(sc - 100) > 0.05) applyScale(el, Math.round(sc * 100) / 100);
    return el;
  };
  const tracks = (list, kind) => (list ?? []).map(
    (items) => createElement(
      "track",
      // Resolve ses parçaları kanalları birlikte taşır: analizde kanallar karıştırılır
      kind === "audio" ? { premiereTrackType: "Stereo" } : {},
      [...items].sort((a, b) => a.start - b.start).map((it) => clipEl(it, kind)).filter(Boolean)
    )
  );
  const duration = Math.max(1, Math.round(desc.duration || 0), ...[...desc.video ?? [], ...desc.audio ?? []].flat().map((it) => Math.round(it.end)));
  const sequence = createElement("sequence", { id: "sequence-1" }, [
    createElement("duration", {}, [String(duration)]),
    rateOf(fps),
    createElement("name", {}, [desc.name || "Sekans"]),
    createElement("media", {}, [
      createElement("video", {}, [
        createElement("format", {}, [
          createElement("samplecharacteristics", {}, [
            rateOf(fps),
            createElement("width", {}, [String(desc.width || 1920)]),
            createElement("height", {}, [String(desc.height || 1080)]),
            createElement("pixelaspectratio", {}, ["square"])
          ])
        ]),
        ...tracks(desc.video, "video")
      ]),
      createElement("audio", {}, [createElement("numOutputChannels", {}, ["2"]), ...tracks(desc.audio, "audio")])
    ]),
    createElement("timecode", {}, [rateOf(fps), createElement("string", {}, ["00:00:00:00"]), createElement("frame", {}, ["0"])])
  ]);
  return serializeXml({
    type: "doc",
    children: [
      { type: "pi", value: 'xml version="1.0" encoding="UTF-8"' },
      { type: "text", value: "\n" },
      { type: "doctype", value: "DOCTYPE xmeml" },
      { type: "text", value: "\n" },
      createElement("xmeml", { version: "4" }, [sequence]),
      { type: "text", value: "\n" }
    ]
  });
}
function makeVertical(tl, { width = 1080, height = 1920 } = {}) {
  const fmt = childPath(tl.sequence, "media/video/format/samplecharacteristics");
  if (fmt) {
    setChildText(fmt, "width", String(width));
    setChildText(fmt, "height", String(height));
  }
  const srcW = tl.width || 1920;
  const srcH = tl.height || 1080;
  for (const t of tl.video) {
    for (const it of t.items) {
      if (it.kind !== "clipitem") continue;
      const f = it.fileId ? tl.files.get(it.fileId) : null;
      const w = (f == null ? void 0 : f.width) || srcW;
      const h = (f == null ? void 0 : f.height) || srcH;
      const fill = Math.max(width / w, height / h) * 100;
      const current = clipScale(it.el) || 100;
      applyScale(it.el, fill / current * 100);
    }
  }
  tl.width = width;
  tl.height = height;
}
function rateEl(fps) {
  const r = rateFromFps(fps);
  return createElement("rate", {}, [createElement("timebase", {}, [String(r.timebase)]), createElement("ntsc", {}, [r.ntsc ? "TRUE" : "FALSE"])]);
}
function addAudioClips(tl, clips) {
  if (!clips.length) return 0;
  const audio = childPath(tl.sequence, "media/audio");
  if (!audio) return 0;
  const ids = /* @__PURE__ */ new Map();
  const items = [...clips].sort((a, b) => a.start - b.start).map((c, n) => {
    const len = Math.max(1, Math.round(c.duration * tl.fps));
    const start = Math.max(0, Math.round(c.start * tl.fps));
    let file;
    if (ids.has(c.path)) file = createElement("file", { id: ids.get(c.path) });
    else {
      const id = `file-makas-sfx-${ids.size + 1}`;
      ids.set(c.path, id);
      file = createElement("file", { id }, [
        createElement("name", {}, [c.name ?? "sfx"]),
        createElement("pathurl", {}, [urlFromPath(c.path)]),
        rateEl(tl.fps),
        createElement("duration", {}, [String(len)]),
        createElement("media", {}, [
          createElement("audio", {}, [
            createElement("samplecharacteristics", {}, [createElement("depth", {}, ["24"]), createElement("samplerate", {}, ["48000"])]),
            createElement("channelcount", {}, [String(c.channels || 2)])
          ])
        ])
      ]);
    }
    return createElement("clipitem", { id: `clipitem-makas-sfx-${n + 1}` }, [
      createElement("name", {}, [c.name ?? "sfx"]),
      createElement("enabled", {}, ["TRUE"]),
      createElement("duration", {}, [String(len)]),
      rateEl(tl.fps),
      createElement("start", {}, [String(start)]),
      createElement("end", {}, [String(start + len)]),
      createElement("in", {}, ["0"]),
      createElement("out", {}, [String(len)]),
      file,
      createElement("sourcetrack", {}, [createElement("mediatype", {}, ["audio"]), createElement("trackindex", {}, ["1"])])
    ]);
  });
  audio.children.push(createElement("track", { premiereTrackType: "Stereo" }, items));
  return items.length;
}
function relinkAudio(tl, replace, tracks = []) {
  var _a, _b;
  const ids = /* @__PURE__ */ new Map();
  const relinked = /* @__PURE__ */ new Set();
  let n = 0;
  for (const t of tl.audio) {
    if (tracks.length && !tracks.includes(t.index)) continue;
    for (const it of t.items) {
      if (it.kind !== "clipitem" || !it.fileId) continue;
      const src = tl.files.get(it.fileId);
      const target = src && replace.get(src.path);
      if (!target) continue;
      const fileIdx = it.el.children.findIndex((c) => c.type === "el" && c.name === "file");
      if (fileIdx < 0) continue;
      let file;
      if (ids.has(target)) file = createElement("file", { id: ids.get(target) });
      else {
        const id = `file-makas-ses-${ids.size + 1}`;
        ids.set(target, id);
        file = createElement("file", { id }, [
          createElement("name", {}, [target.split(/[\\/]/).pop()]),
          createElement("pathurl", {}, [urlFromPath(target)]),
          child(src.el, "rate") ? cloneNode(child(src.el, "rate")) : rateEl(tl.fps),
          createElement("duration", {}, [String(src.duration || 1)]),
          createElement("media", {}, [
            createElement("audio", {}, [
              createElement("samplecharacteristics", {}, [createElement("depth", {}, ["24"]), createElement("samplerate", {}, ["48000"])]),
              createElement("channelcount", {}, [String(src.channels || 2)])
            ])
          ])
        ]);
      }
      const old = it.el.children[fileIdx];
      it.el.children[fileIdx] = file;
      relinked.add(it.fileId);
      if ((_a = old.children) == null ? void 0 : _a.some((c) => c.type === "el")) {
        for (const other of [...tl.video, ...tl.audio].flatMap((x) => x.items)) {
          if (other === it || other.kind !== "clipitem" || other.fileId !== it.fileId) continue;
          const k = other.el.children.findIndex((c) => c.type === "el" && c.name === "file");
          if (k >= 0 && !((_b = other.el.children[k].children) == null ? void 0 : _b.some((c) => c.type === "el"))) {
            other.el.children[k] = old;
            break;
          }
        }
      }
      n++;
    }
  }
  for (const t of [...tl.video, ...tl.audio]) {
    for (const it of t.items) {
      if (it.kind === "clipitem" && relinked.has(it.fileId)) it.el.children = it.el.children.filter((c) => !(c.type === "el" && c.name === "link"));
    }
  }
  return n;
}
function relinkVideo(tl, replace) {
  var _a, _b;
  const ids = /* @__PURE__ */ new Map();
  const relinked = /* @__PURE__ */ new Set();
  let n = 0;
  for (const t of tl.video) {
    for (const it of t.items) {
      if (it.kind !== "clipitem" || !it.fileId) continue;
      const src = tl.files.get(it.fileId);
      const target = src && replace.get(src.path);
      if (!target) continue;
      const fileIdx = it.el.children.findIndex((c) => c.type === "el" && c.name === "file");
      if (fileIdx < 0) continue;
      let file;
      if (ids.has(target)) file = createElement("file", { id: ids.get(target) });
      else {
        const id = `file-makas-renk-${ids.size + 1}`;
        ids.set(target, id);
        file = createElement("file", { id }, [
          createElement("name", {}, [target.split(/[\\/]/).pop()]),
          createElement("pathurl", {}, [urlFromPath(target)]),
          child(src.el, "rate") ? cloneNode(child(src.el, "rate")) : rateEl(tl.fps),
          createElement("duration", {}, [String(src.duration || 1)]),
          createElement("media", {}, [
            createElement("video", {}, [
              createElement("samplecharacteristics", {}, [createElement("width", {}, [String(src.width || 1920)]), createElement("height", {}, [String(src.height || 1080)])])
            ])
          ])
        ]);
      }
      const old = it.el.children[fileIdx];
      it.el.children[fileIdx] = file;
      relinked.add(it.fileId);
      if ((_a = old.children) == null ? void 0 : _a.some((c) => c.type === "el")) {
        for (const other of [...tl.audio, ...tl.video].flatMap((x) => x.items)) {
          if (other === it || other.kind !== "clipitem" || other.fileId !== it.fileId) continue;
          const k = other.el.children.findIndex((c) => c.type === "el" && c.name === "file");
          if (k >= 0 && !((_b = other.el.children[k].children) == null ? void 0 : _b.some((c) => c.type === "el"))) {
            other.el.children[k] = old;
            break;
          }
        }
      }
      n++;
    }
  }
  for (const t of [...tl.video, ...tl.audio]) {
    for (const it of t.items) {
      if (it.kind === "clipitem" && relinked.has(it.fileId)) it.el.children = it.el.children.filter((c) => !(c.type === "el" && c.name === "link"));
    }
  }
  return n;
}
function setSequenceName(tl, name) {
  setChildText(tl.sequence, "name", name);
  tl.name = name;
}
function addVideoClips(tl, clips) {
  if (!clips.length) return 0;
  const video = childPath(tl.sequence, "media/video");
  if (!video) return 0;
  const W = tl.width || 1920;
  const H = tl.height || 1080;
  const ids = /* @__PURE__ */ new Map();
  const items = [...clips].sort((a, b) => a.start - b.start).map((c, n) => {
    const len = Math.max(1, Math.round(c.duration * tl.fps));
    const start = Math.max(0, Math.round(c.start * tl.fps));
    const inF = Math.max(0, Math.round((c.sourceIn || 0) * tl.fps));
    const fileFps = c.fps || tl.fps;
    let file;
    if (ids.has(c.path)) file = createElement("file", { id: ids.get(c.path) });
    else {
      const id = `file-makas-broll-${ids.size + 1}`;
      ids.set(c.path, id);
      file = createElement("file", { id }, [
        createElement("name", {}, [c.name ?? "b-roll"]),
        createElement("pathurl", {}, [urlFromPath(c.path)]),
        rateEl(fileFps),
        createElement("duration", {}, [String(Math.max(1, Math.round(c.frames || (c.sourceIn + c.duration) * fileFps)))]),
        createElement("media", {}, [
          createElement("video", {}, [
            createElement("samplecharacteristics", {}, [rateEl(fileFps), createElement("width", {}, [String(c.width || W)]), createElement("height", {}, [String(c.height || H)])])
          ])
        ])
      ]);
    }
    const el = createElement("clipitem", { id: `clipitem-makas-broll-${n + 1}` }, [
      createElement("name", {}, [c.name ?? "b-roll"]),
      createElement("enabled", {}, ["TRUE"]),
      createElement("duration", {}, [String(Math.max(len + inF, Math.round((c.frames || 0) * tl.fps / fileFps)))]),
      rateEl(tl.fps),
      createElement("start", {}, [String(start)]),
      createElement("end", {}, [String(start + len)]),
      createElement("in", {}, [String(inF)]),
      createElement("out", {}, [String(inF + len)]),
      file
    ]);
    const fill = Math.max(W / (c.width || W), H / (c.height || H)) * 100;
    if (Math.abs(fill - 100) > 0.05) applyScale(el, Math.round(fill * 100) / 100);
    return el;
  });
  const lastTrack = video.children.map((c, i) => c.type === "el" && c.name === "track" ? i : -1).filter((i) => i >= 0).pop();
  video.children.splice(lastTrack == null ? video.children.length : lastTrack + 1, 0, createElement("track", {}, items));
  return items.length;
}
function shiftFile(tl, fileId2, deltaFrames) {
  if (!deltaFrames) return 0;
  let n = 0;
  for (const t of [...tl.video, ...tl.audio]) {
    for (const it of t.items) {
      if (it.kind !== "clipitem" || it.fileId !== fileId2) continue;
      if (it.start >= 0) setChildText(it.el, "start", String(it.start + deltaFrames));
      if (it.end >= 0) setChildText(it.el, "end", String(it.end + deltaFrames));
      it.start += deltaFrames;
      it.end += deltaFrames;
      n++;
    }
  }
  const end = Math.max(0, ...[...tl.video, ...tl.audio].flatMap((t) => t.items.map((it) => it.end)));
  setChildText(tl.sequence, "duration", String(end));
  return n;
}
function punchZoom(tl, spans, { scale = 112, name } = {}) {
  const total = tl.duration;
  const sorted = spans.map(([s, e]) => [Math.max(0, Math.round(s)), Math.min(total, Math.round(e))]).filter(([s, e]) => e > s).sort((a, b) => a[0] - b[0]);
  const keeps = [];
  const keys = /* @__PURE__ */ new Set();
  let at = 0;
  for (const [s, e] of sorted) {
    if (s < at) continue;
    if (s > at) keeps.push([at, s]);
    keys.add(keeps.length);
    keeps.push([s, e]);
    at = e;
  }
  if (at < total) keeps.push([at, total]);
  rippleKeep(tl, keeps, { name: name ?? `${tl.name} - Zoom`, zoom: { scale, keys }, split: true });
  return keys.size;
}

// core/fontmetrics.js
function parseFont(bytes) {
  const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const u16 = (o) => v.getUint16(o);
  const i16 = (o) => v.getInt16(o);
  const u32 = (o) => v.getUint32(o);
  const tables = {};
  const n = u16(4);
  for (let i = 0; i < n; i++) {
    const r = 12 + i * 16;
    const tag = String.fromCharCode(bytes[r], bytes[r + 1], bytes[r + 2], bytes[r + 3]);
    tables[tag] = u32(r + 8);
  }
  if (tables.head == null || tables.hhea == null || tables.hmtx == null || tables.cmap == null) throw new Error("Desteklenmeyen yaz\u0131 tipi");
  const unitsPerEm = u16(tables.head + 18);
  const numHMetrics = u16(tables.hhea + 34);
  let ascent = i16(tables.hhea + 4);
  let descent = -i16(tables.hhea + 6);
  let capHeight = Math.round(unitsPerEm * 0.7);
  const os2 = tables["OS/2"];
  if (os2 != null) {
    ascent = u16(os2 + 74);
    descent = u16(os2 + 76);
    if (u16(os2) >= 2) capHeight = i16(os2 + 88) || capHeight;
  }
  const advances = [];
  for (let i = 0; i < numHMetrics; i++) advances.push(u16(tables.hmtx + i * 4));
  const glyphAdvance = (g) => advances[Math.min(g, numHMetrics - 1)] ?? 0;
  const glyphOf = buildCmap(bytes, v, tables.cmap);
  const kerning = tables.GPOS != null ? readPairKerning(v, tables.GPOS) : /* @__PURE__ */ new Map();
  return {
    names: readNames(bytes, v, tables.name),
    unitsPerEm,
    ascent,
    descent,
    capHeight,
    glyph: glyphOf,
    advance: (cp) => glyphAdvance(glyphOf(cp)),
    kern: (a, b) => kerning.get(glyphOf(a) * 65536 + glyphOf(b)) ?? 0
  };
}
function buildCmap(bytes, v, base) {
  const u16 = (o) => v.getUint16(o);
  const u32 = (o) => v.getUint32(o);
  let best = null;
  for (let i = 0, n = u16(base + 2); i < n; i++) {
    const r = base + 4 + i * 8;
    const platform7 = u16(r);
    const enc = u16(r + 2);
    const off2 = base + u32(r + 4);
    const format = u16(off2);
    if (platform7 === 3 && enc === 10 && format === 12) best = { off: off2, format };
    else if (!best && (platform7 === 3 && enc === 1 || platform7 === 0) && format === 4) best = { off: off2, format };
  }
  if (!best) return () => 0;
  const cache = /* @__PURE__ */ new Map();
  if (best.format === 12) {
    const groups = u32(best.off + 12);
    return (cp) => {
      for (let g = 0; g < groups; g++) {
        const r = best.off + 16 + g * 12;
        const s = u32(r);
        const e = u32(r + 4);
        if (cp >= s && cp <= e) return u32(r + 8) + (cp - s);
      }
      return 0;
    };
  }
  const off = best.off;
  const segX2 = u16(off + 6);
  const ends = off + 14;
  const starts = ends + segX2 + 2;
  const deltas = starts + segX2;
  const ranges = deltas + segX2;
  return (cp) => {
    if (cache.has(cp)) return cache.get(cp);
    let gid = 0;
    for (let s = 0; s < segX2; s += 2) {
      if (cp > u16(ends + s)) continue;
      const start = u16(starts + s);
      if (cp < start) break;
      const delta = v.getInt16(deltas + s);
      const ro = u16(ranges + s);
      if (ro === 0) gid = cp + delta & 65535;
      else {
        const g = u16(ranges + s + ro + (cp - start) * 2);
        gid = g ? g + delta & 65535 : 0;
      }
      break;
    }
    cache.set(cp, gid);
    return gid;
  };
}
function readNames(bytes, v, base) {
  if (base == null) return [];
  const u16 = (o) => v.getUint16(o);
  const count = u16(base + 2);
  const strings = base + u16(base + 4);
  const byId = {};
  for (let i = 0; i < count; i++) {
    const r = base + 6 + i * 12;
    const platform7 = u16(r);
    const id = u16(r + 6);
    const len = u16(r + 8);
    const off = strings + u16(r + 10);
    if (![1, 2, 4, 6, 16, 17].includes(id)) continue;
    let s = "";
    if (platform7 === 3 || platform7 === 0) for (let k = 0; k < len; k += 2) s += String.fromCharCode(u16(off + k));
    else for (let k = 0; k < len; k++) s += String.fromCharCode(bytes[off + k]);
    byId[id] ??= s;
  }
  const names = /* @__PURE__ */ new Set([byId[1], byId[4], byId[6]]);
  if (byId[16]) names.add(`${byId[16]} ${byId[17] ?? ""}`.trim());
  if (byId[1] && byId[2] && byId[2] !== "Regular") names.add(`${byId[1]} ${byId[2]}`);
  return [...names].filter(Boolean);
}
function readPairKerning(v, base) {
  const u16 = (o) => v.getUint16(o);
  const i16 = (o) => v.getInt16(o);
  const map = /* @__PURE__ */ new Map();
  try {
    const lookupList = base + u16(base + 8);
    for (let l = 0, nl = u16(lookupList); l < nl; l++) {
      const lookup = lookupList + u16(lookupList + 2 + l * 2);
      let type = u16(lookup);
      for (let s = 0, ns = u16(lookup + 4); s < ns; s++) {
        let sub = lookup + u16(lookup + 6 + s * 2);
        if (type === 9) {
          if (u16(sub + 2) !== 2) continue;
          sub = sub + v.getUint32(sub + 4);
        } else if (type !== 2) continue;
        readPairSubtable(v, sub, map, u16, i16);
      }
    }
  } catch {
  }
  return map;
}
function coverageGlyphs(v, off) {
  const u16 = (o) => v.getUint16(o);
  const out = [];
  if (u16(off) === 1) for (let i = 0, n = u16(off + 2); i < n; i++) out.push(u16(off + 4 + i * 2));
  else
    for (let i = 0, n = u16(off + 2); i < n; i++) {
      const r = off + 4 + i * 6;
      for (let g = u16(r); g <= u16(r + 2); g++) out.push(g);
    }
  return out;
}
function classDef(v, off) {
  const u16 = (o) => v.getUint16(o);
  const m2 = /* @__PURE__ */ new Map();
  if (u16(off) === 1) {
    const start = u16(off + 2);
    for (let i = 0, n = u16(off + 4); i < n; i++) m2.set(start + i, u16(off + 6 + i * 2));
  } else
    for (let i = 0, n = u16(off + 2); i < n; i++) {
      const r = off + 4 + i * 6;
      for (let g = u16(r); g <= u16(r + 2); g++) m2.set(g, u16(r + 4));
    }
  return m2;
}
function valueSize(fmt) {
  let n = 0;
  for (let b = fmt; b; b >>= 1) n += b & 1;
  return n * 2;
}
function readPairSubtable(v, sub, map, u16, i16) {
  const format = u16(sub);
  const first = coverageGlyphs(v, sub + u16(sub + 2));
  const vf1 = u16(sub + 4);
  const vf2 = u16(sub + 6);
  if (!(vf1 & 4)) return;
  const xAdvOffset = (vf1 & 1 ? 2 : 0) + (vf1 & 2 ? 2 : 0);
  const recSize = valueSize(vf1) + valueSize(vf2);
  if (format === 1) {
    first.forEach((g1, i) => {
      const set = sub + u16(sub + 10 + i * 2);
      for (let k = 0, n = u16(set); k < n; k++) {
        const r = set + 2 + k * (2 + recSize);
        const key = g1 * 65536 + u16(r);
        if (!map.has(key)) map.set(key, i16(r + 2 + xAdvOffset));
      }
    });
  } else if (format === 2) {
    const c1 = classDef(v, sub + u16(sub + 8));
    const c2 = classDef(v, sub + u16(sub + 10));
    const n1 = u16(sub + 12);
    const n22 = u16(sub + 14);
    const byClass2 = /* @__PURE__ */ new Map();
    for (const [g, c] of c2) {
      if (!byClass2.has(c)) byClass2.set(c, []);
      byClass2.get(c).push(g);
    }
    for (const g1 of first) {
      const k1 = c1.get(g1) ?? 0;
      if (k1 >= n1) continue;
      for (let k2 = 1; k2 < n22; k2++) {
        const val = i16(sub + 16 + (k1 * n22 + k2) * recSize + xAdvOffset);
        if (!val) continue;
        for (const g2 of byClass2.get(k2) ?? []) {
          const key = g1 * 65536 + g2;
          if (!map.has(key)) map.set(key, val);
        }
      }
    }
  }
}
function createMeasurer(fonts) {
  const byName = /* @__PURE__ */ new Map();
  for (const f of fonts) {
    try {
      const m2 = parseFont(f.bytes);
      for (const name of m2.names) if (!byName.has(name.toLowerCase())) byName.set(name.toLowerCase(), m2);
    } catch {
    }
  }
  return (fontName) => {
    const m2 = byName.get(String(fontName).toLowerCase());
    if (!m2) return null;
    const em = m2.ascent + m2.descent;
    return {
      ascent: m2.ascent / em,
      descent: m2.descent / em,
      capHeight: m2.capHeight / em,
      width(text, size, spacing = 0) {
        const cps = [...String(text)].map((c) => c.codePointAt(0));
        let units = 0;
        cps.forEach((cp, i) => {
          units += m2.advance(cp);
          if (i + 1 < cps.length) units += m2.kern(cp, cps[i + 1]);
        });
        return units / em * size + spacing * cps.length;
      }
    };
  };
}

// core/highlights.js
var STOP = new Set(
  `ve ile de da ki bu \u015Fu o bir i\xE7in ama fakat \xE7\xFCnk\xFC gibi kadar daha \xE7ok en mi m\u0131 mu m\xFC ne ya yani i\u015Fte \u015Fey \u015Fimdi
  ben sen biz siz onlar bunu \u015Funu onu bana sana bize size beni seni bizi sizi benim senin bizim sizin onun
  var yok olan olarak oldu olur olsun de\u011Fil her hep hi\xE7 bile sonra \xF6nce zaten art\u0131k hani evet hay\u0131r tamam
  diye dedi dedim ger\xE7ekten asl\u0131nda sadece biraz b\xF6yle \xF6yle \u015F\xF6yle burada orada nas\u0131l neden niye kendi
  gibi g\xF6re kez tane mesela belki herhalde laz\u0131m gerek oluyor yap\u0131yor yapmak etmek olmak bence
  the a an and or but to of in on at for is are was it this that you i we they`.split(/\s+/)
);
var FILLER = /^(ı+|ıı+|e+|ee+|ı+m+|hı+|ha+|şey|yani|hani|işte)$/i;
var HOOK = /^(neden|nasıl|niye|inanılmaz|asla|sakın|dikkat|sır|gerçek|önemli|hata|en|ilk|son|bedava|para|kazan|kaybet|şok|hiç|kimse|herkes|bakın|bakalım)$/i;
var clean = (w) => String(w).toLocaleLowerCase("tr-TR").replace(/[^\p{L}\p{N}]/gu, "");
var endsSentence2 = (w) => /[.!?…]["')\]]?$/.test(String(w).trim());
function sentences(words, { pause = 0.8 } = {}) {
  const out = [];
  let cur = [];
  words.forEach((w, i) => {
    cur.push(w);
    const next = words[i + 1];
    if (!next || endsSentence2(w.text) || next.start - w.end > pause) {
      out.push({ start: cur[0].start, end: cur[cur.length - 1].end, words: cur, text: cur.map((x) => x.text).join(" ") });
      cur = [];
    }
  });
  return out;
}
function scoreWindow(sents) {
  const words = sents.flatMap((s) => s.words);
  const dur = sents[sents.length - 1].end - sents[0].start;
  const tokens = words.map((w) => clean(w.text)).filter(Boolean);
  const fillers = tokens.filter((t) => FILLER.test(t)).length;
  const hooks = tokens.filter((t) => HOOK.test(t)).length;
  const numbers = tokens.filter((t) => /\d/.test(t)).length;
  let gaps = 0;
  for (let i = 1; i < words.length; i++) if (words[i].start - words[i - 1].end > 1.2) gaps++;
  const pace = tokens.length / Math.max(1, dur);
  const first = sents[0];
  const firstTokens = first.words.map((w) => clean(w.text));
  const hookStart = /\?\s*$/.test(first.text) || firstTokens.slice(0, 6).some((t) => HOOK.test(t));
  return pace * 10 + hooks * 1.5 + numbers * 0.8 + (hookStart ? 8 : 0) - fillers * 1.2 - gaps * 3;
}
function findHighlights(words, { min = 20, max = 60, count = 5 } = {}) {
  const sents = sentences(words);
  const cands = [];
  for (let i = 0; i < sents.length; i++) {
    let best = null;
    for (let j = i; j < sents.length; j++) {
      const dur = sents[j].end - sents[i].start;
      if (dur > max) break;
      if (dur < min) continue;
      const score = scoreWindow(sents.slice(i, j + 1)) + Math.min(dur, 45) / 15;
      if (!best || score > best.score) best = { i, j, score };
    }
    if (best) cands.push(best);
  }
  cands.sort((a, b) => b.score - a.score);
  const picked = [];
  for (const c of cands) {
    const s = sents[c.i].start;
    const e = sents[c.j].end;
    if (picked.some((p) => s < p.end && e > p.start)) continue;
    const text = sents.slice(c.i, c.j + 1).map((x) => x.text).join(" ");
    picked.push({ start: Math.max(0, s - 0.15), end: e + 0.25, duration: e - s, score: Math.round(c.score * 10) / 10, text, hook: sents[c.i].text });
    if (picked.length >= count) break;
  }
  return picked;
}
function contentWords(sents) {
  return sents.flatMap((s) => s.words.map((w) => clean(w.text))).filter((t) => t.length > 2 && !STOP.has(t) && !FILLER.test(t) && !/^\d+$/.test(t));
}
var titleCase = (w) => w.charAt(0).toLocaleUpperCase("tr-TR") + w.slice(1);
function buildChapters(words, { minLen = 45 } = {}) {
  const sents = sentences(words, { pause: 1 });
  if (!sents.length) return [];
  const total = sents[sents.length - 1].end;
  const k = Math.max(1, Math.min(10, Math.round(total / 150)));
  if (k < 3 || total < minLen * 3) return [{ start: 0, title: "Giri\u015F" }];
  const bounds = [0];
  for (let b = 1; b < k; b++) {
    const target = b * total / k;
    let best = null;
    sents.forEach((s, i) => {
      if (i === 0 || Math.abs(s.start - target) > total / k / 3) return;
      if (s.start - sents[bounds[bounds.length - 1]].start < minLen || total - s.start < minLen) return;
      const before = new Set(contentWords(sents.slice(Math.max(0, i - 8), i)));
      const after = contentWords(sents.slice(i, i + 8));
      const overlap = after.filter((t) => before.has(t)).length / Math.max(1, after.length);
      const pause = s.start - sents[i - 1].end;
      const score = overlap - Math.min(pause, 3) * 0.15 + Math.abs(s.start - target) / total * 2;
      if (!best || score < best.score) best = { i, score };
    });
    if (best) bounds.push(best.i);
  }
  const chunks = bounds.map((b, n) => sents.slice(b, bounds[n + 1] ?? sents.length));
  const docFreq = /* @__PURE__ */ new Map();
  const tfs = chunks.map((c) => {
    const tf = /* @__PURE__ */ new Map();
    for (const t of contentWords(c)) tf.set(t, (tf.get(t) ?? 0) + 1);
    for (const t of tf.keys()) docFreq.set(t, (docFreq.get(t) ?? 0) + 1);
    return tf;
  });
  return chunks.map((c, n) => {
    if (n === 0) return { start: 0, title: "Giri\u015F" };
    const top = [...tfs[n].entries()].map(([t, f]) => [t, f * Math.log(1 + chunks.length / docFreq.get(t))]).sort((a, b) => b[1] - a[1]).slice(0, 2).map(([t]) => titleCase(t));
    return { start: c[0].start, title: top.length ? top.join(" ve ") : `B\xF6l\xFCm ${n + 1}` };
  });
}
function chaptersText(chapters) {
  const long = chapters.some((c) => c.start >= 3600);
  return chapters.map((c) => {
    const t = Math.floor(c.start);
    const h = Math.floor(t / 3600);
    const m2 = Math.floor(t % 3600 / 60);
    const s = t % 60;
    const mm = String(m2).padStart(2, "0");
    const ss = String(s).padStart(2, "0");
    return `${long ? `${h}:${mm}` : mm}:${ss} ${c.title}`;
  }).join("\n");
}

// core/broll.js
var STOP2 = new Set("ve ile bir bu \u015Fu i\xE7in gibi kadar video klip broll b roll final yeni copy kopya the and of".split(" "));
var clean2 = (w) => String(w).toLocaleLowerCase("tr-TR").replace(/[^\p{L}\p{N}]/gu, "");
function brollKeywords(fileName) {
  const base = String(fileName).split(/[\\/]/).pop().replace(/\.[^.]+$/, "");
  return base.replace(/([a-zğüşöçı])([A-ZĞÜŞÖÇİ])/g, "$1 $2").split(/[^\p{L}\p{N}]+/u).map(clean2).filter((t) => t.length >= 3 && !/^\d+$/.test(t) && !STOP2.has(t));
}
var matches = (word, key) => word.startsWith(key) || key.length >= 5 && word.length >= 5 && word.slice(0, 5) === key.slice(0, 5);
function matchBroll(words, files, { clipLen = 2.5, minGap = 4, maxUses = 1, lead = 0.2 } = {}) {
  const keyed = files.map((f) => ({ ...f, keys: brollKeywords(f.name ?? f.path), uses: 0 })).filter((f) => f.keys.length);
  const out = [];
  let freeAt = 0;
  for (const w of words) {
    const word = clean2(w.text);
    if (word.length < 3 || w.start < freeAt) continue;
    const f = keyed.find((x) => x.uses < maxUses && x.keys.some((k) => matches(word, k)));
    if (!f) continue;
    const duration = Math.min(clipLen, Math.max(0.5, (f.duration || clipLen) - 0.2));
    const sourceIn = f.duration > duration + 1 ? Math.min(1, (f.duration - duration) / 2) : 0;
    const start = Math.max(0, w.start - lead);
    out.push({ path: f.path, name: f.name, word: w.text, start, duration, sourceIn });
    f.uses++;
    freeAt = start + duration + minGap;
  }
  return out;
}

// core/sync.js
function onsets(envDb, { floor = 3 } = {}) {
  const out = new Float32Array(envDb.length);
  for (let i = 1; i < envDb.length; i++) out[i] = Math.max(0, Math.max(-60, envDb[i]) - Math.max(-60, envDb[i - 1]) - floor);
  return out;
}
function decimate(x, factor) {
  const n = Math.floor(x.length / factor);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let m2 = 0;
    for (let k = 0; k < factor; k++) m2 = Math.max(m2, x[i * factor + k]);
    out[i] = m2;
  }
  return out;
}
function normalized(x) {
  let mean = 0;
  for (const v of x) mean += v;
  mean /= x.length || 1;
  let sd = 0;
  const out = new Float32Array(x.length);
  for (let i = 0; i < x.length; i++) {
    out[i] = x[i] - mean;
    sd += out[i] * out[i];
  }
  sd = Math.sqrt(sd) || 1;
  for (let i = 0; i < out.length; i++) out[i] /= sd;
  return out;
}
function bestLag(a, b, lagMin, lagMax) {
  const nb = normalized(b);
  lagMin = Math.max(0, lagMin);
  lagMax = Math.min(a.length - nb.length, lagMax);
  let best = { lag: lagMin, score: -Infinity };
  const scores = [];
  for (let lag = lagMin; lag <= lagMax; lag++) {
    let sc = 0;
    for (let i = 0; i < nb.length; i++) sc += a[i + lag] * nb[i];
    scores.push(sc);
    if (sc > best.score) best = { lag, score: sc };
  }
  let second = 0;
  scores.forEach((sc, k) => {
    if (Math.abs(lagMin + k - best.lag) > 20 && sc > second) second = sc;
  });
  return { ...best, confidence: second > 0 ? best.score / second : 10 };
}
function oneWay(envA, envB, { windowSec = 0.01, maxOffset = 600, excerpt = 90 } = {}) {
  const A = onsets(envA);
  const B = onsets(envB);
  const winN = Math.max(1, Math.min(Math.floor(B.length / 2), Math.round(excerpt / windowSec)));
  let from = 0;
  let bestEnergy = -1;
  const stepN = Math.max(1, Math.round(10 / windowSec));
  for (let s = 0; s + winN <= B.length; s += stepN) {
    let e = 0;
    for (let i = s; i < s + winN; i += 5) e += B[i];
    if (e > bestEnergy) {
      bestEnergy = e;
      from = s;
    }
  }
  const piece = B.subarray(from, from + winN);
  const f = Math.max(1, Math.round(0.05 / windowSec));
  const Ac = decimate(A, f);
  const Pc = decimate(piece, f);
  const maxC = Math.round(maxOffset / (windowSec * f));
  const fromC = Math.floor(from / f);
  const coarse = bestLag(Ac, Pc, Math.max(-Pc.length, fromC - maxC), Math.min(Ac.length, fromC + maxC));
  const center = coarse.lag * f;
  const fine = bestLag(A, piece, center - 2 * f, center + 2 * f);
  return { offset: (fine.lag - from) * windowSec, confidence: Math.round(coarse.confidence * 100) / 100 };
}
function findSyncOffset(envA, envB, opts = {}) {
  const r1 = oneWay(envA, envB, opts);
  if (r1.confidence >= 2) return r1;
  const r2 = oneWay(envB, envA, opts);
  return r2.confidence > r1.confidence ? { offset: -r2.offset, confidence: r2.confidence } : r1;
}

// core/beats.js
function onsetStrength(envDb) {
  const out = new Float32Array(envDb.length);
  for (let i = 1; i < envDb.length; i++) out[i] = Math.max(0, Math.max(-70, envDb[i]) - Math.max(-70, envDb[i - 1]) - 0.5);
  return out;
}
function detectBeats(envDb, { windowSec = 0.01, minBpm = 70, maxBpm = 180 } = {}) {
  const o = onsetStrength(envDb);
  const n = o.length;
  const lagMin = Math.round(60 / maxBpm / windowSec);
  const lagMax = Math.round(60 / minBpm / windowSec);
  let best = { lag: lagMin, score: -1 };
  for (let lag2 = lagMin; lag2 <= lagMax; lag2++) {
    let s = 0;
    for (let i = 0; i + lag2 < n; i++) s += o[i] * o[i + lag2];
    const bpm = 60 / (lag2 * windowSec);
    const prior = Math.exp(-(Math.log2(bpm / 118) ** 2) / 0.5);
    s *= 0.6 + 0.4 * prior;
    if (s > best.score) best = { lag: lag2, score: s };
  }
  const lag = best.lag;
  let phase = 0;
  let phaseScore = -1;
  for (let p = 0; p < lag; p++) {
    let s = 0;
    for (let i = p; i < n; i += lag) s += o[i];
    if (s > phaseScore) {
      phaseScore = s;
      phase = p;
    }
  }
  const beats = [];
  const tol = Math.round(0.04 / windowSec);
  for (let i = phase; i < n; i += lag) {
    let at = i;
    for (let k = Math.max(0, i - tol); k <= Math.min(n - 1, i + tol); k++) if (o[k] > o[at]) at = k;
    beats.push(Math.round(at * windowSec * 1e3) / 1e3);
  }
  return { bpm: Math.round(60 / (lag * windowSec) * 10) / 10, beats };
}
function beatCuts(beats, clips, { every = 2, maxLength = Infinity, skipIn = 0.5 } = {}) {
  const out = [];
  const cursor = new Map(clips.map((c) => [c.id, Math.min(skipIn, Math.max(0, c.duration / 4))]));
  let k = 0;
  for (let b = 0; b + every < beats.length; b += every) {
    const start = b === 0 ? 0 : beats[b];
    const end = beats[b + every];
    if (start >= maxLength) break;
    const len = end - start;
    let tries = 0;
    let c = clips[k % clips.length];
    while (c.duration < len + 0.05 && tries++ < clips.length) c = clips[++k % clips.length];
    if (c.duration < len + 0.05) break;
    let from = cursor.get(c.id);
    if (from + len > c.duration) from = Math.min(skipIn, c.duration - len);
    out.push({ fileId: c.id, start, end, sourceIn: from });
    cursor.set(c.id, from + len);
    k++;
  }
  return out;
}

// core/kinetic.js
var STOP3 = new Set(
  `ve ile de da ki bu \u015Fu o bir i\xE7in ama fakat \xE7\xFCnk\xFC gibi kadar daha \xE7ok en mi m\u0131 mu m\xFC ne ya yani i\u015Fte \u015Fey \u015Fimdi
  ben sen biz siz onlar bunu \u015Funu onu bana sana bize size beni seni bizi sizi benim senin bizim sizin onun
  var yok olan olarak oldu olur de\u011Fil her hep hi\xE7 bile sonra \xF6nce zaten art\u0131k hani evet hay\u0131r tamam diye
  the a an and or but to of in on at for is are was it this that you i we they what if my your`.split(/\s+/)
);
var STRONG = /^(asla|sakın|inanılmaz|müthiş|korkunç|gerçek|gerçekten|sır|önemli|hata|bedava|ücretsiz|para|milyon|bin|yüzde|ilk|son|tek|herkes|kimse|hiçbir|never|always|secret|free|money|actually)$/i;
var clean3 = (w) => String(w).toLocaleLowerCase("tr-TR").replace(/[^\p{L}\p{N}]/gu, "");
function pickEmphasis(words) {
  let best = -1;
  let bestScore = -1;
  words.forEach((w, i) => {
    const t = clean3(w.text ?? w);
    if (!t) return;
    let score = t.length;
    if (STOP3.has(t)) score -= 100;
    if (STRONG.test(t) || /\d/.test(t)) score += 20;
    if (score >= bestScore) {
      bestScore = score;
      best = i;
    }
  });
  return best < 0 ? words.length - 1 : best;
}
var KINETIC_LOOKS = {
  // Aralıklı küçük büyük harfler + büyük eğik serif: dergi kapağı düzeni
  editoryal: { label: "Editoryal", small: "Montserrat SemiBold", big: "Instrument Serif Italic", bigRatio: 3.3, bigUpper: false, smallUpper: true, smallRatio: 0.82, smallSpacing: 0.16, gap: 0.16 },
  guclu: { label: "G\xFC\xE7l\xFC", small: "Montserrat Bold", big: "Montserrat Black", bigRatio: 2.3, bigUpper: true, smallUpper: true, smallRatio: 0.9, smallSpacing: 0.06, gap: 0.22 },
  afis: { label: "Afi\u015F", small: "Poppins SemiBold", big: "Anton", bigRatio: 3, bigUpper: true, smallUpper: true, smallRatio: 0.8, smallSpacing: 0.12, gap: 0.24 }
};
var KINETIC_ENTRANCES = ["karisik", "maske", "harf", "yuksel", "dus", "soldan", "sagdan", "netles", "sol", "aninda"];
var ac = (hex) => `&H${toAssColor(hex).slice(4)}&`;
var esc = (t) => String(t).replace(/[{}]/g, "").replace(/\\/g, "/");
function entrance(kind, x, y, d, ms) {
  switch (kind) {
    case "yuksel":
      return `\\move(${x},${y + d},${x},${y},0,${ms})\\fad(${ms},0)`;
    case "dus":
      return `\\move(${x},${y - d},${x},${y},0,${ms})\\fad(${ms},0)`;
    case "soldan":
      return `\\move(${x - d * 2},${y},${x},${y},0,${ms})\\fad(${ms},0)`;
    case "sagdan":
      return `\\move(${x + d * 2},${y},${x},${y},0,${ms})\\fad(${ms},0)`;
    case "netles":
      return `\\pos(${x},${y})\\blur${Math.max(6, Math.round(d / 3))}\\fscx112\\fscy112\\t(0,${Math.round(ms * 1.5)},0.5,\\blur0\\fscx100\\fscy100)\\fad(${ms},0)`;
    case "sol":
      return `\\pos(${x},${y})\\fad(${Math.round(ms * 1.4)},0)`;
    default:
      return `\\pos(${x},${y})`;
  }
}
function buildKineticAss(segments, opts = {}) {
  const { width = 1920, height = 1080, measure } = opts;
  const look = KINETIC_LOOKS[opts.look] ?? KINETIC_LOOKS.editoryal;
  const ent = KINETIC_ENTRANCES.includes(opts.entrance) ? opts.entrance : "karisik";
  const color = opts.color || "#FFFFFF";
  const accent = opts.accent || color;
  const scale = opts.scale ?? 1;
  const unit = Math.min(width, height * 1.1);
  const smallSize = Math.round(unit * 0.056 * scale);
  const mSmall = measure == null ? void 0 : measure(look.small);
  const mBig = measure == null ? void 0 : measure(look.big);
  if (!mSmall || !mBig) throw new Error("Hareketli yaz\u0131 i\xE7in yaz\u0131 tipleri bulunamad\u0131");
  const maxW = width * 0.86;
  const cx = Math.round(width / 2);
  const anchor = opts.position === "top" ? height * 0.2 : opts.position === "middle" ? height * 0.5 : height * 0.72;
  const ms = 170;
  const header = [
    "[Script Info]",
    "ScriptType: v4.00+",
    `PlayResX: ${width}`,
    `PlayResY: ${height}`,
    "WrapStyle: 2",
    "ScaledBorderAndShadow: yes",
    "YCbCr Matrix: None",
    "",
    "[V4+ Styles]",
    "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
    `Style: Default,${look.small},${smallSize},${toAssColor(color)},${toAssColor(color)},&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1`,
    "",
    "[Events]",
    "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"
  ];
  const events = [];
  const ev = (layer, start, end, text) => events.push(`Dialogue: ${layer},${formatAssTime(start)},${formatAssTime(end)},Default,,0,0,0,,${text}`);
  segments.forEach((seg) => {
    var _a;
    const words = (((_a = seg.words) == null ? void 0 : _a.length) ? seg.words : String(seg.text).split(/\s+/).map((t) => ({ text: t, start: seg.start, end: seg.end }))).filter((w) => clean3(w.text));
    if (!words.length) return;
    const e = Number.isInteger(seg.emphasis) && seg.emphasis >= 0 && seg.emphasis < words.length ? seg.emphasis : pickEmphasis(words);
    const bigText = look.bigUpper ? upperTr(words[e].text) : words[e].text;
    const smallText = (w) => look.smallUpper ? upperTr(w.text) : w.text;
    const before = words.slice(0, e);
    const after = words.slice(e + 1);
    let bigSize = Math.round(smallSize * look.bigRatio);
    const bw = mBig.width(bigText, bigSize);
    if (bw > maxW) bigSize = Math.floor(bigSize * maxW / bw);
    const bigW = mBig.width(bigText, bigSize);
    const rows = [];
    const sSize = smallSize * (look.smallRatio ?? 1);
    const sp = sSize * (look.smallSpacing ?? 0);
    const space = mSmall.width(" ", sSize, sp) * 1.15;
    const smallRow = (list) => {
      const texts = list.map(smallText);
      const widths = texts.map((t) => mSmall.width(t, sSize, sp));
      let total2 = widths.reduce((a, b) => a + b, 0) + space * Math.max(0, list.length - 1);
      const k = total2 > maxW ? maxW / total2 : 1;
      total2 *= k;
      let x = cx - total2 / 2;
      return {
        h: sSize * k,
        items: list.map((w, i) => {
          const it = { w, text: texts[i], x: Math.round(x + widths[i] * k / 2), width: widths[i] * k, font: look.small, size: Math.round(sSize * k), spacing: Math.round(sp * k * 10) / 10, color, big: false, m: mSmall };
          x += (widths[i] + space) * k;
          return it;
        })
      };
    };
    if (before.length) rows.push(smallRow(before));
    rows.push({ h: bigSize * (mBig.capHeight + 0.26), items: [{ w: words[e], text: bigText, x: cx, width: bigW, font: look.big, size: bigSize, spacing: 0, color: accent, big: true, m: mBig }] });
    if (after.length) rows.push(smallRow(after));
    const gap = smallSize * (look.gap ?? 0.2);
    const total = rows.reduce((n, r) => n + r.h, 0) + gap * (rows.length - 1);
    let y = anchor - total / 2;
    const end = seg.end;
    rows.forEach((row) => {
      const cy = Math.round(y + row.h / 2);
      row.items.forEach((it) => {
        const start = Math.max(seg.start, Math.min((it.w.start ?? seg.start) - 0.06, end - 0.1));
        const kind = ent === "karisik" ? it.big ? "harf" : "maske" : ent;
        const life = Math.round((end - start) * 1e3);
        const out = `\\t(${Math.max(0, life - 110)},${life},\\alpha&HFF&)`;
        const face = `\\fn${it.font}\\fs${it.size}${it.spacing ? `\\fsp${it.spacing}` : ""}`;
        const sb = Math.max(2, Math.round(it.size * 0.045));
        const emit = (motion, text) => {
          ev(0, start, end, `{\\an5${motion}${face}\\1a&HFF&\\bord${sb}\\3c&H000000&\\3a&H88&\\blur${Math.round(sb * 2.5)}\\shad0${out}}${esc(text)}`);
          ev(1, start, end, `{\\an5${motion}${face}\\c${ac(it.color)}\\bord0\\shad0${out}}${esc(text)}`);
        };
        if (kind === "maske" || kind === "harf") {
          const top = Math.round(cy - it.size * 0.78);
          const bottom = Math.round(cy + it.size * 0.6);
          const d = bottom - top;
          const clip = `\\clip(0,${top},${width},${bottom})`;
          const dur = it.big ? 260 : 200;
          if (kind === "maske") emit(`${clip}\\move(${it.x},${cy + d},${it.x},${cy},0,${dur})`, it.text);
          else {
            const chars = [...it.text];
            const k = it.width / (it.m.width(it.text, it.size, it.spacing) || 1);
            const stagger = Math.min(38, Math.round(240 / chars.length));
            const left = it.x - it.width / 2;
            chars.forEach((ch, i) => {
              if (!ch.trim()) return;
              const pre = it.m.width(chars.slice(0, i).join(""), it.size, it.spacing) * k;
              const upto = it.m.width(chars.slice(0, i + 1).join(""), it.size, it.spacing) * k;
              const x = Math.round(left + (pre + upto) / 2);
              emit(`${clip}\\move(${x},${cy + d},${x},${cy},${i * stagger},${i * stagger + dur})`, ch);
            });
          }
        } else {
          const d = Math.round(it.size * (it.big ? 0.28 : 0.6));
          emit(entrance(kind, it.x, cy, d, it.big ? ms + 60 : ms), it.text);
        }
      });
      y += row.h + gap;
    });
  });
  return `${header.join("\n")}
${events.join("\n")}
`;
}

// core/effects.js
var ac2 = (hex) => `&H${toAssColor(hex).slice(4)}&`;
var esc2 = (t) => String(t ?? "").replace(/[{}]/g, "").replace(/\\/g, "/").replace(/\s+/g, " ").trim();
var f1 = (n) => Math.round(n * 10) / 10;
function sheet(width, height) {
  const lines = [
    "[Script Info]",
    "ScriptType: v4.00+",
    `PlayResX: ${width}`,
    `PlayResY: ${height}`,
    "WrapStyle: 2",
    "ScaledBorderAndShadow: yes",
    "YCbCr Matrix: None",
    "",
    "[V4+ Styles]",
    "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
    "Style: Default,Montserrat Bold,40,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1",
    "",
    "[Events]",
    "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"
  ];
  const events = [];
  return {
    ev: (layer, start, end, text) => events.push(`Dialogue: ${layer},${formatAssTime(Math.max(0, start))},${formatAssTime(end)},Default,,0,0,0,,${text}`),
    done: () => `${lines.join("\n")}
${events.join("\n")}
`
  };
}
function rect(w, h, r = 0) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  if (!r) return `m 0 0 l ${f1(w)} 0 ${f1(w)} ${f1(h)} 0 ${f1(h)}`;
  const k = r * 0.4477;
  return `m ${f1(r)} 0 l ${f1(w - r)} 0 b ${f1(w - k)} 0 ${f1(w)} ${f1(k)} ${f1(w)} ${f1(r)} l ${f1(w)} ${f1(h - r)} b ${f1(w)} ${f1(h - k)} ${f1(w - k)} ${f1(h)} ${f1(w - r)} ${f1(h)} l ${f1(r)} ${f1(h)} b ${f1(k)} ${f1(h)} 0 ${f1(h - k)} 0 ${f1(h - r)} l 0 ${f1(r)} b 0 ${f1(k)} ${f1(k)} 0 ${f1(r)} 0`;
}
var unitOf = (width, height) => Math.min(width, height * 1.1);
function buildTitle({ width, height, measure, title, kicker = "", look = "editoryal", accent = "#FFFFFF", hold = 3.5 }) {
  const t = esc2(title);
  if (!t) throw new Error("Ba\u015Fl\u0131k metni bo\u015F");
  const small = esc2(kicker).split(" ").filter(Boolean);
  const words = [...small.map((text) => ({ text, start: 0, end: 0.3 })), { text: t, start: small.length ? 0.25 : 0, end: hold }];
  const seg = { start: 0, end: hold, text: `${small.join(" ")} ${t}`.trim(), words, emphasis: small.length };
  return { ass: buildKineticAss([seg], { width, height, measure, look, entrance: "karisik", accent, position: "middle", scale: 1.15 }), duration: hold + 0.2 };
}
function inkOn(hex) {
  const m2 = /^#?([0-9a-f]{6})$/i.exec(String(hex));
  if (!m2) return "#FFFFFF";
  const n = parseInt(m2[1], 16);
  const lum = (0.2126 * (n >> 16) + 0.7152 * (n >> 8 & 255) + 0.0722 * (n & 255)) / 255;
  return lum > 0.62 ? "#111111" : "#FFFFFF";
}
var LOWER_FONTS = [
  { id: "montserrat", label: "Montserrat", name: "Montserrat Bold", role: "Montserrat SemiBold", k: 1 },
  { id: "poppins", label: "Poppins", name: "Poppins Bold", role: "Poppins SemiBold", k: 1 },
  { id: "anton", label: "Anton", name: "Anton", role: "Montserrat SemiBold", k: 1.15 },
  { id: "serif", label: "Serif", name: "Instrument Serif", role: "Montserrat SemiBold", k: 1.2, italic: true }
];
var OWN_ENTRANCE = { cizgi: "kay", cam: "kay", kutu: "sil", altcizgi: "yuksel", etiket: "buyu" };
function rectC(w, h, r = 0) {
  return rect(w, h, r).replace(/(-?\d+(?:\.\d+)?) (-?\d+(?:\.\d+)?)/g, (_, x, y) => `${f1(x - w / 2)} ${f1(y - h / 2)}`);
}
function buildLowerThird({
  width,
  height,
  measure,
  name,
  role = "",
  handle = "",
  accent = "#A855F7",
  hold = 4.5,
  style = "cizgi",
  position = "sol",
  scale = 1,
  entrance: entrance2 = "ozgun",
  exit = "belir",
  font = "montserrat",
  nameColor,
  roleColor,
  bgColor = "#0B0B0F",
  bgOpacity,
  radius,
  upperName = false,
  upperRole = true,
  bottom = 0.87,
  margin = 0.07,
  logo = false,
  logoRound = false
}) {
  const n = upperName ? upperTr(esc2(name)) : esc2(name);
  if (!n) throw new Error("\u0130sim bo\u015F");
  const r = upperRole ? upperTr(esc2(role)) : esc2(role);
  const h = esc2(handle);
  const F = LOWER_FONTS.find((x) => x.id === font) ?? LOWER_FONTS[0];
  const u = unitOf(width, height) * Math.max(0.6, Math.min(1.8, scale));
  const nameSize = Math.round(u * 0.05 * F.k);
  const roleSize = Math.round(u * 0.026);
  const sp = upperRole ? f1(roleSize * 0.14) : 0;
  const wOf = (text, face, size, spacing = 0) => {
    var _a;
    return (((_a = measure == null ? void 0 : measure(face)) == null ? void 0 : _a.width(text, size)) ?? text.length * size * 0.6) + spacing * text.length;
  };
  const wName = wOf(n, F.name, nameSize);
  const wRole = r ? wOf(r, F.role, roleSize, sp) : 0;
  const wHandle = h ? wOf(h, F.role, roleSize) : 0;
  const NAME = `\\fn${F.name}\\fs${nameSize}${F.italic ? "\\i1" : ""}`;
  const ROLE = `\\fn${F.role}\\fs${roleSize}${sp ? `\\fsp${sp}` : ""}`;
  const HANDLE = `\\fn${F.role}\\fs${roleSize}`;
  const alphaHex = (opacity) => Math.round((1 - Math.max(0, Math.min(1, opacity))) * 255).toString(16).padStart(2, "0").toUpperCase();
  const rad = (boxH, fallback) => radius == null ? fallback : Math.max(0, Math.min(100, radius)) / 100 * (boxH / 2);
  const els = [];
  const shapeEl = (k, x, y, w, hh, rr, color, alpha, extra = {}) => els.push({ k, x, y, w, h: hh, r: rr, color, alpha, ...extra });
  const textEl = (x, y, an, text, face, color, size, box, glow = false) => {
    if (glow) els.push({ k: "text", glow: true, x, y, an, text, face, size, box });
    els.push({ k: "text", x, y, an, text, face, color, size, box });
  };
  let W = 0;
  let H = 0;
  if (style === "kutu") {
    const padX = Math.round(nameSize * 0.45);
    const hName = Math.round(nameSize * 1.5);
    const hRole = Math.round(roleSize * 2.1);
    const sub = [r, h].filter(Boolean).join("  \xB7  ");
    const wSub = sub ? wOf(sub, F.role, roleSize, sp) + (r && h ? roleSize : 0) : 0;
    const boxW = Math.round(wName + padX * 2);
    const subW = Math.round(wSub + padX * 2);
    shapeEl("bg", 0, 0, boxW, hName, rad(hName, 0), accent, alphaHex(bgOpacity ?? 1));
    textEl(padX, hName / 2, 4, n, NAME, nameColor ?? inkOn(accent), nameSize, [0, 0, boxW, hName]);
    if (sub) {
      shapeEl("bg", 0, hName, subW, hRole, rad(hRole, 0), bgColor, alphaHex(bgOpacity ?? 0.9));
      textEl(padX, hName + hRole / 2, 4, sub, ROLE, roleColor ?? "#FFFFFF", roleSize, [0, hName, subW, hRole]);
    }
    W = Math.max(boxW, subW);
    H = hName + (sub ? hRole : 0);
  } else if (style === "etiket") {
    const padX = Math.round(roleSize * 0.9);
    const hPill = Math.round(roleSize * 2);
    const pillW = Math.round(wRole + padX * 2);
    const gap = Math.round(nameSize * 0.22);
    let y = 0;
    if (r) {
      shapeEl("bg", 0, 0, pillW, hPill, rad(hPill, hPill / 2), accent, alphaHex(bgOpacity ?? 1));
      textEl(pillW / 2, hPill / 2, 5, r, ROLE, roleColor ?? inkOn(accent), roleSize, [0, 0, pillW, hPill]);
      y = hPill + gap;
    }
    textEl(0, y, 7, n, NAME, nameColor ?? "#FFFFFF", nameSize, [0, y, wName, nameSize * 1.2], true);
    y += nameSize * 1.2;
    if (h) {
      textEl(0, y, 7, h, HANDLE, "#DCDCDC", roleSize, [0, y, wHandle, roleSize * 1.5], true);
      y += roleSize * 1.5;
    }
    W = Math.max(wName, r ? pillW : 0, wHandle);
    H = y;
  } else {
    const under = style === "altcizgi";
    const panel = style === "cam";
    const lineW = Math.max(3, Math.round(u * 4e-3));
    const rows = [{ text: n, face: NAME, size: nameSize, h: nameSize * 1.16, color: nameColor ?? "#FFFFFF" }];
    if (r) rows.push({ text: r, face: ROLE, size: roleSize, h: roleSize * 1.5, color: roleColor ?? accent, gap: under ? nameSize * 0.22 + lineW : 0 });
    if (h) rows.push({ text: h, face: HANDLE, size: roleSize, h: roleSize * 1.5, color: panel && inkOn(bgColor) !== "#FFFFFF" ? "#555555" : "#DCDCDC", gap: under && !r ? nameSize * 0.22 + lineW : 0 });
    const blockH = rows.reduce((t, x) => t + x.h + (x.gap ?? 0), 0);
    const textW = Math.max(wName, wRole, wHandle);
    const barW = under ? 0 : Math.max(4, Math.round(u * 7e-3));
    const pad2 = Math.round(u * 0.022);
    const padP = panel ? Math.round(u * 0.02) : 0;
    W = padP * 2 + barW + (barW ? pad2 : 0) + textW + (panel ? pad2 * 0.5 : 0);
    H = blockH + padP * 2;
    if (panel) shapeEl("bg", 0, 0, W, H, rad(H, u * 0.012), bgColor, alphaHex(bgOpacity ?? 0.7));
    if (barW) shapeEl("bar", padP, padP, barW, blockH, panel ? barW / 2 : 0, accent, "00", { vertical: true });
    const tx = padP + barW + (barW ? pad2 : 0);
    let y = padP;
    rows.forEach((row, i) => {
      y += row.gap ?? 0;
      textEl(tx, y, 7, row.text, row.face, row.color, row.size, [tx, y, textW, row.h], !panel);
      if (under && i === 0) shapeEl("bar", tx, y + row.h + nameSize * 0.06, textW, lineW, 0, accent, "00");
      y += row.h;
    });
  }
  const logoSize = logo ? Math.round(Math.max(H, nameSize * 1.6)) : 0;
  const logoGap = logo ? Math.round(u * 0.02) : 0;
  const total = logoSize + logoGap + W;
  const m2 = Math.max(0, Math.min(0.3, margin));
  const x0 = Math.round(position === "orta" ? (width - total) / 2 : position === "sag" ? width * (1 - m2) - total : width * m2);
  const blockBottom = Math.round(height * Math.max(0.1, Math.min(0.98, bottom)));
  const bandH = Math.max(H, logoSize);
  const top = blockBottom - bandH;
  const ox = x0 + logoSize + logoGap;
  const oy = top + (bandH - H) / 2;
  const enter = entrance2 === "ozgun" ? OWN_ENTRANCE[style] ?? "kay" : entrance2;
  const X = 450;
  const life = Math.round(hold * 1e3);
  const s = sheet(width, height);
  const R = Math.round;
  const full = [ox - 12, oy - 12, ox + W + 60, oy + H + 12].map(R);
  const dist = Math.round(nameSize * 0.9);
  let order = 0;
  for (const e of els) {
    const isText = e.k === "text";
    const d = 40 + order * 70;
    if (!e.glow) order++;
    const ch = e.glow ? "3a" : "1a";
    const base = e.glow ? "80" : e.alpha ?? "00";
    const fadeIn = (t0, dur = 260) => `\\${ch}&HFF&\\t(${t0},${t0 + dur},\\${ch}&H${base}&)`;
    const fadeOut = (t0, t1) => `\\t(${t0},${t1},\\${ch}&HFF&)`;
    const [bx, by, bw, bh] = isText ? [ox + e.box[0], oy + e.box[1], e.box[2], e.box[3]] : [ox + e.x, oy + e.y, e.w, e.h];
    const px = R(isText ? ox + e.x : bx + bw / 2);
    const py = R(isText ? oy + e.y : by + bh / 2);
    const box = [bx - 6, by - 6, bx + bw + 14, by + bh + 6].map(R);
    const wipeIn = (t0, dur = 380) => `\\clip(${box[0]},${box[1]},${box[0]},${box[3]})\\t(${t0},${t0 + dur},0.6,\\clip(${box.join(",")}))`;
    const paint = isText ? e.glow ? `\\1a&HFF&\\bord${Math.max(2, R(e.size * 0.05))}\\3c&H000000&\\3a&H80&\\blur${Math.max(4, R(e.size * 0.12))}\\shad0` : `\\c${ac2(e.color)}\\bord0\\shad0` : `\\c${ac2(e.color)}\\1a&H${e.alpha}&\\bord0\\shad0`;
    const an = isText ? e.an : 7;
    const body = isText ? e.text : `{\\p1}${rectC(e.w, e.h, e.r)}{\\p0}`;
    const head = `\\an${an}${isText ? e.face : ""}${paint}`;
    let inTags;
    if (enter === "belir") inTags = `\\pos(${px},${py})${fadeIn(d)}`;
    else if (enter === "buyu") inTags = isText ? `\\pos(${px},${py})\\fscx85\\fscy85\\t(${d},${d + 260},\\fscx100\\fscy100)${fadeIn(d, 200)}` : `\\pos(${px},${py})\\fscx0\\fscy0\\t(${d},${d + 200},\\fscx108\\fscy108)\\t(${d + 200},${d + 300},\\fscx100\\fscy100)`;
    else if (enter === "sil") inTags = `\\pos(${px},${py})${wipeIn(d)}`;
    else if (enter === "yuksel") {
      if (isText) inTags = `\\clip(${box.join(",")})\\move(${px},${R(py + bh)},${px},${py},${d},${d + 380})`;
      else if (e.k === "bar") inTags = e.vertical ? `\\pos(${px},${py})\\fscy0\\t(${d},${d + 260},0.6,\\fscy100)` : `\\pos(${px},${py})${wipeIn(d, 460)}`;
      else inTags = `\\move(${px},${py + dist},${px},${py},${d},${d + 380})${fadeIn(d)}`;
    } else {
      if (isText) inTags = `\\clip(${full.join(",")})\\move(${px - Math.min(R(bw), nameSize * 4)},${py},${px},${py},${d},${d + 320})${e.glow ? fadeIn(d + 120) : ""}`;
      else if (e.k === "bar" && e.vertical) inTags = `\\pos(${px},${py})\\fscy0\\t(${d},${d + 240},0.6,\\fscy100)`;
      else inTags = `\\pos(${px},${py})${wipeIn(d, 320)}`;
    }
    let outTags;
    if (exit === "kay") outTags = `\\move(${px},${py},${px - dist * 2},${py},0,${X - 60})${fadeOut(0, X - 80)}`;
    else if (exit === "in") outTags = `\\move(${px},${py},${px},${py + dist},0,${X - 60})${fadeOut(0, X - 80)}`;
    else if (exit === "sil") outTags = `\\pos(${px},${py})\\clip(${box.join(",")})\\t(0,${X - 80},1.6,\\clip(${box[0]},${box[1]},${box[0]},${box[3]}))`;
    else outTags = `\\pos(${px},${py})${fadeOut(0, 280)}`;
    const layer = isText ? e.glow ? 1 : 4 : e.k === "bar" ? 3 : 0;
    const cut = (life - X) / 1e3;
    s.ev(layer, 0, cut, `{${head}${inTags}}${body}`);
    s.ev(layer, cut, hold + 0.05, `{${head}${outTags}}${body}`);
  }
  const images = logo ? [{ src: "logo", x: x0, y: R(top + (bandH - logoSize) / 2), w: logoSize, h: logoSize, round: Boolean(logoRound), fadeIn: 0.05, fadeOutAt: Math.max(0.3, hold - X / 1e3) }] : [];
  return { ass: s.done(), duration: hold + 0.1, images };
}
var cleanWord = (w) => String(w).toLocaleLowerCase("tr-TR").replace(/[^\p{L}\p{N}]/gu, "");
function buildEmoji({ width, height, items, color = "#FFFFFF", position = "top", scale = 1 }) {
  if (!(items == null ? void 0 : items.length)) throw new Error("Konu\u015Fmada emojiyle e\u015Fle\u015Fen kelime bulunamad\u0131");
  const u = unitOf(width, height);
  const size = Math.round(u * 0.13 * scale);
  const x = Math.round(width / 2);
  const y = Math.round(height * (position === "middle" ? 0.5 : position === "bottom" ? 0.56 : 0.3));
  const s = sheet(width, height);
  const hold = 1.2;
  for (const it of items) {
    const move = `\\an5\\move(${x},${y},${x},${y - Math.round(size * 0.25)},150,${hold * 1e3})\\fnNoto Emoji\\fs${size}\\fscx40\\fscy40\\t(0,130,\\fscx118\\fscy118)\\t(130,220,\\fscx100\\fscy100)\\t(${hold * 1e3 - 300},${hold * 1e3},\\alpha&HFF&)`;
    s.ev(0, it.time, it.time + hold, `{${move}\\1a&HFF&\\bord${Math.round(size * 0.04)}\\3c&H000000&\\3a&H80&\\blur${Math.round(size * 0.1)}\\shad0}${it.emoji}`);
    s.ev(1, it.time, it.time + hold, `{${move}\\c${ac2(color)}\\bord0\\shad0}${it.emoji}`);
  }
  return { ass: s.done(), duration: items[items.length - 1].time + hold + 0.1 };
}
function buildCinematic({ width, height, duration, bars = true, vignette = true, ratio = 2.35 }) {
  const s = sheet(width, height);
  if (bars) {
    const natural = (height - width / ratio) / 2;
    const bar = Math.round(natural > height * 0.03 ? natural : height * 0.07);
    s.ev(1, 0, duration, `{\\an7\\move(0,${-bar},0,0,0,450)\\c&H000000&\\bord0\\shad0\\p1}${rect(width, bar)}{\\p0}`);
    s.ev(1, 0, duration, `{\\an7\\move(0,${height},0,${height - bar},0,450)\\c&H000000&\\bord0\\shad0\\p1}${rect(width, bar)}{\\p0}`);
  }
  if (vignette) {
    const m2 = Math.round(Math.max(width, height) * 0.25);
    const ix = Math.round(width * 0.04);
    const iy = Math.round(height * 0.04);
    const shape = `m ${-m2} ${-m2} l ${width + m2} ${-m2} ${width + m2} ${height + m2} ${-m2} ${height + m2} m ${ix} ${iy} l ${ix} ${height - iy} ${width - ix} ${height - iy} ${width - ix} ${iy}`;
    s.ev(0, 0, duration, `{\\an7\\pos(0,0)\\c&H000000&\\1a&H70&\\bord0\\shad0\\blur${Math.round(Math.max(width, height) * 0.045)}\\fad(400,0)\\p1}${shape}{\\p0}`);
  }
  if (!bars && !vignette) throw new Error("Bant ya da kenar karartmadan en az biri se\xE7ilmeli");
  return { ass: s.done(), duration };
}
function buildFlash({ width, height, times, duration, mode = "flas" }) {
  const list = (times ?? []).filter((t) => t > 0.2 && t < duration - 0.1);
  if (!list.length) throw new Error("Zaman \xE7izelgesinde kesim bulunamad\u0131 (en az iki klip gerekli)");
  const s = sheet(width, height);
  const full = rect(width, height);
  for (const t of list) {
    if (mode === "kararma") s.ev(0, t - 0.14, t + 0.16, `{\\an7\\pos(0,0)\\c&H000000&\\bord0\\shad0\\fad(140,160)\\p1}${full}{\\p0}`);
    else s.ev(0, t - 0.02, t + 0.24, `{\\an7\\pos(0,0)\\c&HFFFFFF&\\1a&H38&\\bord0\\shad0\\t(20,260,\\1a&HFF&)\\p1}${full}{\\p0}`);
  }
  return { ass: s.done(), duration, count: list.length };
}
function buildProgress({ width, height, duration, chapters = [], accent = "#A855F7", position = "bottom", showTitles = true }) {
  const s = sheet(width, height);
  const u = unitOf(width, height);
  const h = Math.max(4, Math.round(u * 8e-3));
  const y = position === "top" ? 0 : height - h;
  const ms = Math.round(duration * 1e3);
  s.ev(0, 0, duration, `{\\an7\\pos(0,${y})\\c&HFFFFFF&\\1a&HC8&\\bord0\\shad0\\p1}${rect(width, h)}{\\p0}`);
  s.ev(1, 0, duration, `{\\an7\\pos(0,${y})\\c${ac2(accent)}\\bord0\\shad0\\fscx0\\t(0,${ms},\\fscx100)\\p1}${rect(width, h)}{\\p0}`);
  const list = chapters.filter((c) => c.start < duration);
  const size = Math.round(u * 0.024);
  list.forEach((c, i) => {
    var _a;
    const end = ((_a = list[i + 1]) == null ? void 0 : _a.start) ?? duration;
    if (i > 0) s.ev(2, 0, duration, `{\\an7\\pos(${Math.round(c.start / duration * width) - 1},${y})\\c&H000000&\\1a&H50&\\bord0\\shad0\\p1}${rect(3, h)}{\\p0}`);
    if (showTitles && esc2(c.title)) {
      const ty = position === "top" ? h + Math.round(size * 0.6) : y - Math.round(size * 1.7);
      const tags = `\\an7\\pos(${Math.round(width * 0.03)},${ty})\\fnMontserrat SemiBold\\fs${size}\\fsp${f1(size * 0.08)}\\fad(250,250)`;
      s.ev(2, c.start, end, `{${tags}\\1a&HFF&\\bord${Math.max(2, Math.round(size * 0.08))}\\3c&H000000&\\3a&H70&\\blur${Math.round(size * 0.2)}\\shad0}${upperTr(esc2(c.title))}`);
      s.ev(3, c.start, end, `{${tags}\\bord0\\shad0}${upperTr(esc2(c.title))}`);
    }
  });
  return { ass: s.done(), duration };
}
function buildSubscribe({ width, height, measure, text = "ABONE OL", done = "ABONE OLUNDU", hold = 4 }) {
  const u = unitOf(width, height);
  const size = Math.round(u * 0.038);
  const m2 = measure == null ? void 0 : measure("Montserrat Black");
  const wOf = (t) => m2 ? m2.width(t, size) : t.length * size * 0.7;
  const a = upperTr(esc2(text)) || "ABONE OL";
  const b = upperTr(esc2(done)) || a;
  const icon = size * 1.5;
  const padX = Math.round(size * 0.9);
  const bh = Math.round(size * 2.1);
  const cx = Math.round(width / 2);
  const cy = Math.round(height * 0.84);
  const press = 1700;
  const s = sheet(width, height);
  const part = (label, color, bell, from, to, anim) => {
    const bw = Math.round(wOf(label) + icon + padX * 2);
    const base = `\\an5\\pos(${cx},${cy})${anim}`;
    s.ev(0, from, to, `{${base}\\c&H000000&\\1a&H90&\\bord0\\shad0\\blur${Math.round(size * 0.5)}\\p1}${rect(bw, bh, bh / 2)}{\\p0}`);
    s.ev(1, from, to, `{${base}\\c${ac2(color)}\\bord0\\shad0\\p1}${rect(bw, bh, bh / 2)}{\\p0}`);
    const tx = Math.round(cx + icon / 2);
    s.ev(2, from, to, `{\\an5\\pos(${tx},${cy})${anim}\\fnMontserrat Black\\fs${size}\\bord0\\shad0}${label}`);
    s.ev(2, from, to, `{\\an5\\pos(${Math.round(cx - bw / 2 + padX + icon / 3)},${cy})${anim}\\fnNoto Emoji\\fs${Math.round(size * 1.15)}\\bord0\\shad0}${bell}`);
  };
  part(a, "#FF0033", "\u{1F514}", 0, press / 1e3, `\\fscx30\\fscy30\\t(0,160,\\fscx108\\fscy108)\\t(160,260,\\fscx100\\fscy100)\\t(${press - 140},${press},\\fscx92\\fscy92)\\fad(120,0)`);
  const life = hold * 1e3 - press;
  part(b, "#3F3F46", "\u2705", press / 1e3, hold, `\\fscx92\\fscy92\\t(0,140,\\fscx104\\fscy104)\\t(140,240,\\fscx100\\fscy100)\\t(${life - 300},${life},\\alpha&HFF&)`);
  return { ass: s.done(), duration: hold + 0.1 };
}
function punchSpans(segments, { every = 2, minLength = 0.5 } = {}) {
  const out = [];
  segments.forEach((seg, i) => {
    if (i % every !== 0) return;
    const words = (seg.words ?? []).filter((w) => cleanWord(w.text));
    if (!words.length) return;
    const e = Number.isInteger(seg.emphasis) && words[seg.emphasis] ? seg.emphasis : pickEmphasis(words);
    const start = words[e].start;
    const end = Math.max(seg.end, start + minLength);
    if (end - start >= minLength) out.push([start, end]);
  });
  return out;
}
var TRANSITIONS = [
  { id: "supurme", group: "panel", name: "S\xFCp\xFCrme", sub: "Renkli panel soldan sa\u011Fa ge\xE7er", sound: "H\u0131zl\u0131 Whoosh", anchor: 0.236, tint: true },
  { id: "ciftsupurme", group: "panel", name: "\xC7ift s\xFCp\xFCrme", sub: "\xDC\xE7 renkli panel sa\u011Fdan sola kovalar", sound: "Swish \xC7ift \u0130nce", file: "cift", anchor: 0.13, tint: true },
  { id: "yukari", group: "panel", name: "Yukar\u0131", sub: "Panel a\u015Fa\u011F\u0131dan yukar\u0131 ge\xE7er", sound: "H\u0131zl\u0131 Whoosh", file: "supurme", anchor: 0.236, tint: true },
  { id: "asagi", group: "panel", name: "A\u015Fa\u011F\u0131", sub: "Panel yukar\u0131dan a\u015Fa\u011F\u0131 ge\xE7er", sound: "Whoosh A\u015Fa\u011F\u0131 K\u0131sa", file: "asagi", anchor: 0.089, tint: true },
  { id: "ok", group: "panel", name: "Ok", sub: "Sivri u\xE7lu panel soldan sa\u011Fa", sound: "H\u0131zl\u0131 Whoosh", file: "supurme", anchor: 0.236, tint: true },
  { id: "capraz", group: "panel", name: "\xC7apraz", sub: "E\u011Fik panel k\xF6\u015Feden k\xF6\u015Feye", sound: "Keskin Swish", anchor: 0.073, tint: true },
  { id: "ciftcapraz", group: "panel", name: "\xC7ift \xE7apraz", sub: "\u0130ki e\u011Fik panel ortada bulu\u015Fur", sound: "Keskin Swish", file: "capraz", anchor: 0.073, tint: true },
  { id: "perde", group: "panel", name: "Perde", sub: "\u0130ki yandan kapan\u0131r, a\xE7\u0131l\u0131r", sound: "Whoosh Orta", anchor: 0.26, tint: true },
  { id: "kepenk", group: "panel", name: "Kepenk", sub: "\xDCstten ve alttan kapan\u0131r", sound: "Whoosh Orta", file: "perde", anchor: 0.26, tint: true },
  { id: "koseler", group: "panel", name: "K\xF6\u015Feler", sub: "D\xF6rt k\xF6\u015Feden d\xF6rt panel", sound: "Swish \xC7ift \u0130nce", file: "cift", anchor: 0.13, tint: true },
  { id: "seritler", group: "panel", name: "\u015Eeritler", sub: "Yatay \u015Feritler kar\u015F\u0131l\u0131kl\u0131 kayar", sound: "Swish \xDC\xE7l\xFC", anchor: 0.17, tint: true },
  { id: "dikey", group: "panel", name: "Dikey \u015Feritler", sub: "Dikey \u015Feritler kar\u015F\u0131l\u0131kl\u0131 kayar", sound: "Swish \xDC\xE7l\xFC", file: "seritler", anchor: 0.17, tint: true },
  { id: "jaluzi", group: "panel", name: "Jaluzi", sub: "Yatay \xE7ubuklar kal\u0131nla\u015F\u0131p kapan\u0131r", sound: "Swish \xC7ift \u0130nce", file: "cift", anchor: 0.13, tint: true },
  { id: "cizgi", group: "panel", name: "\xC7izgi", sub: "Ortadaki \xE7izgi ekran\u0131 kaplar", sound: "Whoosh Ge\xE7 Tepe", file: "gec", anchor: 0.5, tint: true },
  { id: "daire", group: "sekil", name: "Daire", sub: "Ortadan b\xFCy\xFCyen daire", sound: "Whoosh K\u0131sa Bas", anchor: 0.14, tint: true },
  { id: "elmas", group: "sekil", name: "Elmas", sub: "Ortadan b\xFCy\xFCyen e\u015Fkenar d\xF6rtgen", sound: "Whoosh K\u0131sa Bas", file: "daire", anchor: 0.14, tint: true },
  { id: "kare", group: "sekil", name: "D\xF6nen kare", sub: "D\xF6nerek b\xFCy\xFCyen kare", sound: "Whoosh Ge\xE7 Tepe", file: "gec", anchor: 0.5, tint: true },
  { id: "yildiz", group: "sekil", name: "Y\u0131ld\u0131z", sub: "Ortadan b\xFCy\xFCyen y\u0131ld\u0131z", sound: "Pop \xDC\xE7l\xFC", file: "pop3", anchor: 0.14, tint: true },
  { id: "kalp", group: "sekil", name: "Kalp", sub: "Ortadan b\xFCy\xFCyen kalp", sound: "Pop \xDC\xE7l\xFC", file: "pop3", anchor: 0.14, tint: true },
  { id: "dama", group: "sekil", name: "Dama", sub: "Kareler \xE7aprazlama dolar", sound: "Swish \xDC\xE7l\xFC", file: "seritler", anchor: 0.17, tint: true },
  { id: "noktalar", group: "sekil", name: "Noktalar", sub: "B\xFCy\xFCyen noktalar ekran\u0131 kaplar", sound: "Pop \xDC\xE7l\xFC", file: "pop3", anchor: 0.14, tint: true },
  { id: "kirpma", group: "sekil", name: "G\xF6z k\u0131rpma", sub: "Yumu\u015Fak kenarl\u0131 g\xF6z kapa\u011F\u0131", sound: "Kamera Hareketi", anchor: 0.362, tint: true },
  { id: "flas", group: "isik", name: "Fla\u015F", sub: "Beyaz parlama", sound: "Whoosh \xC7ok K\u0131sa", anchor: 0.074, tint: false },
  { id: "karartma", group: "isik", name: "Karartma", sub: "Karar\u0131p a\xE7\u0131l\u0131r", sound: "Whoosh Orta Bas", anchor: 0.305, tint: true },
  { id: "isik", group: "isik", name: "I\u015F\u0131k s\u0131z\u0131nt\u0131s\u0131", sub: "S\u0131cak \u0131\u015F\u0131k s\xFCz\xFCl\xFCr", sound: "Haval\u0131 Ge\xE7i\u015F", anchor: 0.425, tint: false },
  { id: "film", group: "isik", name: "Film yan\u0131\u011F\u0131", sub: "Film kenardan yanar", sound: "Haval\u0131 Ge\xE7i\u015F", file: "isik", anchor: 0.425, tint: false },
  { id: "strobe", group: "isik", name: "\xC7akma", sub: "Art arda k\u0131sa parlamalar", sound: "Deklan\u015F\xF6r", file: "deklansor", anchor: 0, tint: false },
  { id: "deklansor", group: "isik", name: "Deklan\u015F\xF6r", sub: "Karar\u0131r, fla\u015F patlar", sound: "Deklan\u015F\xF6r", file: "deklansor", anchor: 0.01, tint: false },
  { id: "glitch", group: "dijital", name: "Glitch", sub: "Dijital bozulma", sound: "Glitch K\u0131sa", anchor: 0.078, tint: false },
  { id: "mozaik", group: "dijital", name: "Mozaik", sub: "Kareler rastgele dolar", sound: "Glitch K\u0131sa", file: "glitch", anchor: 0.078, tint: true },
  { id: "tv", group: "dijital", name: "TV kapan\u0131\u015F\u0131", sub: "Ekran \xE7izgiye, sonra noktaya iner", sound: "TV Kapan\u0131\u015F\u0131", file: "tv", anchor: 0.27, tint: false }
];
var SHAPES = {
  elmas: { path: "m 100 0 l 200 100 100 200 0 100", inner: 70.7 },
  kare: { path: "m 0 0 l 200 0 200 200 0 200", inner: 100 },
  yildiz: { path: "m 100 0 l 126.5 63.6 195.1 69.1 142.8 113.9 158.8 180.9 100 145 41.2 180.9 57.2 113.9 4.9 69.1 73.5 63.6", inner: 38 },
  kalp: { path: "m 100 190 b 20 125 0 85 0 58 b 0 22 26 0 56 0 b 76 0 92 12 100 32 b 108 12 124 0 144 0 b 174 0 200 22 200 58 b 200 85 180 125 100 190", inner: 40 }
};
var CLIP_TRANSITIONS = [
  { id: "erime", name: "Yumu\u015Fak ge\xE7i\u015F", sub: "\u0130ki g\xF6r\xFCnt\xFC birbirine erir", sound: "Haval\u0131 Ge\xE7i\u015F", file: "isik", anchor: 0.425 },
  { id: "bulanik", name: "Bulan\u0131k ge\xE7i\u015F", sub: "Bulan\u0131kla\u015F\u0131p yeni klibe netle\u015Fir", sound: "Whoosh Orta Bas", file: "karartma", anchor: 0.305 },
  { id: "zoomin", name: "Zoom i\xE7eri", sub: "\u0130\xE7eri dalar, yeni klip yerine oturur", sound: "Whoosh Orta", file: "zoom", anchor: 0.26 },
  { id: "zoomout", name: "Zoom d\u0131\u015Far\u0131", sub: "Geri \xE7ekilir, yeni klip yakla\u015Farak gelir", sound: "Whoosh Orta", file: "zoom", anchor: 0.26 },
  { id: "itsola", name: "Sola itme", sub: "Yeni klip eskisini sola iter", sound: "Whoosh Soldan Sa\u011Fa", file: "kaydir", anchor: 0.271 },
  { id: "itsaga", name: "Sa\u011Fa itme", sub: "Yeni klip eskisini sa\u011Fa iter", sound: "Whoosh Soldan Sa\u011Fa", file: "kaydir", anchor: 0.271 },
  { id: "ityukari", name: "Yukar\u0131 itme", sub: "Yeni klip eskisini yukar\u0131 iter", sound: "H\u0131zl\u0131 Whoosh", file: "supurme", anchor: 0.236 },
  { id: "sola", name: "Sola savurma", sub: "G\xF6r\xFCnt\xFC h\u0131zla sola akar", sound: "Whoosh Soldan Sa\u011Fa", file: "kaydir", anchor: 0.271 },
  { id: "saga", name: "Sa\u011Fa savurma", sub: "G\xF6r\xFCnt\xFC h\u0131zla sa\u011Fa akar", sound: "Whoosh Soldan Sa\u011Fa", file: "kaydir", anchor: 0.271 },
  { id: "yukarikay", name: "Yukar\u0131 savurma", sub: "G\xF6r\xFCnt\xFC h\u0131zla yukar\u0131 akar", sound: "Whoosh Soldan Sa\u011Fa", file: "kaydir", anchor: 0.271 },
  { id: "don", name: "D\xF6nme", sub: "D\xF6nerek ge\xE7er", sound: "D\xF6nen Whoosh", file: "don", anchor: 0.762 },
  { id: "yakin", name: "Yak\u0131nla\u015Farak", sub: "Yak\u0131nla\u015F\u0131rken yeni klibe erir", sound: "Whoosh Orta", file: "zoom", anchor: 0.26 },
  { id: "beyaz", name: "Beyaza ge\xE7i\u015F", sub: "Beyaza a\xE7\u0131l\u0131p yeni klibe d\xF6ner", sound: "Whoosh \xC7ok K\u0131sa", file: "flas", anchor: 0.074 },
  { id: "siyah", name: "Siyaha ge\xE7i\u015F", sub: "Karar\u0131p yeni klipte a\xE7\u0131l\u0131r", sound: "Whoosh Orta Bas", file: "karartma", anchor: 0.305 },
  { id: "yumusak", name: "Yumu\u015Fak s\xFCp\xFCrme", sub: "Yumu\u015Fak kenarl\u0131 s\xFCp\xFCrme", sound: "H\u0131zl\u0131 Whoosh", file: "supurme", anchor: 0.236 },
  { id: "daireac", name: "Daire a\xE7\u0131lma", sub: "Yeni klip ortadan daireyle a\xE7\u0131l\u0131r", sound: "Whoosh K\u0131sa Bas", file: "daire", anchor: 0.14 },
  { id: "radyal", name: "Saat", sub: "Saat ibresi gibi d\xF6ner", sound: "Whoosh Ge\xE7 Tepe", file: "gec", anchor: 0.5 },
  { id: "piksel", name: "Pikselle\u015Fme", sub: "Pikselle\u015Fip yeni klibe \xE7\xF6z\xFCl\xFCr", sound: "Glitch K\u0131sa", file: "glitch", anchor: 0.078 },
  { id: "dagil", name: "Da\u011F\u0131lma", sub: "Tanecikler h\xE2linde da\u011F\u0131l\u0131r", sound: "Haval\u0131 Ge\xE7i\u015F", file: "isik", anchor: 0.425 }
];
var CIRCLE = "m 100 0 b 155.2 0 200 44.8 200 100 b 200 155.2 155.2 200 100 200 b 44.8 200 0 155.2 0 100 b 0 44.8 44.8 0 100 0";
function seeded(seed) {
  let a = seed >>> 0;
  return () => {
    a = a + 1831565813 >>> 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function buildTransition({ width: W, height: H, id = "supurme", color = "#000000", accent, lead = 0, tail: tail2 = 0 }) {
  if (!TRANSITIONS.some((t) => t.id === id)) throw new Error(`Bilinmeyen ge\xE7i\u015F: ${id}`);
  const s = sheet(W, H);
  const neutral = /^#(0{6}|f{6}|1{6})$/i.test(color);
  const main = ac2(color);
  const acc = ac2(accent ?? (neutral ? "#A855F7" : "#FFFFFF"));
  const ms = (t) => Math.round(t * 1e3);
  const R = Math.round;
  const flat = "\\bord0\\shad0";
  const ev = (layer, a, b, text) => s.ev(layer, lead + a, lead + b, text);
  const panel = (c, w, h) => `\\c${c}${flat}\\p1}${rect(w, h)}{\\p0}`;
  let D;
  let mid;
  const EASE = {
    io: (u) => u < 0.5 ? 4 * u * u * u : 1 - Math.pow(2 - 2 * u, 3) / 2,
    out: (u) => 1 - Math.pow(1 - u, 3),
    in: (u) => u * u * u
  };
  const glide = (layer, t0, t1, from, to, ease, body, pre = "\\an7") => {
    const n = Math.max(1, Math.round((t1 - t0) / 0.02));
    const at = (u) => `${R(from[0] + (to[0] - from[0]) * u)},${R(from[1] + (to[1] - from[1]) * u)}`;
    for (let i = 0; i < n; i++) {
      ev(layer, t0 + (t1 - t0) * i / n, t0 + (t1 - t0) * (i + 1) / n, `{${pre}\\move(${at(EASE[ease](i / n))},${at(EASE[ease]((i + 1) / n))})${body}`);
    }
  };
  const hold = (layer, t0, t1, pos, body, pre = "\\an7") => ev(layer, t0, t1, `{${pre}\\pos(${R(pos[0])},${R(pos[1])})${body}`);
  const shut = (layer, open, closed, body, [closeEnd, openStart, end], pre) => {
    glide(layer, 0, closeEnd, open, closed, "out", body, pre);
    hold(layer, closeEnd, openStart, closed, body, pre);
    glide(layer, openStart, end, closed, open, "in", body, pre);
  };
  const SWEEP = { supurme: [1, 0], ok: [1, 0], yukari: [0, -1], asagi: [0, 1] };
  if (SWEEP[id]) {
    const [dx, dy] = SWEEP[id];
    const Ds = 0.7;
    const lag = 0.04;
    const tip = id === "ok" ? R(H * 0.35) : 0;
    const bw = dx ? R(2.4 * W) : W;
    const bh = dy ? R(2.4 * H) : H;
    const shape = (c) => tip ? `\\c${c}${flat}\\p1}m 0 0 l ${bw} 0 ${bw + tip} ${R(H / 2)} ${bw} ${H} 0 ${H} ${tip} ${R(H / 2)}{\\p0}` : panel(c, bw, bh);
    const from = dx ? [-(bw + tip), 0] : dy < 0 ? [0, H] : [0, -bh];
    const to = dx ? [W, 0] : dy < 0 ? [0, -bh] : [0, H];
    D = Ds + lag;
    mid = lag + Ds / 2;
    glide(0, 0, Ds, from, to, "io", shape(acc));
    glide(1, lag, D, from, to, "io", shape(main));
  } else if (id === "ciftsupurme") {
    const Ds = 0.66;
    const lag = 0.04;
    const pw = R(2.4 * W);
    D = Ds + 2 * lag;
    mid = 2 * lag + Ds / 2;
    [acc, "&HFFFFFF&", main].forEach((c, i) => glide(i, i * lag, i * lag + Ds, [W, 0], [-pw, 0], "io", panel(c, pw, H)));
  } else if (id === "capraz") {
    const Ds = 0.7;
    const lag = 0.04;
    const diag = Math.hypot(W, H);
    const w = R(2.4 * diag);
    const h = R(2.6 * diag);
    const th = 20 * Math.PI / 180;
    const reach = w / 2 + diag / 2 + 4;
    const [ux, uy] = [Math.cos(th), -Math.sin(th)];
    const from = [W / 2 - ux * reach, H / 2 - uy * reach];
    const to = [W / 2 + ux * reach, H / 2 + uy * reach];
    D = Ds + lag;
    mid = lag + Ds / 2;
    glide(0, 0, Ds, from, to, "io", panel(acc, w, h), "\\an5\\frz20");
    glide(1, lag, D, from, to, "io", panel(main, w, h), "\\an5\\frz20");
  } else if (id === "ciftcapraz") {
    D = 0.76;
    mid = 0.38;
    const diag = Math.hypot(W, H);
    const w = R(1.2 * diag);
    const h = R(2.4 * diag);
    const th = 20 * Math.PI / 180;
    const [ux, uy] = [Math.cos(th), -Math.sin(th)];
    const far = w / 2 + diag / 2 + 4;
    const near = w / 2 - diag * 0.03;
    for (const [sign, c] of [[-1, main], [1, acc]]) {
      const at = (d) => [W / 2 + sign * ux * d, H / 2 + sign * uy * d];
      shut(1, at(far), at(near), panel(c, w, h), [0.28, 0.44, D], "\\an5\\frz20");
    }
  } else if (id === "perde" || id === "kepenk" || id === "koseler") {
    D = 0.76;
    mid = 0.38;
    const times = [0.28, 0.44, D];
    const hw = R(W / 2) + 2;
    const hh = R(H / 2) + 2;
    if (id === "perde") {
      const edge = R(W * 0.012);
      for (const [layer, c, extra] of [[0, acc, edge], [1, main, 0]]) {
        shut(layer, [-hw, 0], [extra, 0], panel(c, hw, H), times);
        shut(layer, [W, 0], [W - hw - extra, 0], panel(c, hw, H), times);
      }
    } else if (id === "kepenk") {
      const edge = R(H * 0.014);
      for (const [layer, c, extra] of [[0, acc, edge], [1, main, 0]]) {
        shut(layer, [0, -hh], [0, extra], panel(c, W, hh), times);
        shut(layer, [0, H], [0, H - hh - extra], panel(c, W, hh), times);
      }
    } else {
      const q = [
        [[0, 0], [-hw, -hh], main],
        [[W - hw, 0], [W, -hh], acc],
        [[0, H - hh], [-hw, H], acc],
        [[W - hw, H - hh], [W, H], main]
      ];
      for (const [closed, open, c] of q) shut(1, open, closed, panel(c, hw, hh), times);
    }
  } else if (id === "seritler" || id === "dikey") {
    const vertical = id === "dikey";
    const N = vertical ? 8 : 6;
    const Ds = 0.8;
    const step = 0.02;
    D = Ds + step * (N - 1);
    mid = D / 2;
    for (let i = 0; i < N; i++) {
      const c = i % 3 === 1 ? acc : main;
      const fwd = i % 2 === 0;
      if (vertical) {
        const x = R(i * W / N);
        const ph = R(4.6 * H);
        glide(1, i * step, i * step + Ds, [x, fwd ? -ph : H], [x, fwd ? H : -ph], "io", panel(c, Math.ceil(W / N) + 1, ph));
      } else {
        const y = R(i * H / N);
        const pw = R(4 * W);
        glide(1, i * step, i * step + Ds, [fwd ? -pw : W, y], [fwd ? W : -pw, y], "io", panel(c, pw, Math.ceil(H / N) + 1));
      }
    }
  } else if (id === "kirpma") {
    D = 0.66;
    mid = 0.3;
    const bh = R(H * 0.62);
    const m2 = R(W * 0.05);
    const blur = Math.max(2, R(H * 0.02));
    const bar = `\\blur${blur}${panel(main, W + 2 * m2, bh)}`;
    const times = [0.22, 0.38, D];
    shut(1, [-m2, -bh - blur * 3], [-m2, R(H * 0.56) - bh], bar, times);
    shut(1, [-m2, H + blur * 3], [-m2, R(H * 0.44)], bar, times);
  } else if (id === "flas") {
    D = 0.45;
    mid = 0.2;
    ev(0, 0, D, `{\\an7\\pos(0,0)\\1a&HFF&\\t(0,160,0.7,\\1a&H00&)\\t(240,450,1.4,\\1a&HFF&)${panel("&HFFFFFF&", W, H)}`);
  } else if (id === "karartma") {
    D = 0.7;
    mid = 0.35;
    ev(0, 0, D, `{\\an7\\pos(0,0)\\1a&HFF&\\t(0,280,\\1a&H00&)\\t(420,700,\\1a&HFF&)${panel(main, W, H)}`);
  } else if (id === "daire") {
    D = 0.7;
    mid = 0.35;
    const S = Math.ceil(Math.hypot(W, H) / 2 * 1.1);
    const circle = (c) => `\\c${c}${flat}\\p1}${CIRCLE}{\\p0}`;
    const pos = `\\an5\\pos(${R(W / 2)},${R(H / 2)})`;
    ev(0, 0, mid, `{${pos}\\fscx1\\fscy1\\t(0,230,0.7,\\fscx${S}\\fscy${S})${circle(acc)}`);
    ev(1, 0, mid, `{${pos}\\fscx1\\fscy1\\t(50,280,0.7,\\fscx${S}\\fscy${S})${circle(main)}`);
    ev(1, mid, D, `{${pos}\\fscx${S}\\fscy${S}\\t(70,300,1.5,\\fscx1\\fscy1)${circle(main)}`);
    ev(0, mid, D, `{${pos}\\fscx${S}\\fscy${S}\\t(120,350,1.5,\\fscx1\\fscy1)${circle(acc)}`);
  } else if (id === "glitch") {
    D = 0.4;
    mid = 0.2;
    const rnd = seeded(20261113);
    const steps = 12;
    const dt = D / steps;
    const colors = ["#00E5FF", "#FF2BD6", "#FFFFFF", "#0B0B0F", "#A855F7"];
    for (let k = 0; k < steps; k++) {
      const power = 1 - Math.abs(k - (steps - 1) / 2) / (steps / 2);
      if (k >= 4 && k <= 7) ev(0, k * dt, (k + 1) * dt, `{\\an7\\pos(0,0)${panel(k === 5 || k === 6 ? "&HFFFFFF&" : "&H0F0B0B&", W, H)}`);
      const n = R(2 + 7 * power);
      for (let j = 0; j < n; j++) {
        const bw = R(W * (0.25 + 0.75 * rnd()));
        const bhh = R(H * (0.015 + 0.11 * rnd() * (0.4 + power)));
        const x = R((W - bw) * rnd() + (rnd() - 0.5) * W * 0.2);
        const y = R((H - bhh) * rnd());
        const a = ["00", "00", "40", "70"][Math.floor(rnd() * 4)];
        ev(1, k * dt, (k + 1) * dt, `{\\an7\\pos(${x},${y})\\1a&H${a}&${panel(ac2(colors[Math.floor(rnd() * colors.length)]), bw, bhh)}`);
      }
    }
  } else if (id === "isik") {
    D = 0.9;
    mid = 0.45;
    const u = Math.max(W, H);
    const blur = Math.min(90, Math.max(8, R(u * 0.045)));
    const blob = (c, a, sx, sy, y, t0, t1) => {
      const cy = R(H * y);
      ev(1, t0, t1, `{\\an5\\move(${R(-u * 0.5)},${cy},${R(W + u * 0.5)},${cy})\\fscx${R(u * sx)}\\fscy${R(u * sy)}\\1a&H${a}&\\blur${blur}\\c${ac2(c)}${flat}\\p1}${CIRCLE}{\\p0}`);
    };
    blob("#FF7A1A", "30", 0.45, 0.75, 0.45, 0, 0.8);
    blob("#FFD34D", "48", 0.28, 0.5, 0.6, 0.1, 0.9);
    blob("#FF3D6E", "70", 0.22, 0.4, 0.3, 0.05, 0.75);
    ev(2, 0.15, 0.8, `{\\an7\\pos(0,0)\\1a&HFF&\\t(0,240,0.8,\\1a&H00&)\\t(360,650,1.3,\\1a&HFF&)${panel(ac2("#FFF0D0"), W, H)}`);
  } else if (id === "jaluzi") {
    D = 0.7;
    mid = 0.35;
    const N = 8;
    const hb = Math.ceil(H / N) + 1;
    for (let i = 0; i < N; i++) {
      const y = R(i * H / N);
      const d = i * 12;
      ev(1, 0, mid, `{\\an7\\pos(0,${y})\\fscy0\\t(${d},${190 + d},0.8,\\fscy100)${panel(i % 2 ? acc : main, W, hb)}`);
      ev(1, mid, D, `{\\an7\\pos(0,${y})\\fscy100\\t(${80 + d},${270 + d},1.3,\\fscy0)${panel(i % 2 ? acc : main, W, hb)}`);
    }
  } else if (id === "cizgi") {
    D = 0.7;
    mid = 0.35;
    const pos = `\\an5\\pos(${R(W / 2)},${R(H / 2)})`;
    for (const [layer, c, lagMs] of [[0, acc, 0], [1, main, 40]]) {
      ev(layer, 0, mid, `{${pos}\\fscy0\\t(${lagMs},${lagMs + 70},\\fscy2)\\t(${lagMs + 70},${lagMs + 240},0.7,\\fscy102)${panel(c, W, H)}`);
      ev(layer, mid, D, `{${pos}\\fscy102\\t(${110 - lagMs},${280 - lagMs},1.4,\\fscy2)\\t(${280 - lagMs},${350 - lagMs},\\fscy0)${panel(c, W, H)}`);
    }
  } else if (SHAPES[id]) {
    D = 0.7;
    mid = 0.35;
    const sh = SHAPES[id];
    const S = Math.ceil(Math.hypot(W, H) / 2 * 1.12 * 100 / sh.inner);
    const spin = id === "kare";
    const draw = (c) => `\\c${c}${flat}\\p1}${sh.path}{\\p0}`;
    const pos = `\\an5\\pos(${R(W / 2)},${R(id === "kalp" ? H * 0.52 : H / 2)})`;
    const grow = (a, bms) => `\\fscx1\\fscy1${spin ? "\\frz-90" : ""}\\t(${a},${bms},0.7,\\fscx${S}\\fscy${S}${spin ? "\\frz0" : ""})`;
    const shrink = (a, bms) => `\\fscx${S}\\fscy${S}${spin ? "\\frz0" : ""}\\t(${a},${bms},1.5,\\fscx1\\fscy1${spin ? "\\frz90" : ""})`;
    ev(0, 0, mid, `{${pos}${grow(0, 230)}${draw(acc)}`);
    ev(1, 0, mid, `{${pos}${grow(50, 280)}${draw(main)}`);
    ev(1, mid, D, `{${pos}${shrink(70, 300)}${draw(main)}`);
    ev(0, mid, D, `{${pos}${shrink(120, 350)}${draw(acc)}`);
  } else if (id === "dama" || id === "noktalar") {
    D = 0.8;
    mid = 0.4;
    const cols = W >= H ? 8 : 5;
    const cell = Math.ceil(W / cols);
    const rows = Math.ceil(H / cell);
    const dots = id === "noktalar";
    const spread = 150;
    const size = dots ? Math.ceil(cell * 0.75) : 100;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const d = R(spread * (c + r) / (cols + rows - 2));
        const pos = `\\an5\\pos(${R(c * cell + cell / 2)},${R(r * cell + cell / 2)})`;
        const col = (c + r) % 4 === 1 ? acc : main;
        const shape = dots ? `\\c${col}${flat}\\p1}${CIRCLE}{\\p0}` : panel(col, cell + 2, cell + 2);
        ev(1, 0, mid, `{${pos}\\fscx0\\fscy0\\t(${d},${d + 190},0.8,\\fscx${size}\\fscy${size})${shape}`);
        ev(1, mid, D, `{${pos}\\fscx${size}\\fscy${size}\\t(${60 + d},${250 + d},1.3,\\fscx0\\fscy0)${shape}`);
      }
    }
  } else if (id === "mozaik") {
    D = 0.7;
    mid = 0.35;
    const rnd = seeded(20261114);
    const cols = W >= H ? 10 : 6;
    const cell = Math.ceil(W / cols);
    const rows = Math.ceil(H / cell);
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const on = rnd() * 0.26;
        const off = D - rnd() * 0.26;
        const col = rnd() < 0.18 ? acc : main;
        ev(1, on, off, `{\\an7\\pos(${c * cell},${r * cell})${panel(col, cell + 1, cell + 1)}`);
      }
    }
  } else if (id === "film") {
    D = 0.85;
    mid = 0.42;
    const rnd = seeded(20261115);
    const u = Math.max(W, H);
    const blur = Math.min(90, Math.max(8, R(u * 0.04)));
    for (let i = 0; i < 7; i++) {
      const c = ["#FF3B1F", "#FF7A1A", "#FFC531", "#FF5A2A"][i % 4];
      const t0 = rnd() * 0.18;
      const cy = R(H * rnd());
      const sx = R(u * (0.18 + rnd() * 0.3));
      const sy = R(u * (0.25 + rnd() * 0.4));
      const a = ["20", "38", "50"][i % 3];
      ev(1, t0, t0 + 0.6, `{\\an5\\move(${R(W + u * 0.4)},${cy},${R(-u * 0.4)},${R(cy + (rnd() - 0.5) * H * 0.3)})\\fscx${sx}\\fscy${sy}\\1a&H${a}&\\blur${blur}\\c${ac2(c)}${flat}\\p1}${CIRCLE}{\\p0}`);
    }
    for (let k = 0; k < 6; k++) ev(2, 0.1 + k * 0.04, 0.14 + k * 0.04, `{\\an7\\pos(0,0)\\1a&H${["B0", "70", "A0", "50", "80", "30"][k]}&${panel(ac2("#FF6A1F"), W, H)}`);
    ev(3, 0.3, 0.8, `{\\an7\\pos(0,0)\\1a&HFF&\\t(0,90,\\1a&H00&)\\t(210,500,1.4,\\1a&HFF&)${panel(ac2("#FFF3DC"), W, H)}`);
  } else if (id === "strobe") {
    D = 0.6;
    mid = 0.3;
    const full = (c, a, t0, t1) => ev(1, t0, t1, `{\\an7\\pos(0,0)\\1a&H${a}&${panel(c, W, H)}`);
    full("&HFFFFFF&", "70", 0, 0.07);
    full(ac2("#A855F7"), "40", 0.12, 0.19);
    full("&HFFFFFF&", "00", 0.23, 0.37);
    full(ac2("#F43F8E"), "40", 0.41, 0.48);
    full("&HFFFFFF&", "80", 0.52, 0.6);
  } else if (id === "deklansor") {
    D = 0.5;
    mid = 0.17;
    ev(1, 0.07, 0.2, `{\\an7\\pos(0,0)\\1a&HFF&\\t(0,40,\\1a&H00&)${panel("&H000000&", W, H)}`);
    ev(2, 0.19, D, `{\\an7\\pos(0,0)\\1a&H00&\\t(40,310,1.5,\\1a&HFF&)${panel("&HFFFFFF&", W, H)}`);
  } else if (id === "tv") {
    D = 0.65;
    mid = 0.34;
    const hh = R(H / 2) + 2;
    const gap = Math.max(2, R(H * 6e-3));
    const lh = gap * 2;
    ev(2, 0, 0.3, `{\\an7\\move(0,${-hh},0,${R(H / 2) - gap - hh},0,170)${panel("&H000000&", W, hh)}`);
    ev(2, 0, 0.3, `{\\an7\\move(0,${H},0,${R(H / 2) + gap},0,170)${panel("&H000000&", W, hh)}`);
    ev(1, 0.13, 0.3, `{\\an5\\pos(${R(W / 2)},${R(H / 2)})\\fscx100\\t(50,160,1.6,\\fscx0)${panel("&HFFFFFF&", W, lh + 2)}`);
    ev(0, 0.28, D, `{\\an7\\pos(0,0)\\1a&H00&\\t(140,330,1.3,\\1a&HFF&)${panel("&H000000&", W, H)}`);
  }
  return { ass: s.done(), duration: lead + D + tail2, mid: lead + mid };
}
var EFFECT_BUILDERS = { title: buildTitle, lowerThird: buildLowerThird, emoji: buildEmoji, cinematic: buildCinematic, flash: buildFlash, progress: buildProgress, subscribe: buildSubscribe, transition: buildTransition };

// core/colormatch.js
var toLin = (v) => v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
var toGam = (v) => v <= 31308e-7 ? v * 12.92 : 1.055 * Math.max(0, v) ** (1 / 2.4) - 0.055;
function rgbToOklab(r, g, b) {
  const lr = toLin(r);
  const lg = toLin(g);
  const lb = toLin(b);
  const l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb);
  const m2 = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb);
  const s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb);
  return [0.2104542553 * l + 0.793617785 * m2 - 0.0040720468 * s, 1.9779984951 * l - 2.428592205 * m2 + 0.4505937099 * s, 0.0259040371 * l + 0.7827717662 * m2 - 0.808675766 * s];
}
function oklabToRgb(L, a, b) {
  const l = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3;
  const m2 = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3;
  const s = (L - 0.0894841775 * a - 1.291485548 * b) ** 3;
  return [toGam(4.0767416621 * l - 3.3077115913 * m2 + 0.2309699292 * s), toGam(-1.2684380046 * l + 2.6097574011 * m2 - 0.3413193965 * s), toGam(-0.0041960863 * l - 0.7034186147 * m2 + 1.707614701 * s)];
}
var clamp01 = (v) => v < 0 ? 0 : v > 1 ? 1 : v;
var smooth = (e0, e1, x) => {
  const t = clamp01((x - e0) / (e1 - e0));
  return t * t * (3 - 2 * t);
};
var zones = (L) => {
  const s = 1 - smooth(0.25, 0.55, L);
  const h = smooth(0.6, 0.88, L);
  return [s, Math.max(0, 1 - s - h), h];
};
var BINS = 256;
function colorStats(pixels) {
  const hist = new Float64Array(BINS);
  const z = [0, 1, 2].map(() => ({ w: 0, a: 0, b: 0, c: 0 }));
  const n = Math.floor(pixels.length / 3);
  const labs = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const [L, a, b] = rgbToOklab(pixels[i * 3] / 255, pixels[i * 3 + 1] / 255, pixels[i * 3 + 2] / 255);
    labs[i * 3] = L;
    labs[i * 3 + 1] = a;
    labs[i * 3 + 2] = b;
    hist[Math.min(BINS - 1, Math.max(0, Math.round(L * (BINS - 1))))]++;
    const w = zones(L);
    for (let k = 0; k < 3; k++) {
      z[k].w += w[k];
      z[k].a += w[k] * a;
      z[k].b += w[k] * b;
    }
  }
  for (const q of z) {
    if (q.w > 0) {
      q.a /= q.w;
      q.b /= q.w;
    }
  }
  for (let i = 0; i < n; i++) {
    const w = zones(labs[i * 3]);
    for (let k = 0; k < 3; k++) z[k].c += w[k] * Math.hypot(labs[i * 3 + 1] - z[k].a, labs[i * 3 + 2] - z[k].b);
  }
  for (const q of z) q.c = q.w > 0 ? q.c / q.w : 0;
  const cdf = new Float64Array(BINS);
  let acc = 0;
  for (let i = 0; i < BINS; i++) {
    acc += hist[i];
    cdf[i] = acc / Math.max(1, n);
  }
  return { n, cdf, zones: z };
}
function toneCurve(src, ref) {
  const m2 = new Float64Array(BINS);
  let j = 0;
  for (let i = 0; i < BINS; i++) {
    while (j < BINS - 1 && ref.cdf[j] < src.cdf[i]) j++;
    m2[i] = j / (BINS - 1);
  }
  let lo = 0;
  let hi = BINS - 1;
  while (lo < BINS - 1 && src.cdf[lo] < 2e-3) lo++;
  while (hi > 0 && src.cdf[hi] > 0.998) hi--;
  for (let i = 0; i < lo; i++) m2[i] = m2[lo] * i / Math.max(1, lo);
  for (let i = hi + 1; i < BINS; i++) m2[i] = m2[hi] + (1 - m2[hi]) * (i - hi) / Math.max(1, BINS - 1 - hi);
  let cur = m2;
  for (let pass = 0; pass < 3; pass++) {
    const next = new Float64Array(BINS);
    for (let i = 0; i < BINS; i++) {
      let s = 0;
      let c = 0;
      for (let k = -8; k <= 8; k++) {
        const q = i + k;
        if (q >= 0 && q < BINS) {
          s += cur[q];
          c++;
        }
      }
      next[i] = s / c;
    }
    cur = next;
  }
  const step = 1 / (BINS - 1);
  const out = new Float64Array(BINS);
  out[0] = Math.min(cur[0], 0.12);
  for (let i = 1; i < BINS; i++) out[i] = out[i - 1] + Math.min(3 * step, Math.max(0.3 * step, cur[i] - cur[i - 1]));
  const top = Math.max(cur[BINS - 1], 0.75);
  const scale = out[BINS - 1] > 0 ? Math.min(1.25, Math.max(0.8, top / out[BINS - 1])) : 1;
  for (let i = 0; i < BINS; i++) out[i] = clamp01(out[i] * scale);
  return out;
}
var sample = (curve, L) => {
  const x = clamp01(L) * (BINS - 1);
  const i = Math.min(BINS - 2, Math.floor(x));
  return curve[i] + (curve[i + 1] - curve[i]) * (x - i);
};
function skinWeight(L, a, b) {
  const c = Math.hypot(a, b);
  const h = Math.atan2(b, a) * 180 / Math.PI;
  return smooth(22, 38, h) * (1 - smooth(72, 92, h)) * smooth(0.025, 0.05, c) * (1 - smooth(0.17, 0.24, c)) * smooth(0.25, 0.4, L) * (1 - smooth(0.88, 0.97, L));
}
function buildColorTransform(src, ref, { strength = 1, protectSkin = true, part = "all" } = {}) {
  const kc = part === "tone" ? 0 : 1;
  const kt = part === "color" ? 0 : 1;
  const curve = toneCurve(src, ref);
  const k = Math.max(0, Math.min(1, strength));
  const z = [0, 1, 2].map((i) => {
    const s = src.zones[i];
    const r = ref.zones[i];
    const ok = s.w > src.n * 0.01 && r.w > ref.n * 0.01;
    return ok ? { sa: s.a, sb: s.b, ra: r.a, rb: r.b, gain: Math.min(1.7, Math.max(0.6, s.c > 4e-3 ? r.c / s.c : 1)) } : null;
  });
  const fallback = z.find(Boolean) ?? { sa: 0, sb: 0, ra: 0, rb: 0, gain: 1 };
  return (r, g, b) => {
    const [L, a, bb] = rgbToOklab(r, g, b);
    const L2 = sample(curve, L);
    const w = zones(L);
    let na = 0;
    let nb = 0;
    for (let i = 0; i < 3; i++) {
      const q = z[i] ?? fallback;
      na += w[i] * ((a - q.sa) * q.gain + q.ra);
      nb += w[i] * ((bb - q.sb) * q.gain + q.rb);
    }
    const keep = protectSkin ? 1 - 0.7 * skinWeight(L, a, bb) : 1;
    const out = oklabToRgb(L + (L2 - L) * k * kt, a + (na - a) * k * keep * kc, bb + (nb - bb) * k * keep * kc);
    return [clamp01(out[0]), clamp01(out[1]), clamp01(out[2])];
  };
}
function buildCube(transform, { size = 33, title = "Makas Renk Esleme" } = {}) {
  const lines = [`TITLE "${title}"`, `LUT_3D_SIZE ${size}`, "DOMAIN_MIN 0.0 0.0 0.0", "DOMAIN_MAX 1.0 1.0 1.0", ""];
  const d = size - 1;
  for (let b = 0; b < size; b++) {
    for (let g = 0; g < size; g++) {
      for (let r = 0; r < size; r++) {
        const o = transform(r / d, g / d, b / d);
        lines.push(`${o[0].toFixed(6)} ${o[1].toFixed(6)} ${o[2].toFixed(6)}`);
      }
    }
  }
  return `${lines.join("\n")}
`;
}
function matchColors(sourcePixels, referencePixels, opts = {}) {
  const { pre } = opts;
  let pixels = sourcePixels;
  if (pre) {
    pixels = new Uint8Array(sourcePixels.length);
    for (let i = 0; i + 2 < sourcePixels.length; i += 3) {
      const o = pre(sourcePixels[i] / 255, sourcePixels[i + 1] / 255, sourcePixels[i + 2] / 255);
      pixels[i] = Math.round(o[0] * 255);
      pixels[i + 1] = Math.round(o[1] * 255);
      pixels[i + 2] = Math.round(o[2] * 255);
    }
  }
  let match = null;
  let matchColor = null;
  let matchTone = null;
  if (referencePixels) {
    const src = colorStats(pixels);
    const ref = colorStats(referencePixels);
    if (src.n < 100 || ref.n < 100) throw new Error("Renk e\u015Fleme i\xE7in g\xF6r\xFCnt\xFC okunamad\u0131");
    match = buildColorTransform(src, ref, opts);
    matchColor = buildColorTransform(src, ref, { ...opts, part: "color" });
    matchTone = buildColorTransform(src, ref, { ...opts, part: "tone" });
  }
  const transform = pre && match ? (r, g, b) => match(...pre(r, g, b)) : match ?? pre ?? ((r, g, b) => [r, g, b]);
  return { cube: buildCube(transform, opts), transform, match, matchColor, matchTone };
}

// core/cameralog.js
var D65 = [0.3127, 0.329];
function inv3(m2) {
  const [a, b, c, d, e, f, g, h, i] = m2;
  const A = e * i - f * h;
  const B = -(d * i - f * g);
  const C = d * h - e * g;
  const det = a * A + b * B + c * C;
  return [A / det, (c * h - b * i) / det, (b * f - c * e) / det, B / det, (a * i - c * g) / det, (c * d - a * f) / det, C / det, (b * g - a * h) / det, (a * e - b * d) / det];
}
var mul3 = (x, y) => {
  const o = new Array(9);
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) o[r * 3 + c] = x[r * 3] * y[c] + x[r * 3 + 1] * y[3 + c] + x[r * 3 + 2] * y[6 + c];
  return o;
};
function rgbToXyz([rx, ry, gx, gy, bx, by], [wx, wy] = D65) {
  const col = (x, y) => [x / y, 1, (1 - x - y) / y];
  const R = col(rx, ry);
  const G = col(gx, gy);
  const B = col(bx, by);
  const W = col(wx, wy);
  const M = [R[0], G[0], B[0], R[1], G[1], B[1], R[2], G[2], B[2]];
  const I = inv3(M);
  const s = [0, 1, 2].map((r) => I[r * 3] * W[0] + I[r * 3 + 1] * W[1] + I[r * 3 + 2] * W[2]);
  return [M[0] * s[0], M[1] * s[1], M[2] * s[2], M[3] * s[0], M[4] * s[1], M[5] * s[2], M[6] * s[0], M[7] * s[1], M[8] * s[2]];
}
var REC709 = [0.64, 0.33, 0.3, 0.6, 0.15, 0.06];
var XYZ_TO_709 = inv3(rgbToXyz(REC709));
var gamutTo709 = (primaries, white) => mul3(XYZ_TO_709, rgbToXyz(primaries, white));
var GAMUTS = {
  rec709: REC709,
  rec2020: [0.708, 0.292, 0.17, 0.797, 0.131, 0.046],
  sgamut3: [0.73, 0.28, 0.14, 0.855, 0.1, -0.05],
  sgamut3cine: [0.766, 0.275, 0.225, 0.8, 0.089, -0.087],
  vgamut: [0.73, 0.28, 0.165, 0.84, 0.1, -0.03],
  awg3: [0.684, 0.313, 0.221, 0.848, 0.0861, -0.102],
  awg4: [0.7347, 0.2653, 0.1424, 0.8576, 0.0991, -0.0308],
  cinemagamut: [0.74, 0.27, 0.17, 1.14, 0.08, -0.1],
  rwg: [0.780308, 0.304253, 0.121595, 1.493994, 0.095612, -0.084589],
  dgamut: [0.71, 0.31, 0.21, 0.88, 0.09, -0.08],
  bmdwg: [0.7177215, 0.3171181, 0.228041, 0.861569, 0.1005841, -0.0820452]
};
var legalToFull = (x) => (x * 1023 - 64) / 876;
var CURVES = {
  slog3: (x) => x >= 171.2102946929 / 1023 ? 10 ** ((x * 1023 - 420) / 261.5) * 0.19 - 0.01 : (x * 1023 - 95) * 0.01125 / (171.2102946929 - 95),
  slog2: (v) => {
    const x = legalToFull(v);
    const y = x >= 0.030001222851889303 ? 10 ** ((x - 0.616596 - 0.03) / 0.432699) - 0.037584 : (x - 0.030001222851889303) / 5;
    return 219 * y / 155 * 0.9;
  },
  vlog: (x) => x < 0.181 ? (x - 0.125) / 5.6 : 10 ** ((x - 0.598206) / 0.241514) - 873e-5,
  logc3: (x) => x > 5.367655 * 0.010591 + 0.092809 ? (10 ** ((x - 0.385537) / 0.24719) - 0.052272) / 5.555556 : (x - 0.092809) / 5.367655,
  logc4: (x) => {
    const a = (2 ** 18 - 16) / 117.45;
    const b = (1023 - 95) / 1023;
    const c = 95 / 1023;
    const s = 7 * Math.LN2 * 2 ** (7 - 14 * c / b) / (a * b);
    const t = (2 ** (14 * (-c / b) + 6) - 64) / a;
    return x >= 0 ? (2 ** (14 * (x - c) / b + 6) - 64) / a : x * s + t;
  },
  clog3: (v) => {
    const x = legalToFull(v);
    const y = x < 0.097465473 ? -(10 ** ((0.12783901 - x) / 0.36726845) - 1) / 14.98325 : x <= 0.15277891 ? (x - 0.12512219) / 1.9754798 : (10 ** ((x - 0.12240537) / 0.36726845) - 1) / 14.98325;
    return y * 0.9;
  },
  clog2: (v) => {
    const x = legalToFull(v);
    const y = x < 0.092864125 ? -(10 ** ((0.092864125 - x) / 0.24136077) - 1) / 87.099375 : (10 ** ((x - 0.092864125) / 0.24136077) - 1) / 87.099375;
    return y * 0.9;
  },
  flog: (x) => x < 0.100537775223865 ? (x - 0.092864) / 8.735631 : 10 ** ((x - 0.790453) / 0.344676) / 0.555556 - 9468e-6 / 0.555556,
  flog2: (x) => x < 0.100686685370811 ? (x - 0.092864) / 8.799461 : 10 ** ((x - 0.384316) / 0.245281) / 5.555556 - 0.064829 / 5.555556,
  nlog: (x) => x < 452 / 1023 ? (x / (650 / 1023)) ** 3 - 75e-4 : Math.exp((x - 619 / 1023) / (150 / 1023)),
  dlog: (x) => x <= 0.14 ? (x - 0.0929) / 6.025 : (10 ** (3.89616 * x - 2.27752) - 0.0108) / 0.9892,
  log3g10: (x) => x < 0 ? x / 15.1927 - 0.01 : (10 ** (x / 0.224282) - 1) / 155.975327 - 0.01,
  bmdfilm5: (x) => x < 8.283605932402494 * 5e-3 + 0.09246575342465753 ? (x - 0.09246575342465753) / 8.283605932402494 : Math.exp((x - 0.5300133392291939) / 0.08692876065491224) - 0.005494072432257808,
  applelog: (p) => {
    const R0 = -0.05641088;
    const c = 47.28711236;
    const pt = c * (0.01 - R0) ** 2;
    return p >= pt ? 2 ** ((p - 0.69336945) / 0.08550479) - 964052e-8 : p >= 0 ? Math.sqrt(p / c) + R0 : R0;
  }
};
var CAMERAS = [
  { id: "standart", label: "Standart (log de\u011Fil)", profiles: [{ id: "rec709", label: "Rec.709 / normal \xE7ekim" }] },
  {
    id: "sony",
    label: "Sony",
    profiles: [
      { id: "slog3-sgamut3cine", label: "S-Log3 / S-Gamut3.Cine", curve: "slog3", gamut: "sgamut3cine" },
      { id: "slog3-sgamut3", label: "S-Log3 / S-Gamut3", curve: "slog3", gamut: "sgamut3" },
      { id: "slog2-sgamut", label: "S-Log2 / S-Gamut", curve: "slog2", gamut: "sgamut3" }
    ]
  },
  { id: "panasonic", label: "Panasonic", profiles: [{ id: "vlog-vgamut", label: "V-Log / V-Gamut", curve: "vlog", gamut: "vgamut" }] },
  {
    id: "canon",
    label: "Canon",
    profiles: [
      { id: "clog3-cinema", label: "Canon Log 3 / Cinema Gamut", curve: "clog3", gamut: "cinemagamut" },
      { id: "clog3-709", label: "Canon Log 3 / BT.709", curve: "clog3", gamut: "rec709" },
      { id: "clog2-cinema", label: "Canon Log 2 / Cinema Gamut", curve: "clog2", gamut: "cinemagamut" }
    ]
  },
  {
    id: "fujifilm",
    label: "Fujifilm",
    profiles: [
      { id: "flog", label: "F-Log / F-Gamut", curve: "flog", gamut: "rec2020" },
      { id: "flog2", label: "F-Log2 / F-Gamut", curve: "flog2", gamut: "rec2020" }
    ]
  },
  { id: "nikon", label: "Nikon", profiles: [{ id: "nlog", label: "N-Log", curve: "nlog", gamut: "rec2020" }] },
  { id: "dji", label: "DJI", profiles: [{ id: "dlog", label: "D-Log / D-Gamut", curve: "dlog", gamut: "dgamut" }] },
  { id: "apple", label: "Apple (iPhone)", profiles: [{ id: "applelog", label: "Apple Log", curve: "applelog", gamut: "rec2020" }] },
  { id: "blackmagic", label: "Blackmagic", profiles: [{ id: "bmdfilm5", label: "Film Gen 5 / Wide Gamut", curve: "bmdfilm5", gamut: "bmdwg" }] },
  {
    id: "arri",
    label: "ARRI",
    profiles: [
      { id: "logc3", label: "LogC3 / Wide Gamut 3", curve: "logc3", gamut: "awg3" },
      { id: "logc4", label: "LogC4 / Wide Gamut 4", curve: "logc4", gamut: "awg4" }
    ]
  },
  { id: "red", label: "RED", profiles: [{ id: "log3g10", label: "Log3G10 / REDWideGamutRGB", curve: "log3g10", gamut: "rwg" }] }
];
var findProfile = (id) => CAMERAS.flatMap((c) => c.profiles).find((p) => p.id === id) ?? null;
var toGam2 = (v) => v <= 31308e-7 ? v * 12.92 : 1.055 * v ** (1 / 2.4) - 0.055;
var toLin2 = (v) => v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
var WHITE = { yumusak: 16, normal: 6, sert: 2.2 };
function cameraTransform(profileId, opts = {}) {
  return cameraTransformOf(findProfile(profileId), opts);
}
function cameraTransformOf(prof, { highlights = "normal", exposure = 0, contrast = 1, saturation = 1 } = {}) {
  const isLog = Boolean(prof == null ? void 0 : prof.curve);
  const decode = isLog ? CURVES[prof.curve] : toLin2;
  const M = isLog ? gamutTo709(GAMUTS[prof.gamut]) : null;
  const gain = 2 ** exposure;
  const w2 = ((WHITE[highlights] ?? WHITE.normal) * 1.22) ** 2;
  const f = (v) => v * (1 + v / w2) / (1 + v);
  let lo = 0.18;
  let hi = 0.3;
  for (let i = 0; i < 40; i++) {
    const mid = (lo + hi) / 2;
    if (f(mid) < 0.18) lo = mid;
    else hi = mid;
  }
  const k = lo / 0.18;
  const tone = (x) => x <= 0 ? 0 : Math.min(1, f(x * k));
  const neutral = !isLog && exposure === 0 && contrast === 1 && saturation === 1;
  return (r, g, b) => {
    if (neutral) return [r, g, b];
    let lr = decode(r);
    let lg = decode(g);
    let lb = decode(b);
    if (M) [lr, lg, lb] = [M[0] * lr + M[1] * lg + M[2] * lb, M[3] * lr + M[4] * lg + M[5] * lb, M[6] * lr + M[7] * lg + M[8] * lb];
    lr *= gain;
    lg *= gain;
    lb *= gain;
    if (isLog) {
      lr = Math.max(0, lr);
      lg = Math.max(0, lg);
      lb = Math.max(0, lb);
      const Y = 0.2126 * lr + 0.7152 * lg + 0.0722 * lb;
      const s = Y > 1e-6 ? tone(Y) / Y : 0;
      lr *= s;
      lg *= s;
      lb *= s;
      const mx = Math.max(lr, lg, lb);
      if (mx > 1) {
        const Y2 = Math.min(1, 0.2126 * lr + 0.7152 * lg + 0.0722 * lb);
        const t = (mx - 1) / Math.max(1e-6, mx - Y2);
        lr += (Y2 - lr) * t;
        lg += (Y2 - lg) * t;
        lb += (Y2 - lb) * t;
      }
    }
    let out = [toGam2(Math.min(1, Math.max(0, lr))), toGam2(Math.min(1, Math.max(0, lg))), toGam2(Math.min(1, Math.max(0, lb)))];
    if (contrast !== 1 || saturation !== 1) {
      const P = 0.46;
      const sc = (v) => v < P ? P * (v / P) ** contrast : 1 - (1 - P) * ((1 - v) / (1 - P)) ** contrast;
      const y = 0.2126 * out[0] + 0.7152 * out[1] + 0.0722 * out[2];
      const y2 = sc(y);
      const f2 = y > 1e-5 ? y2 / y : 1;
      out = out.map((v) => Math.min(1, Math.max(0, y2 + (v * f2 - y2) * saturation)));
    }
    return out;
  };
}
GAMUTS.dwg = [0.8, 0.313, 0.1682, 0.9877, 0.079, -0.1155];
CURVES.di = (v) => v > 0.02740668 ? 2 ** (v / 0.07329248 - 7) - 75e-4 : v / 10.44426855;
var diEncode = (x) => x > 262409e-8 ? (Math.log2(x + 75e-4) + 7) * 0.07329248 : x * 10.44426855;
var HIDDEN = [{ id: "davinci-intermediate", label: "DaVinci Intermediate", curve: "di", gamut: "dwg" }];
var profileOf = (id) => findProfile(id) ?? HIDDEN.find((p) => p.id === id) ?? null;
var inverseOf = (decode) => (y) => {
  let lo = -0.2;
  let hi = 1.2;
  for (let i = 0; i < 32; i++) {
    const mid = (lo + hi) / 2;
    if (decode(mid) < y) lo = mid;
    else hi = mid;
  }
  return Math.min(1, Math.max(0, (lo + hi) / 2));
};
function colorStages(profileId, { highlights = "normal", exposure = 0, contrast = 1, saturation = 1, temperature = 0 } = {}) {
  const prof = profileOf(profileId);
  const isLog = Boolean(prof == null ? void 0 : prof.curve);
  const decode = isLog ? CURVES[prof.curve] : toLin2;
  const encode = inverseOf(decode);
  const toXyz = rgbToXyz(GAMUTS[isLog ? prof.gamut : "rec709"]);
  const wY = [toXyz[3], toXyz[4], toXyz[5]];
  const out = [];
  if (exposure || temperature || saturation !== 1) {
    const g = 2 ** exposure;
    const t = Math.max(-1, Math.min(1, temperature));
    let wb = [1 + 0.25 * t, 1, 1 - 0.25 * t];
    const norm = wY[0] * wb[0] + wY[1] * wb[1] + wY[2] * wb[2];
    wb = wb.map((v) => v / norm * g);
    out.push({
      id: "wbsat",
      label: "WB-SAT",
      match: ["WB/SAT", "WB", "BALANCE", "PRIMARIES", "EXP", "SAT"],
      fn: (r, gg, b) => {
        let l = [decode(r) * wb[0], decode(gg) * wb[1], decode(b) * wb[2]];
        if (saturation !== 1) {
          const Y = wY[0] * l[0] + wY[1] * l[1] + wY[2] * l[2];
          l = l.map((v) => Y + (v - Y) * saturation);
        }
        return l.map(encode);
      }
    });
  }
  if (contrast !== 1) {
    const pivot = encode(0.18);
    const lin = (v) => Math.min(1, Math.max(0, pivot + (v - pivot) * contrast));
    out.push({ id: "contrast", label: "CONTRAST", match: ["CONTRAST", "KONTRAST"], fn: isLog ? (r, g, b) => [lin(r), lin(g), lin(b)] : cameraTransform("rec709", { contrast }) });
  }
  if (isLog) {
    const M = mul3(inv3(rgbToXyz(GAMUTS.dwg)), rgbToXyz(GAMUTS[prof.gamut]));
    out.push({
      id: "cst-in",
      label: "CST-TO-DWG",
      match: ["CST TO DWG", "CST IN", "IDT", "CST 1"],
      size: 65,
      fn: (r, g, b) => {
        const lr = decode(r);
        const lg = decode(g);
        const lb = decode(b);
        return [diEncode(M[0] * lr + M[1] * lg + M[2] * lb), diEncode(M[3] * lr + M[4] * lg + M[5] * lb), diEncode(M[6] * lr + M[7] * lg + M[8] * lb)].map((v) => Math.min(1, Math.max(0, v)));
      }
    });
    const toRec = cameraTransformOf(HIDDEN[0], { highlights });
    out.push({ id: "cst-out", label: "CST-TO-REC709", match: ["CST TO REC", "CST OUT", "ODT", "CST 2"], size: 65, fn: toRec });
  }
  return out;
}
var S3 = ["slog3-sgamut3cine", "slog3-sgamut3"];
var S23 = [...S3, "slog2-sgamut"];
var m = (id, label, profiles, extra = {}) => ({ id, label, profiles, ...extra });
var VLOG_L = { names: { "vlog-vgamut": "V-Log L / V-Gamut" }, note: "V-Log L, V-Log ile ayn\u0131 e\u011Friyi kullan\u0131r (dinamik aral\u0131\u011F\u0131 daha dar)." };
var CAMERA_MODELS = {
  sony: [
    m("a7siii", "A7S III", S3, { note: "S-Log3 \xE7ift taban ISO: 640 ve 12800." }),
    m("fx3", "FX3", S3, { note: "S-Log3 \xE7ift taban ISO: 640 ve 12800." }),
    m("zve1", "ZV-E1", S3, { note: "S-Log3 \xE7ift taban ISO: 640 ve 12800." }),
    m("fx30", "FX30", S3, { note: "S-Log3 \xE7ift taban ISO: 800 ve 2500." }),
    m("a7iv", "A7 IV", S3),
    m("a7cii", "A7C II", S3),
    m("a7rv", "A7R V", S3),
    m("a1", "A1 / A1 II", S3),
    m("a9iii", "A9 III", S3),
    m("a6700", "A6700", S3),
    m("fx6", "FX6 / FX9 / Venice", S3),
    m("a7iii", "A7 III", S23),
    m("a7riv", "A7R III / A7R IV", S23),
    m("a7c", "A7C", S23),
    m("a6400", "A6400 / A6600 / A6100", S23),
    m("zve10", "ZV-E10 / ZV-E10 II", S23)
  ],
  panasonic: [
    m("s5ii", "S5 II / S5 IIX", ["vlog-vgamut"]),
    m("s5", "S5", ["vlog-vgamut"]),
    m("s1h", "S1H / S1 / S1R", ["vlog-vgamut"]),
    m("gh7", "GH7", ["vlog-vgamut"]),
    m("gh6", "GH6", ["vlog-vgamut"]),
    m("g9ii", "G9 II", ["vlog-vgamut"]),
    m("gh5ii", "GH5 II", ["vlog-vgamut"], VLOG_L),
    m("gh5", "GH5 / GH5S / G9", ["vlog-vgamut"], VLOG_L),
    m("bgh1", "BGH1 / BS1H", ["vlog-vgamut"])
  ],
  canon: [
    m("r5ii", "EOS R5 Mark II", ["clog3-cinema", "clog3-709", "clog2-cinema"]),
    m("r5", "EOS R5 / R5 C", ["clog3-cinema", "clog3-709"]),
    m("r6ii", "EOS R6 Mark II / R6", ["clog3-cinema", "clog3-709"]),
    m("r7", "EOS R7 / R8 / R50", ["clog3-cinema", "clog3-709"]),
    m("r3", "EOS R3 / R1", ["clog3-cinema", "clog3-709"]),
    m("c70", "C70 / C80", ["clog3-cinema", "clog2-cinema", "clog3-709"]),
    m("c300", "C300 III / C500 II / C400", ["clog3-cinema", "clog2-cinema"]),
    m("c200", "C200", ["clog3-cinema", "clog2-cinema"])
  ],
  fujifilm: [
    m("xh2s", "X-H2S / X-H2", ["flog2", "flog"]),
    m("xt5", "X-T5 / X-S20 / X-M5", ["flog2", "flog"]),
    m("gfx", "GFX100 II / GFX100S II", ["flog2", "flog"]),
    m("xt4", "X-T4 / X-S10 / X-T3", ["flog"]),
    m("xh1", "X-H1", ["flog"])
  ],
  nikon: [
    m("z8", "Z8 / Z9", ["nlog"]),
    m("z6iii", "Z6 III", ["nlog"]),
    m("zf", "Zf / Z5 II", ["nlog"]),
    m("z6ii", "Z6 II / Z7 II", ["nlog"]),
    m("z6", "Z6 / Z7", ["nlog"], { note: "N-Log i\xE7in harici kay\u0131t ve \xFCcretli g\xFCncelleme gerekir." })
  ],
  dji: [
    m("mavic3", "Mavic 3 / Mavic 3 Pro / Cine", ["dlog"]),
    m("inspire3", "Inspire 3 / Ronin 4D", ["dlog"]),
    m("air2s", "Air 2S", ["dlog"])
  ],
  apple: [m("iphone17", "iPhone 17 Pro / Pro Max", ["applelog"]), m("iphone16", "iPhone 16 Pro / Pro Max", ["applelog"]), m("iphone15", "iPhone 15 Pro / Pro Max", ["applelog"])],
  blackmagic: [
    m("bmpcc6kpro", "Pocket 6K / 6K G2 / 6K Pro", ["bmdfilm5"]),
    m("bmpcc4k", "Pocket 4K", ["bmdfilm5"]),
    m("bmcc6k", "Cinema Camera 6K", ["bmdfilm5"]),
    m("ursa", "URSA Mini Pro 12K / Cine", ["bmdfilm5"])
  ],
  arri: [m("alexa35", "ALEXA 35 / 265", ["logc4"]), m("minilf", "ALEXA Mini / Mini LF / AMIRA", ["logc3"])],
  red: [m("komodo", "KOMODO / KOMODO-X", ["log3g10"]), m("vraptor", "V-RAPTOR / RAPTOR", ["log3g10"]), m("dsmc2", "DSMC2 (Monstro, Helium, Gemini)", ["log3g10"])]
};

// core/looks.js
var clamp012 = (v) => v < 0 ? 0 : v > 1 ? 1 : v;
var smooth2 = (e0, e1, x) => {
  const t = clamp012((x - e0) / (e1 - e0));
  return t * t * (3 - 2 * t);
};
var LOOKS = [
  { id: "teal-orange", label: "Teal & Orange", desc: "G\xF6lgeler turkuaz, tenler s\u0131cak", contrast: 1.12, sat: 1.08, shadow: [-0.03, -0.035], highlight: [0.02, 0.035] },
  { id: "sicak-film", label: "S\u0131cak film", desc: "Alt\u0131n saat s\u0131cakl\u0131\u011F\u0131, yumu\u015Fak siyahlar", contrast: 1.06, sat: 0.96, warm: 0.5, fade: 0.035, highlight: [8e-3, 0.02] },
  { id: "soguk", label: "So\u011Fuk", desc: "Mavi g\xF6lgeler, temiz beyazlar", contrast: 1.1, sat: 0.95, warm: -0.45, shadow: [-8e-3, -0.03] },
  { id: "mat", label: "Mat", desc: "Soluk siyahlar, d\xFC\u015F\xFCk kontrast", contrast: 0.92, sat: 0.86, fade: 0.07 },
  { id: "canli", label: "Canl\u0131", desc: "Dolgun renkler, net kontrast", contrast: 1.14, sat: 1.3 },
  { id: "vintage", label: "Vintage", desc: "Sar\u0131ms\u0131 parlaklar, ye\u015Filimsi g\xF6lgeler", contrast: 0.98, sat: 0.8, fade: 0.06, shadow: [-0.018, 0.012], highlight: [6e-3, 0.03] },
  { id: "gece", label: "Gece mavisi", desc: "Derin mavi, koyu ve dramatik", contrast: 1.18, sat: 0.9, warm: -0.3, shadow: [-0.012, -0.045], highlight: [-4e-3, -0.01], gain: 0.94 },
  { id: "pastel", label: "Pastel", desc: "A\xE7\u0131k, yumu\u015Fak ve havadar", contrast: 0.9, sat: 0.9, fade: 0.05, gain: 1.05, highlight: [6e-3, 6e-3] },
  { id: "sb", label: "Siyah-beyaz", desc: "G\xFC\xE7l\xFC kontrastl\u0131 siyah-beyaz", contrast: 1.2, mono: true },
  { id: "sb-sepya", label: "Sepya", desc: "S\u0131cak tonlu siyah-beyaz", contrast: 1.05, mono: true, fade: 0.04, shadow: [8e-3, 0.02], highlight: [0.01, 0.03] }
];
var findLook = (id) => LOOKS.find((l) => l.id === id) ?? null;
function lookTransform(id, strength = 1) {
  const look = findLook(id);
  const k = Math.max(0, Math.min(1, strength));
  if (!look || k === 0) return (r, g, b) => [r, g, b];
  const { contrast = 1, fade = 0, sat = 1, warm = 0, shadow = [0, 0], highlight = [0, 0], mono = false, gain = 1 } = look;
  const P = 0.6;
  const curve = (L) => {
    const v = L < P ? P * (L / P) ** contrast : 1 - (1 - P) * ((1 - L) / (1 - P)) ** contrast;
    return clamp012(fade + v * gain * (1 - fade));
  };
  return (r, g, b) => {
    const [L, a, bb] = rgbToOklab(r, g, b);
    const L2 = curve(L);
    const ws = 1 - smooth2(0.2, 0.6, L);
    const wh = smooth2(0.55, 0.92, L);
    const edge = smooth2(0.02, 0.18, L) * (1 - smooth2(0.9, 1, L));
    let a2 = (mono ? 0 : a * sat) + (ws * shadow[0] + wh * highlight[0] + warm * 0.012) * edge;
    let b2 = (mono ? 0 : bb * sat) + (ws * shadow[1] + wh * highlight[1] + warm * 0.03) * edge;
    a2 = a + (a2 - a) * k;
    b2 = bb + (b2 - bb) * k;
    const out = oklabToRgb(L + (L2 - L) * k, a2, b2);
    return [clamp012(out[0]), clamp012(out[1]), clamp012(out[2])];
  };
}

// core/filmfx.js
var clamp = (v, a, b) => Math.max(a, Math.min(b, v));
var n2 = (v) => Math.round(v * 100) / 100;
var filmFxActive = (fx) => Boolean(fx && ["halation", "bloom", "grain", "vignette"].some((k) => {
  var _a;
  return (_a = fx[k]) == null ? void 0 : _a.on;
}));
function filmFxGraph(fx, { width, inp = "[0:v]", out = "[fx]", seed = 7 } = {}) {
  var _a, _b, _c, _d;
  const k = Math.max(0.1, (width || 1920) / 1920);
  const parts = [];
  let cur = inp;
  let n = 0;
  const next = () => `[f${n++}]`;
  const add = (chain) => {
    const o = next();
    parts.push(`${cur}${chain}${o}`);
    cur = o;
  };
  add("format=gbrp");
  const glow = (cfg, { threshold, sigma, tint, opacity }) => {
    const a = next();
    const b = next();
    const g = next();
    parts.push(`${cur}split${a}${b}`);
    parts.push(`${b}colorlevels=rimin=${threshold}:gimin=${threshold}:bimin=${threshold}${tint ? `,colorchannelmixer=${tint}` : ""},gblur=sigma=${n2(sigma * k)}${g}`);
    const o = next();
    parts.push(`${a}${g}blend=all_mode=screen:all_opacity=${n2(opacity)}${o}`);
    cur = o;
  };
  if ((_a = fx == null ? void 0 : fx.bloom) == null ? void 0 : _a.on) {
    const amt = clamp(fx.bloom.amount ?? 35, 0, 100) / 100;
    const spr = clamp(fx.bloom.spread ?? 50, 0, 100) / 100;
    glow(fx.bloom, { threshold: n2(0.72 - amt * 0.22), sigma: 12 + spr * 48, opacity: 0.25 + amt * 0.65 });
  }
  if ((_b = fx == null ? void 0 : fx.halation) == null ? void 0 : _b.on) {
    const amt = clamp(fx.halation.amount ?? 40, 0, 100) / 100;
    const spr = clamp(fx.halation.spread ?? 50, 0, 100) / 100;
    glow(fx.halation, { threshold: n2(0.82 - amt * 0.17), sigma: 4 + spr * 18, tint: "rr=1:rg=0:rb=0:gr=0.32:gg=0.1:gb=0:br=0.05:bg=0:bb=0.02", opacity: 0.3 + amt * 0.7 });
  }
  if ((_c = fx == null ? void 0 : fx.vignette) == null ? void 0 : _c.on) {
    const amt = clamp(fx.vignette.amount ?? 35, 0, 100) / 100;
    add(`vignette=angle=${n2(0.15 + amt * 0.75)}:mode=forward`);
  }
  if ((_d = fx == null ? void 0 : fx.grain) == null ? void 0 : _d.on) {
    const amt = clamp(fx.grain.amount ?? 30, 0, 100) / 100;
    const size = clamp(fx.grain.size ?? 30, 0, 100) / 100;
    add(`format=yuv444p,noise=c0s=${Math.round(4 + amt * 26)}:c0f=t+u:all_seed=${seed}${size > 0.05 ? `,gblur=sigma=${n2(size * 1.2 * k)}:planes=1` : ""}`);
  }
  parts.push(`${cur}format=yuv444p${out}`);
  return parts.join(";");
}

// core/fillers.js
var VERBATIM_PROMPTS = {
  tr: "Eee, \u015Fey, \u0131\u0131\u0131... Yani, hmm, asl\u0131nda \u015F\xF6yle. Eee, tamam.",
  en: "Umm, let me think, like, hmm... Okay, uh, so, you know.",
  default: "Umm, uh, hmm... eh."
};
var HARD = {
  tr: /^(e{2,}h*m*|e+h+|e+m{2,}|ı+|ı+h+|ı+m+|i+h+|a{2,}h*|ö+|o{2,}|h+[ıiu]*m+|m{2,}|hı+|ıh+)$/u,
  en: /^(u+m+|u+h+|e+r+m*|e+h+|a{2,}h*|h+m+|m{2,}|u+h+m+|e+m{2,})$/u
};
var UNIVERSAL = /^(u+m+|u+h+|h+m+|m{2,})$/u;
var SHORT_VOWEL = /^[eaıiö]$/u;
var SOFT = {
  tr: /* @__PURE__ */ new Set(["\u015Fey", "yani", "i\u015Fte", "hani", "falan", "filan", "asl\u0131nda", "a\xE7\u0131k\xE7as\u0131", "ah"]),
  en: /* @__PURE__ */ new Set(["like", "basically", "actually", "literally", "so", "well", "ah"])
};
var SOFT_PAIRS = {
  tr: [["ne", "diyordum"], ["nas\u0131l", "diyeyim"]],
  en: [["you", "know"], ["i", "mean"], ["kind", "of"], ["sort", "of"]]
};
var MAX_SOUND = 1.6;
var MIN_COVERAGE = 0.7;
var FILLER_KINDS = {
  filler: { label: "I\u0131\u0131 / Eee", selected: true },
  sound: { label: "Yaz\u0131ya d\xF6k\xFClmemi\u015F ses", selected: true },
  repeat: { label: "Tekrar", selected: true },
  soft: { label: "Dolgu kelimesi", selected: false },
  retake: { label: "K\xF6t\xFC \xE7ekim", selected: true }
};
function clean4(word, lang) {
  return String(word).toLocaleLowerCase(lang === "tr" ? "tr-TR" : "en-US").replace(/[^\p{L}\p{N}'’]+/gu, "").replace(/[’']/g, "");
}
function isHardFiller(word, lang = "tr", duration = 0) {
  const w = clean4(word, lang);
  if (!w) return false;
  if (SHORT_VOWEL.test(w)) return duration >= 0.3 || lang === "tr" && w === "\u0131";
  const re = HARD[lang] ?? HARD.en;
  return re.test(w) || UNIVERSAL.test(w);
}
function isSoftFiller(word, lang = "tr") {
  return (SOFT[lang] ?? SOFT.en).has(clean4(word, lang));
}
function detectFillers(words, opts = {}) {
  const lang = (opts.language ?? "tr").slice(0, 2);
  const out = [];
  const push = (start, end, text, kind, confidence, selected = FILLER_KINDS[kind].selected) => {
    if (end - start < 0.06) return;
    out.push({ start, end, text, kind, confidence: Math.round(confidence * 100) / 100, selected });
  };
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    const next = words[i + 1];
    if (isHardFiller(w.text, lang, w.end - w.start)) {
      push(w.start, w.end, w.text, "filler", 0.75 + 0.25 * Math.min(1, w.p ?? 0.8));
      continue;
    }
    const pair = (SOFT_PAIRS[lang] ?? []).find(([a, b]) => clean4(w.text, lang) === a && next && clean4(next.text, lang) === b);
    if (pair) {
      push(w.start, next.end, `${w.text} ${next.text}`, "soft", 0.5);
      i++;
      continue;
    }
    if (isSoftFiller(w.text, lang)) {
      push(w.start, w.end, w.text, "soft", 0.45);
      continue;
    }
    if (next && clean4(w.text, lang).length > 0 && clean4(w.text, lang) === clean4(next.text, lang) && next.start - w.end < 0.6) {
      push(w.start, Math.min(next.start, w.end + 0.05), w.text, "repeat", 0.7);
    }
  }
  if (opts.env && Number.isFinite(opts.threshold)) {
    const windowSec = opts.windowSec ?? 0.01;
    const regions = activeRegions(opts.env, { windowSec, threshold: opts.threshold, minSilence: 0.08, minSpeech: 0.18 });
    const sorted = [...words].sort((a, b) => a.start - b.start);
    let wi = 0;
    let voiced = 0;
    let coveredTotal = 0;
    const found = [];
    for (const [s, e] of regions) {
      while (wi < sorted.length && sorted[wi].end < s - 0.05) wi++;
      let covered = 0;
      const pieces = [];
      for (let j = wi; j < sorted.length && sorted[j].start < e + 0.05; j++) {
        const a = Math.max(s, sorted[j].start - 0.05);
        const b = Math.min(e, sorted[j].end + 0.05);
        if (b > a) pieces.push([a, b]);
      }
      for (const [a, b] of normalizeRanges(pieces)) covered += b - a;
      const len = e - s;
      voiced += len;
      coveredTotal += covered;
      if (covered < 0.05 && len >= 0.2 && len <= MAX_SOUND) {
        found.push([s, e, len > 0.35 ? 0.65 : 0.5, len > 0.35]);
      } else if (covered > 0 && len - covered >= 0.35) {
        let cursor = s;
        for (const [a, b] of normalizeRanges(pieces)) {
          if (a - cursor >= 0.35 && a - cursor <= MAX_SOUND) found.push([cursor, a, 0.45, false]);
          cursor = b;
        }
        if (e - cursor >= 0.35 && e - cursor <= MAX_SOUND) found.push([cursor, e, 0.45, false]);
      }
    }
    if (voiced > 0 && coveredTotal / voiced >= MIN_COVERAGE) {
      for (const [s, e, conf, sel] of found) push(s, e, "\u2026", "sound", conf, sel);
    }
  }
  out.sort((a, b) => a.start - b.start);
  const merged = [];
  for (const f of out) {
    const last = merged[merged.length - 1];
    if (last && f.start < last.end - 0.02) {
      if (KIND_RANK[f.kind] < KIND_RANK[last.kind]) Object.assign(last, { kind: f.kind, text: f.text, selected: f.selected });
      last.end = Math.max(last.end, f.end);
      last.confidence = Math.max(last.confidence, f.confidence);
    } else merged.push({ ...f });
  }
  return merged.map((f, i) => ({ id: `f${i + 1}`, ...f }));
}
var KIND_RANK = { filler: 0, repeat: 1, sound: 2, soft: 3 };
function subtractRanges(keep, remove, { pad: pad2 = 0.03, minKeep = 0.08 } = {}) {
  const cuts = normalizeRanges(remove.map(([s, e]) => [Math.max(0, s - pad2), e + pad2]));
  const out = [];
  for (const [ks, ke] of keep) {
    let cursor = ks;
    for (const [cs, ce] of cuts) {
      if (ce <= cursor || cs >= ke) continue;
      if (cs > cursor) out.push([cursor, cs]);
      cursor = Math.max(cursor, ce);
    }
    if (cursor < ke) out.push([cursor, ke]);
  }
  return out.filter(([s, e]) => e - s >= minKeep);
}
function withoutFillers(words, language = "tr") {
  const lang = language.slice(0, 2);
  return words.filter((w) => !isHardFiller(w.text, lang, w.end - w.start));
}
var HARD_FILLER = /^(ı+|ıı+|e+|ee+|ı+m+|hı+|ha+|ah+|oh+|um+|uh+|hmm+)$/i;
var similarToken = (x, y) => x === y || x.length >= 4 && y.length >= 4 && x.slice(0, 4) === y.slice(0, 4);
function findRetakes(words, { language = "tr", pause = 0.7, maxSpan = 25 } = {}) {
  const lang = language.slice(0, 2);
  const sents = [];
  let cur = [];
  words.forEach((w, i) => {
    cur.push(w);
    const next = words[i + 1];
    if (!next || /[.!?…]["')\]]?$/.test(String(w.text).trim()) || next.start - w.end > pause) {
      sents.push({ start: cur[0].start, end: cur[cur.length - 1].end, words: cur, text: cur.map((x) => x.text).join(" ") });
      cur = [];
    }
  });
  const tokens = (s) => s.words.map((w) => clean4(w.text, lang)).filter((t) => t && !HARD_FILLER.test(t));
  const out = [];
  for (let i = 0; i < sents.length; i++) {
    const a = tokens(sents[i]);
    if (a.length < 2) continue;
    for (let j = i + 1; j <= i + 2 && j < sents.length; j++) {
      if (sents[j].start - sents[i].start > maxSpan) break;
      if (j === i + 2 && tokens(sents[i + 1]).length > 6) break;
      const b = tokens(sents[j]);
      if (b.length < 2) continue;
      const k = Math.min(a.length, b.length, 4);
      let m2 = 0;
      let strong = false;
      for (let x = 0; x < k; x++) {
        if (similarToken(a[x], b[x])) {
          m2++;
          if (a[x].length >= 4) strong = true;
        }
      }
      if (strong && m2 >= Math.max(2, Math.ceil(k * 0.75))) {
        out.push({ start: sents[i].start, end: sents[j].start, text: sents.slice(i, j).map((x) => x.text).join(" "), kind: "retake", confidence: Math.round(m2 / k * 100) / 100, selected: true });
        i = j - 1;
        break;
      }
    }
  }
  return out;
}

// engine/render.js
var import_node_fs8 = require("fs");
var import_node_os4 = require("os");
var import_node_path7 = require("path");
var OVERLAY_CODECS = {
  // QuickTime Animation: küçük dosya, Premiere'de sorunsuz.
  qtrle: { label: "QuickTime Animation (k\xFC\xE7\xFCk, Premiere i\xE7in)", args: ["-c:v", "qtrle", "-pix_fmt", "argb"] },
  // ProRes 4444: her yerde açılır, dosya büyük.
  prores: { label: "ProRes 4444 (Resolve i\xE7in, b\xFCy\xFCk dosya)", args: ["-c:v", "prores_ks", "-profile:v", "4444", "-qscale:v", "24", "-pix_fmt", "yuva444p10le", "-vendor", "apl0"] },
  png: { label: "PNG (MOV i\xE7inde)", args: ["-c:v", "png", "-pix_fmt", "rgba"] }
};
function prepareWorkDir(ass, fontsDir) {
  const dir = (0, import_node_fs8.mkdtempSync)((0, import_node_path7.join)((0, import_node_os4.tmpdir)(), "makas-ass-"));
  (0, import_node_fs8.writeFileSync)((0, import_node_path7.join)(dir, "sub.ass"), ass, "utf8");
  let fonts = false;
  if (fontsDir) {
    try {
      (0, import_node_fs8.symlinkSync)(fontsDir, (0, import_node_path7.join)(dir, "fonts"), "dir");
      fonts = true;
    } catch {
      try {
        (0, import_node_fs8.mkdirSync)((0, import_node_path7.join)(dir, "fonts"));
        for (const f of (0, import_node_fs8.readdirSync)(fontsDir)) if (/\.(ttf|otf)$/i.test(f)) (0, import_node_fs8.copyFileSync)((0, import_node_path7.join)(fontsDir, f), (0, import_node_path7.join)(dir, "fonts", f));
        fonts = true;
      } catch {
        fonts = false;
      }
    }
  }
  return { dir, fonts };
}
function imageLayers(images, duration, from) {
  const inputs = [];
  let chain = "";
  let last = from;
  (images ?? []).forEach((im, i) => {
    inputs.push("-loop", "1", "-t", Math.max(0.1, duration).toFixed(3), "-i", im.path);
    const w = Math.max(2, Math.round(im.w));
    const h = Math.max(2, Math.round(im.h));
    const fit = im.round ? `scale=${w}:${h}:force_original_aspect_ratio=increase,crop=${w}:${h},format=rgba,geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='if(lte(hypot(X-W/2,Y-H/2),W/2),alpha(X,Y),0)'` : `scale=${w}:${h}:force_original_aspect_ratio=decrease,format=rgba,pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2:color=black@0`;
    const fin = im.fadeIn != null ? `,fade=t=in:st=${im.fadeIn.toFixed(2)}:d=0.3:alpha=1` : "";
    const fout = im.fadeOutAt != null ? `,fade=t=out:st=${im.fadeOutAt.toFixed(2)}:d=0.35:alpha=1` : "";
    chain += `;[${i + 1}:v]${fit}${fin}${fout}[im${i}];${last}[im${i}]overlay=${Math.round(im.x)}:${Math.round(im.y)}:format=auto[o${i}]`;
    last = `[o${i}]`;
  });
  return { inputs, chain, last };
}
async function renderOverlay(ffmpeg, opts, { signal, onProgress } = {}) {
  (0, import_node_fs8.writeFileSync)(opts.assPath, opts.ass, "utf8");
  const codec = OVERLAY_CODECS[opts.codec] ?? OVERLAY_CODECS.qtrle;
  const fps = Math.max(1, opts.fps || 30);
  const work = prepareWorkDir(opts.ass, opts.fontsDir);
  const fontsOpt = work.fonts ? ":fontsdir=fonts" : "";
  const layers = imageLayers(opts.images, opts.duration, "[a]");
  const K = Math.max(1, Math.round(opts.motionBlur ?? 1));
  const blur = K > 1 ? `,format=gbrap,premultiply=inplace=1,tmix=frames=${K},select='eq(mod(n,${K}),${K - 1})',setpts=N/(${fps}*TB),unpremultiply=inplace=1,fps=${fps}` : "";
  const args = [
    "-hide_banner",
    "-loglevel",
    "error",
    "-nostdin",
    "-y",
    "-progress",
    "pipe:2",
    "-f",
    "lavfi",
    "-i",
    `color=c=black@0.0:s=${opts.width}x${opts.height}:r=${fps * K}:d=${Math.max(0.1, opts.duration).toFixed(3)},format=rgba`,
    ...layers.inputs,
    "-filter_complex",
    `[0:v]ass=sub.ass:alpha=1${fontsOpt}${blur}[a]${layers.chain}`,
    "-map",
    layers.last,
    ...codec.args,
    opts.outPath
  ];
  try {
    await run(ffmpeg, args, {
      cwd: work.dir,
      signal,
      onStderrLine: (line) => {
        const m2 = /^out_time_us=(\d+)/.exec(line);
        if (m2 && onProgress) onProgress(Math.min(1, Number(m2[1]) / 1e6 / opts.duration));
      }
    });
  } finally {
    (0, import_node_fs8.rmSync)(work.dir, { recursive: true, force: true });
  }
  return opts.outPath;
}
async function renderPreviewGif(ffmpeg, opts, { signal } = {}) {
  const work = prepareWorkDir(opts.ass, opts.fontsDir);
  const fontsOpt = work.fonts ? ":fontsdir=fonts" : "";
  const w = opts.width >= opts.height ? 480 : 270;
  const h = Math.round(w * opts.height / opts.width / 2) * 2;
  const k = w / opts.width;
  const images = (opts.images ?? []).map((im) => ({ ...im, x: im.x * k, y: im.y * k, w: im.w * k, h: im.h * k }));
  const still = opts.still != null;
  const dur = still ? 0.2 : opts.duration;
  const layers = imageLayers(still ? images.map((im) => ({ ...im, fadeIn: null, fadeOutAt: null })) : images, dur, "[s]");
  const seek = still ? `,setpts=PTS+${Math.max(0, opts.still).toFixed(3)}/TB` : "";
  const tail2 = still ? "null" : "split[a][b];[a]palettegen=max_colors=64[p];[b][p]paletteuse=dither=bayer:bayer_scale=4";
  const vf = `[0:v]null${seek},ass=sub.ass${fontsOpt}[s]${layers.chain};${layers.last}${tail2}`;
  const outArgs = still ? ["-frames:v", "1", "-update", "1", opts.outPath] : ["-loop", "0", opts.outPath];
  const runWith = (bg) => run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-f", "lavfi", "-i", bg, ...layers.inputs, "-filter_complex", vf, ...outArgs], { cwd: work.dir, signal });
  try {
    try {
      await runWith(`gradients=s=${w}x${h}:c0=0x2a2233:c1=0x15131c:x0=0:y0=0:x1=${w}:y1=${h}:d=${dur.toFixed(2)}:r=15`);
    } catch {
      await runWith(`color=c=0x1c1924:s=${w}x${h}:r=15:d=${dur.toFixed(2)}`);
    }
  } finally {
    (0, import_node_fs8.rmSync)(work.dir, { recursive: true, force: true });
  }
  return opts.outPath;
}
async function renderTransitionGif(ffmpeg, opts, { signal } = {}) {
  const work = prepareWorkDir(opts.ass, null);
  const w = opts.width >= opts.height ? 320 : 180;
  const h = Math.round(w * opts.height / opts.width / 2) * 2;
  const d = opts.duration.toFixed(2);
  const tail2 = "split[a][b];[a]palettegen=max_colors=96[p];[b][p]paletteuse=dither=bayer:bayer_scale=3";
  const vf = `[0:v][1:v]overlay=enable='gte(t\\,${opts.mid.toFixed(3)})',ass=sub.ass,${tail2}`;
  const runWith = (a, b) => run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-f", "lavfi", "-i", a, "-f", "lavfi", "-i", b, "-filter_complex", vf, "-loop", "0", opts.outPath], { cwd: work.dir, signal });
  const grad = (c0, c1) => `gradients=s=${w}x${h}:c0=${c0}:c1=${c1}:x0=0:y0=0:x1=${w}:y1=${h}:d=${d}:r=20:speed=0.00001`;
  try {
    try {
      await runWith(grad("0x2563eb", "0x0ea5a4"), grad("0xf97316", "0xdb2777"));
    } catch {
      await runWith(`color=c=0x2563eb:s=${w}x${h}:r=20:d=${d}`, `color=c=0xf97316:s=${w}x${h}:r=20:d=${d}`);
    }
  } finally {
    (0, import_node_fs8.rmSync)(work.dir, { recursive: true, force: true });
  }
  return opts.outPath;
}
async function muxTransitionSound(ffmpeg, o, { signal } = {}) {
  const d = o.duration.toFixed(3);
  const shift = o.offset >= 0 ? `adelay=${Math.round(o.offset * 1e3)}:all=1` : `atrim=start=${(-o.offset).toFixed(3)},asetpts=PTS-STARTPTS`;
  const fadeAt = Math.max(0, o.duration - 0.03).toFixed(3);
  const chain = `[1:a]aresample=48000,aformat=channel_layouts=stereo,${shift},volume=${Number(o.volumeDb).toFixed(1)}dB,apad,atrim=0:${d},afade=t=out:st=${fadeAt}:d=0.03,asplit[a1][a2]`;
  await run(
    ffmpeg,
    ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", o.video, "-i", o.sound, "-filter_complex", chain, "-map", "0:v", "-map", "[a1]", "-c:v", "copy", "-c:a", "pcm_s16le", o.outMov, "-map", "[a2]", "-c:a", "pcm_s16le", o.outWav],
    { signal }
  );
}
var XFADE = { erime: "fade", bulanik: "hblur", beyaz: "fadewhite", siyah: "fadeblack", daireac: "circleopen", radyal: "radial", yumusak: "smoothleft", piksel: "pixelize", dagil: "dissolve", yakin: "zoomin" };
async function renderClipTransition(ffmpeg, o, { signal } = {}) {
  const W = o.width;
  const H = o.height;
  const F = Math.max(1, o.fps);
  const K = o.samples ?? 4;
  const half = o.half;
  const lead = o.lead ?? 0;
  const tail2 = o.tail ?? 0;
  const D = 2 * half;
  const L = lead + D + tail2;
  const f3 = (n) => n.toFixed(4);
  const even = (n) => 2 * Math.ceil(n / 2);
  const norm = (idx, src, tag) => {
    const k = Math.max(0.01, src.scale ?? 1);
    const size = o.fit === "fit" ? `scale=w='2*trunc(${W}*${f3(k)}/2)':h='2*trunc(${H}*${f3(k)}/2)':force_original_aspect_ratio=decrease` : `scale=w='2*trunc(iw*${f3(k)}/2)':h='2*trunc(ih*${f3(k)}/2)'`;
    const pad2 = `tpad=start_mode=clone:start_duration=${f3(lead + (src.startPad ?? 0))}:stop_mode=clone:stop_duration=${f3(L + 1)}`;
    return `[${idx}:v]fps=${F},setpts=PTS-STARTPTS,${size},crop='min(iw,${W})':'min(ih,${H})',pad=${W}:${H}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,format=yuv444p,${pad2},trim=duration=${f3(L)},setpts=PTS-STARTPTS[${tag}]`;
  };
  const parts = [norm(0, o.a, "a"), norm(1, o.b, "b")];
  const id = o.id;
  const tailFilter = `fps=${F}${o.extraFilter ? `,${o.extraFilter}` : ""}[v]`;
  const up = (tag) => `[${tag}]fps=${F * K},setpts=PTS-STARTPTS[${tag}s]`;
  const down = `tmix=frames=${K},select='eq(mod(n,${K}),${K - 1})',setpts=N/(${F}*TB)`;
  if (XFADE[id]) {
    parts.push(`[a]trim=duration=${f3(lead + D)},setpts=PTS-STARTPTS[ax]`, `[b]trim=start=${f3(lead)},setpts=PTS-STARTPTS[bx]`);
    parts.push(`[ax][bx]xfade=transition=${XFADE[id]}:duration=${f3(D)}:offset=${f3(lead)},${tailFilter}`);
  } else if (id === "itsola" || id === "itsaga" || id === "ityukari") {
    const P = `clip((t-${f3(lead)})/${f3(D)},0,1)`;
    const e = `if(lt(${P},0.5),4*pow(${P},3),1-pow(2-2*${P},3)/2)`;
    parts.push(up("a"), up("b"));
    if (id === "itsola") parts.push(`[as][bs]hstack,crop=${W}:${H}:x='${W}*(${e})':y=0,${down},${tailFilter}`);
    else if (id === "itsaga") parts.push(`[bs][as]hstack,crop=${W}:${H}:x='${W}*(1-(${e}))':y=0,${down},${tailFilter}`);
    else parts.push(`[as][bs]vstack,crop=${W}:${H}:x=0:y='${H}*(${e})',${down},${tailFilter}`);
  } else {
    const pA = `clip((t-${f3(lead)})/${f3(half)},0,1)`;
    const pB = `clip(t/${f3(half)},0,1)`;
    const eA = `pow(${pA},3)`;
    const eB = `pow(1-${pB},3)`;
    const nA = Math.max(1, Math.round(half * F * K));
    const zA = `pow(clip((on-${Math.round(lead * F * K)})/${nA},0,1),3)`;
    const zB = `pow(1-clip(on/${nA},0,1),3)`;
    const CW = even(W * 2.4);
    const CH = even(H * 2.4);
    const DG = even(Math.hypot(W, H) + 4);
    parts.push(up("a"), up("b"));
    parts.push(`[as]trim=duration=${f3(lead + half)},setpts=PTS-STARTPTS[a0]`, `[bs]trim=start=${f3(lead + half)},setpts=PTS-STARTPTS[b0]`);
    const tile = (tag, cw, ch) => `[${tag}0]split=3[${tag}o][${tag}f1][${tag}f2];[${tag}f1]hflip[${tag}l];[${tag}f2]hflip[${tag}r];[${tag}l][${tag}o][${tag}r]hstack=3,split=3[${tag}m][${tag}u1][${tag}d1];[${tag}u1]vflip[${tag}u];[${tag}d1]vflip[${tag}d];[${tag}u][${tag}m][${tag}d]vstack=3,crop=${cw}:${ch}[${tag}t]`;
    const pair = (tag, order, vertical) => {
      const flip = vertical ? "vflip" : "hflip";
      const stack = vertical ? "vstack" : "hstack";
      return `[${tag}0]split[${tag}o][${tag}f0];[${tag}f0]${flip}[${tag}f];${order === "of" ? `[${tag}o][${tag}f]` : `[${tag}f][${tag}o]`}${stack}[${tag}t]`;
    };
    const zoom = (src, tag, z) => `[${src}]zoompan=z='${z}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=${W}x${H}:fps=${F * K}[${tag}x]`;
    if (id === "zoomin") {
      parts.push(zoom("a0", "a", `1+1.6*${zA}`));
      parts.push(tile("b", CW, CH), zoom("bt", "b", `2.4*(1-0.55*${zB})`));
    } else if (id === "zoomout") {
      parts.push(tile("a", CW, CH), zoom("at", "a", `2.4*(1-0.55*${zA})`));
      parts.push(zoom("b0", "b", `1+1.6*${zB}`));
    } else if (id === "sola" || id === "saga" || id === "yukarikay") {
      const vertical = id === "yukarikay";
      const len = vertical ? H : W;
      const crop = (tag, expr) => `[${tag}t]crop=${W}:${H}:${vertical ? `x=0:y='${expr}'` : `x='${expr}':y=0`}[${tag}x]`;
      if (id !== "saga") {
        parts.push(pair("a", "of", vertical), crop("a", `${len}*${eA}`));
        parts.push(pair("b", "fo", vertical), crop("b", `${len}*(1-${eB})`));
      } else {
        parts.push(pair("a", "fo", vertical), crop("a", `${len}*(1-${eA})`));
        parts.push(pair("b", "of", vertical), crop("b", `${len}*${eB}`));
      }
    } else if (id === "don") {
      parts.push(tile("a", DG, DG), `[at]rotate=a='(PI/2)*${eA}':ow=${W}:oh=${H}:c=black[ax]`);
      parts.push(tile("b", DG, DG), `[bt]rotate=a='-(PI/2)*${eB}':ow=${W}:oh=${H}:c=black[bx]`);
    } else {
      throw new Error(`Bilinmeyen ge\xE7i\u015F: ${id}`);
    }
    parts.push(`[ax]${down}[av]`, `[bx]${down}[bv]`, `[av][bv]concat=n=2:v=1:a=0,${tailFilter}`);
  }
  await run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", ...o.a.input, ...o.b.input, "-filter_complex", parts.join(";"), "-map", "[v]", ...o.outArgs, o.outPath], { signal });
  return o.outPath;
}

// engine/workflows.js
var ENV_WINDOW = 0.01;
function safeName(name) {
  return String(name || "cikti").replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, " ").trim().slice(0, 80);
}
function stamp() {
  const d = /* @__PURE__ */ new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}
function badRequest(msg) {
  return Object.assign(new Error(msg), { status: 400 });
}
var Workflows = class {
  constructor({ config, tools, media, whisper }) {
    this.config = config;
    this.tools = tools;
    this.media = media;
    this.whisper = whisper;
    this.analyses = /* @__PURE__ */ new Map();
  }
  #remember(kind, data) {
    const id = `${kind}-${(0, import_node_crypto5.randomUUID)().slice(0, 8)}`;
    this.analyses.set(id, { kind, ...data });
    while (this.analyses.size > 12) this.analyses.delete(this.analyses.keys().next().value);
    return id;
  }
  #analysis(id, kind) {
    const a = this.analyses.get(id);
    if (!a || a.kind !== kind) throw Object.assign(new Error("Analiz bulunamad\u0131; l\xFCtfen yeniden analiz edin"), { status: 404 });
    return a;
  }
  #loadTimeline(source) {
    if (!(source == null ? void 0 : source.xmlPath) || !(0, import_node_fs9.existsSync)(source.xmlPath)) throw badRequest("Zaman \xE7izelgesi XML dosyas\u0131 bulunamad\u0131");
    return readTimeline((0, import_node_fs9.readFileSync)(source.xmlPath, "utf8"));
  }
  /** Altyazı yazı tiplerinin ölçüleri (kutu stilleri için); yazı tipi klasörü yoksa null. */
  #measure() {
    if (this._measure !== void 0) return this._measure;
    const dir = this.config.fontsDir;
    try {
      this._measure = dir ? createMeasurer((0, import_node_fs9.readdirSync)(dir).filter((f) => /\.(ttf|otf)$/i.test(f)).map((f) => ({ bytes: (0, import_node_fs9.readFileSync)((0, import_node_path8.join)(dir, f)) }))) : null;
    } catch {
      this._measure = null;
    }
    return this._measure;
  }
  #outPath(name, ext) {
    return (0, import_node_path8.join)(this.config.outputDir, `${safeName(name)}-${stamp()}${ext}`);
  }
  async inspect(source) {
    if ((source == null ? void 0 : source.kind) === "file") return { kind: "file", ...await this.media.probe(source.path) };
    if ((source == null ? void 0 : source.kind) === "timeline") {
      const tl = this.#loadTimeline(source);
      const info = describeTimeline(tl);
      const missing = [...tl.files.values()].filter((f) => f.path && !(0, import_node_fs9.existsSync)(f.path)).map((f) => f.path);
      return { kind: "timeline", ...info, missing };
    }
    throw badRequest("Ge\xE7ersiz kaynak");
  }
  // --- Transkripsiyon ---
  async transcribe(params, { signal, progress }) {
    const { source, audioTracks = [1], language, translate = false, model, verbatim = false } = params;
    const wav = (0, import_node_path8.join)(this.config.dirs.cache, `stt-${(0, import_node_crypto5.randomUUID)().slice(0, 8)}.wav`);
    let duration;
    let name;
    progress(0.02, "Ses haz\u0131rlan\u0131yor");
    try {
      if ((source == null ? void 0 : source.kind) === "file") {
        const info = await this.media.probe(source.path);
        if (!info.hasAudio) throw badRequest("Bu dosyada ses yok");
        duration = info.duration;
        name = (0, import_node_path8.basename)(source.path, (0, import_node_path8.extname)(source.path));
        await this.media.extractWav(source.path, wav, { signal });
      } else if ((source == null ? void 0 : source.kind) === "timeline") {
        const tl = this.#loadTimeline(source);
        duration = tl.duration / tl.fps;
        name = tl.name;
        const tracks = audioTracks.map((i) => audioTrackSources(tl, Number(i)));
        if (!tracks.flat().length) throw badRequest("Se\xE7ilen ses par\xE7alar\u0131nda klip yok");
        await this.media.renderTracksWav(tracks, duration, wav, { signal, onProgress: (p) => progress(0.02 + p * 0.13) });
      } else throw badRequest("Ge\xE7ersiz kaynak");
      progress(0.15, translate ? "Konu\u015Fma tan\u0131n\u0131yor ve \u0130ngilizceye \xE7evriliyor" : "Konu\u015Fma tan\u0131n\u0131yor");
      const lang = language ?? this.config.settings.language ?? "tr";
      const result = await this.whisper.transcribe({
        wavPath: wav,
        language,
        translate,
        model,
        // Dolgu seslerini yakalamak için whisper'a dolgu içeren bir başlangıç cümlesi verilir.
        prompt: verbatim ? VERBATIM_PROMPTS[lang] ?? VERBATIM_PROMPTS.default : void 0,
        signal,
        onProgress: (p) => progress(0.15 + p * 0.85, `Konu\u015Fma tan\u0131n\u0131yor %${Math.round(p * 100)}`)
      });
      let words = result.words;
      try {
        const env = await this.media.fileEnvelope(wav, { windowSec: ENV_WINDOW, signal });
        words = alignToSpeech(words, env, { windowSec: ENV_WINDOW, threshold: autoThreshold(env).threshold });
      } catch {
      }
      const transcript = {
        id: (0, import_node_crypto5.randomUUID)().slice(0, 8),
        name,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        source,
        audioTracks,
        language: translate ? "en" : result.language ?? language,
        sourceLanguage: result.language ?? language,
        translated: translate,
        model: result.model,
        duration,
        words,
        segments: result.segments
      };
      this.saveTranscript(transcript);
      return this.#transcriptSummary(transcript);
    } finally {
      (0, import_node_fs9.rmSync)(wav, { force: true });
      (0, import_node_fs9.rmSync)(wav.replace(/\.wav$/, ".whisper.json"), { force: true });
    }
  }
  saveTranscript(t) {
    (0, import_node_fs9.writeFileSync)((0, import_node_path8.join)(this.config.dirs.transcripts, `${t.id}.json`), JSON.stringify(t));
  }
  getTranscript(id) {
    const p = (0, import_node_path8.join)(this.config.dirs.transcripts, `${String(id).replace(/[^\w-]/g, "")}.json`);
    if (!(0, import_node_fs9.existsSync)(p)) throw Object.assign(new Error("Transkript bulunamad\u0131"), { status: 404 });
    return JSON.parse((0, import_node_fs9.readFileSync)(p, "utf8"));
  }
  listTranscripts() {
    return (0, import_node_fs9.readdirSync)(this.config.dirs.transcripts).filter((f) => f.endsWith(".json")).map((f) => {
      try {
        return this.#transcriptSummary(JSON.parse((0, import_node_fs9.readFileSync)((0, import_node_path8.join)(this.config.dirs.transcripts, f), "utf8")));
      } catch {
        return null;
      }
    }).filter(Boolean).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
  #transcriptSummary(t) {
    return {
      id: t.id,
      name: t.name,
      createdAt: t.createdAt,
      language: t.language,
      translated: t.translated,
      model: t.model,
      duration: t.duration,
      wordCount: t.words.length,
      preview: wordsToText(t.words.slice(0, 40)),
      source: t.source
    };
  }
  /** Kullanıcının düzelttiği metni kaydeder (kelime zamanları korunarak). */
  updateTranscriptWords(id, words) {
    const t = this.getTranscript(id);
    if (!Array.isArray(words)) throw badRequest("Kelime listesi gerekli");
    t.words = words.filter((w) => w && typeof w.text === "string" && Number.isFinite(w.start) && Number.isFinite(w.end)).map((w) => ({ text: w.text.trim(), start: w.start, end: w.end, p: w.p ?? 1 })).filter((w) => w.text);
    this.saveTranscript(t);
    return this.#transcriptSummary(t);
  }
  /** Sessizlik kesiminden sonra transkripti yeni zaman çizelgesine taşır. */
  remapTranscript(id, keep) {
    const t = this.getTranscript(id);
    const copy = {
      ...t,
      id: (0, import_node_crypto5.randomUUID)().slice(0, 8),
      name: `${t.name} (kesilmi\u015F)`,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      words: remapWords(t.words, keep),
      duration: keep.reduce((n, [s, e]) => n + (e - s), 0),
      remappedFrom: t.id
    };
    copy.segments = [];
    this.saveTranscript(copy);
    return this.#transcriptSummary(copy);
  }
  // --- Altyazı ---
  buildCaptions({ transcriptId, words, options }) {
    const t = words ? null : this.getTranscript(transcriptId);
    let src = words ?? t.words;
    if ((options == null ? void 0 : options.removeFillers) !== false) src = withoutFillers(src, (t == null ? void 0 : t.language) ?? (options == null ? void 0 : options.language) ?? "tr");
    return buildCaptions(src, options ?? {});
  }
  // --- Dolgu sesleri ve birleşik kesim ---
  /** Transkript ve (varsa) sessizlik analizinin ses zarfıyla dolgu seslerini bulur. */
  detectFillers({ transcriptId, analysisId, options = {} }) {
    const t = this.getTranscript(transcriptId);
    let env = null;
    let threshold = null;
    if (analysisId) {
      const a = this.#analysis(analysisId, "silence");
      env = a.env;
      threshold = Number.isFinite(options.threshold) ? options.threshold : a.lastThreshold;
    }
    const language = t.sourceLanguage ?? t.language ?? "tr";
    const items = [...detectFillers(t.words, { language, env, threshold, windowSec: ENV_WINDOW }), ...findRetakes(t.words, { language })].sort((x, y) => x.start - y.start);
    const total = items.filter((f) => f.selected).reduce((n, f) => n + (f.end - f.start), 0);
    return { items, selectedDuration: total };
  }
  /**
   * Sessizlik kesimi + seçili dolgu sesleri + isteğe bağlı jump cut yakınlaştırmasını tek seferde
   * uygular ve yeni sekans XML'i üretir.
   */
  async applyEdit({ analysisId, keep, remove = [], zoom = null, name, range = null, sfx = null }) {
    const a = this.#analysis(analysisId, "silence");
    const base = keep ?? a.lastKeep ?? [[0, a.duration]];
    const finalKeep = remove.length ? subtractRanges(base, remove) : base;
    return this.applySilence({ analysisId, keep: finalKeep, name, zoom, range, sfx });
  }
  /** Önizleme için kısa bir ses parçası üretir (zaman çizelgesi zamanında). */
  async audioSnippet({ analysisId, start, end }) {
    const a = this.#analysis(analysisId, "silence");
    const s = Math.max(0, start);
    const e = Math.min(a.duration, Math.max(s + 0.05, end));
    const out = (0, import_node_path8.join)(this.config.dirs.cache, `snip-${(0, import_node_crypto5.randomUUID)().slice(0, 8)}.wav`);
    if (a.source.kind === "file") await this.media.extractWav(a.source.path, out, { start: s, duration: e - s });
    else {
      const tl = this.#loadTimeline(a.source);
      const tracks = a.audioTracks.map((i) => audioTrackSources(tl, Number(i)));
      await this.media.renderWindowWav(tracks, s, e, out);
    }
    return { path: out, start: s, end: e };
  }
  exportCaptions({ segments, name = "altyazi", formats = ["srt"], style, width = 1920, height = 1080 }) {
    if (!Array.isArray(segments) || !segments.length) throw badRequest("Altyaz\u0131 segmenti yok");
    const files = {};
    const base = this.#outPath(name, "");
    for (const f of formats) {
      const path = `${base}.${f}`;
      if (f === "srt") (0, import_node_fs9.writeFileSync)(path, toSrt(segments), "utf8");
      else if (f === "vtt") (0, import_node_fs9.writeFileSync)(path, toVtt(segments), "utf8");
      else if (f === "ass") (0, import_node_fs9.writeFileSync)(path, buildAss(segments, { width, height, style, measure: this.#measure() }), "utf8");
      else if (f === "txt") (0, import_node_fs9.writeFileSync)(path, segments.map((s) => s.text).join("\n") + "\n", "utf8");
      else continue;
      files[f] = path;
    }
    return { files };
  }
  async renderCaptions(params, { signal, progress }) {
    const { segments, style, width = 1920, height = 1080, fps = 30, codec = "qtrle", name = "altyazi" } = params;
    if (!Array.isArray(segments) || !segments.length) throw badRequest("Altyaz\u0131 segmenti yok");
    const duration = Math.max(params.duration ?? 0, segments[segments.length - 1].end + 0.5);
    const outPath = this.#outPath(`${name}-animasyonlu`, ".mov");
    const ass = params.kinetic ? buildKineticAss(segments, { ...params.kinetic, width, height, measure: this.#measure() }) : buildAss(segments, { width, height, style, measure: this.#measure() });
    progress(0.01, params.kinetic ? "Hareketli yaz\u0131 olu\u015Fturuluyor" : "Animasyonlu altyaz\u0131 olu\u015Fturuluyor");
    this.tools.require("ffmpeg");
    const ffmpeg = await this.tools.ffmpegWithSubtitles();
    if (!ffmpeg) {
      const err = new Error(
        process.platform === "darwin" ? `Animasyonlu altyaz\u0131 i\xE7in altyaz\u0131 destekli ffmpeg gerekiyor; Homebrew'un "ffmpeg" paketi bunu i\xE7ermiyor. Terminal'de "brew install ffmpeg-full" \xE7al\u0131\u015Ft\u0131r\u0131n (ya da kurulumu yeniden \xE7al\u0131\u015Ft\u0131r\u0131n). O zamana kadar "Altyaz\u0131 izi olarak ekle"yi kullanabilirsiniz.` : "Animasyonlu altyaz\u0131 i\xE7in altyaz\u0131 (libass) destekli ffmpeg gerekiyor. Kurulumu yeniden \xE7al\u0131\u015Ft\u0131r\u0131n ya da Ayarlar'dan tam s\xFCr\xFCm ffmpeg se\xE7in."
      );
      err.status = 412;
      err.code = "NO_LIBASS";
      throw err;
    }
    await renderOverlay(
      ffmpeg,
      { ass, assPath: outPath.replace(/\.mov$/, ".ass"), outPath, width, height, fps, duration, codec, fontsDir: this.config.fontsDir },
      { signal, onProgress: (p) => progress(p, `Video olu\u015Fturuluyor %${Math.round(p * 100)}`) }
    );
    return { path: outPath, duration, width, height, fps };
  }
  // --- Sessizlik ---
  async analyzeSilence(params, { signal, progress }) {
    const { source, audioTracks = [1], options = {} } = params;
    let env;
    let duration;
    let fps = 30;
    if ((source == null ? void 0 : source.kind) === "file") {
      const info = await this.media.probe(source.path);
      if (!info.hasAudio) throw badRequest("Bu dosyada ses yok");
      duration = info.duration;
      fps = info.fps || 30;
      env = await this.media.fileEnvelope(source.path, { windowSec: ENV_WINDOW, signal, onProgress: (p) => progress(p * 0.95, "Ses analiz ediliyor") });
    } else if ((source == null ? void 0 : source.kind) === "timeline") {
      const tl = this.#loadTimeline(source);
      duration = tl.duration / tl.fps;
      fps = tl.fps;
      const envs = [];
      for (const [i, track] of audioTracks.entries()) {
        envs.push(
          await this.media.trackEnvelope(audioTrackSources(tl, Number(track)), duration, {
            windowSec: ENV_WINDOW,
            signal,
            onProgress: (p) => progress((i + p) / audioTracks.length * 0.95, `A${track} analiz ediliyor`)
          })
        );
      }
      env = combineEnvelopes(envs);
    } else throw badRequest("Ge\xE7ersiz kaynak");
    let loudest = -Infinity;
    for (const v of env) if (v > loudest) loudest = v;
    if (!(loudest > -70)) {
      throw badRequest("Se\xE7ilen ses par\xE7alar\u0131nda duyulabilir ses bulunamad\u0131. Klibin sesi kapal\u0131 olabilir ya da ses kayna\u011F\u0131 okunamad\u0131.");
    }
    const id = this.#remember("silence", { source, audioTracks, env, duration, fps });
    return { analysisId: id, ...this.recomputeSilence(id, options) };
  }
  /** Eşik değiştiğinde ses yeniden okunmadan sonuç güncellenir. */
  recomputeSilence(analysisId, options = {}) {
    const a = this.#analysis(analysisId, "silence");
    const r = detectSilence(a.env, { ...cleanOptions(options), windowSec: ENV_WINDOW, duration: a.duration });
    a.lastKeep = r.keep;
    a.lastThreshold = r.threshold;
    const factor = Math.max(1, Math.ceil(a.env.length / 1600));
    return {
      duration: a.duration,
      fps: a.fps,
      threshold: r.threshold,
      floor: r.floor,
      speech: r.speech,
      keep: r.keep,
      silences: r.silences,
      removed: r.removed,
      waveform: { step: factor * ENV_WINDOW, values: Array.from(downsampleEnvelope(a.env, factor), (v) => Math.round(v)) }
    };
  }
  async applySilence({ analysisId, keep, name, zoom, range = null, sfx = null }) {
    const a = this.#analysis(analysisId, "silence");
    const ranges = range && range[1] > range[0] ? limitToRange(keep ?? a.lastKeep ?? [], range, a.duration) : keep ?? a.lastKeep;
    if (!(ranges == null ? void 0 : ranges.length)) throw badRequest('Kesimden sonra geriye b\xF6l\xFCm kalm\u0131yor. Kesim tarz\u0131n\u0131 "Do\u011Fal" yap\u0131p yeniden deneyin.');
    let tl;
    if (a.source.kind === "file") {
      const info = await this.media.probe(a.source.path);
      tl = readTimeline(buildSequenceFromMedia(info));
    } else tl = this.#loadTimeline(a.source);
    const keepFrames = ranges.map(([s, e]) => [Math.floor(s * tl.fps), Math.ceil(e * tl.fps)]);
    const seqName = name ?? derivedName(tl.name, "Kesilmi\u015F");
    const res = rippleKeep(tl, keepFrames, { name: seqName, zoom });
    let sfxAdded = 0;
    const credits = /* @__PURE__ */ new Set();
    if ((sfx == null ? void 0 : sfx.enabled) && this.sfx) {
      const cuts = [];
      let acc = 0;
      keepFrames.forEach(([s, e], i) => {
        acc += e - s;
        if (i < keepFrames.length - 1) cuts.push(acc / tl.fps);
      });
      const minGap = sfx.minGap ?? 2.5;
      const at = [];
      for (const c of cuts) if (!at.length || c - at[at.length - 1] >= minGap) at.push(c);
      if (at.length) {
        const sounds = await this.sfx.autoSounds({ category: sfx.category ?? "whoosh", volumeDb: sfx.volumeDb ?? -10 });
        const clips = at.map((c, i) => {
          const s = sounds[i % sounds.length];
          if (s.credit) credits.add(s.credit);
          return { path: s.path, name: s.name, start: Math.max(0, c - s.duration / 2), duration: s.duration, channels: 2 };
        });
        sfxAdded = addAudioClips(tl, clips);
      }
    }
    const xmlPath = this.#outPath(seqName, ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, serializeTimeline(tl), "utf8");
    const keepSec = keepFrames.map(([s, e]) => [s / tl.fps, e / tl.fps]);
    return { xmlPath, name: seqName, duration: res.duration / tl.fps, keep: keepSec, removedTransitions: res.removedTransitions, sfxAdded, credits: [...credits] };
  }
  // --- Efektler ---
  /** Hareketli yazının kısa, döngülü önizlemesi (gerçek çıktıyla aynı çizim). */
  async kineticPreview({ segments, options = {}, width = 1080, height = 1920 }, { signal } = {}) {
    const sample2 = "Bu videoda size asl\u0131nda \xE7ok kolay bir y\xF6ntem g\xF6sterece\u011Fim".split(" ").map((text, i) => ({ text, start: i * 0.38, end: i * 0.38 + 0.34 }));
    let segs = Array.isArray(segments) && segments.length ? segments : buildCaptions(sample2, { maxWords: 3, maxLines: 1, maxCharsPerLine: 30, extendCaptions: true, removePunctuation: true });
    const t0 = segs[0].start;
    segs = segs.filter((s) => s.start - t0 < 4).map((s) => {
      var _a;
      return { ...s, start: s.start - t0, end: s.end - t0, words: (_a = s.words) == null ? void 0 : _a.map((w) => ({ ...w, start: w.start - t0, end: w.end - t0 })) };
    });
    const duration = Math.min(6, segs[segs.length - 1].end + 0.4);
    const ffmpeg = await this.tools.ffmpegWithSubtitles();
    if (!ffmpeg) throw Object.assign(new Error(`\xD6nizleme i\xE7in altyaz\u0131 (libass) destekli ffmpeg gerekiyor. macOS: Terminal'de "brew install ffmpeg-full".`), { status: 412, code: "NO_LIBASS" });
    const ass = buildKineticAss(segs, { ...options, width, height, measure: this.#measure() });
    const outPath = (0, import_node_path8.join)(this.config.dirs.cache, `efekt-${(0, import_node_crypto5.randomUUID)().slice(0, 8)}.gif`);
    await renderPreviewGif(ffmpeg, { ass, outPath, width, height, duration, fontsDir: this.config.fontsDir }, { signal });
    return { path: outPath, duration };
  }
  /** Efekt için çizim: kind → { ass, duration }. Önizlemede süre kısa tutulur. */
  #buildEffect(kind, params, { width, height, duration }) {
    const build = EFFECT_BUILDERS[kind];
    if (!build) throw badRequest(`Bilinmeyen efekt: ${kind}`);
    const built = build({ duration, ...params, width, height, measure: this.#measure() });
    built.images = (built.images ?? []).map((im) => {
      const path = params[im.src];
      if (typeof path !== "string" || !(0, import_node_fs9.existsSync)(path)) throw badRequest("Logo dosyas\u0131 bulunamad\u0131");
      return { ...im, path };
    });
    return built;
  }
  async #libass() {
    this.tools.require("ffmpeg");
    const ffmpeg = await this.tools.ffmpegWithSubtitles();
    if (!ffmpeg) throw Object.assign(new Error(`Efektler i\xE7in altyaz\u0131 (libass) destekli ffmpeg gerekiyor. macOS: Terminal'de "brew install ffmpeg-full"; Windows: kurulumu yeniden \xE7al\u0131\u015Ft\u0131r\u0131n.`), { status: 412, code: "NO_LIBASS" });
    return ffmpeg;
  }
  /** Efekti şeffaf video olarak üretir (zaman çizelgesine ayrıca yerleştirilir). */
  async renderEffect({ kind, params = {}, width = 1920, height = 1080, fps = 30, codec = "qtrle", name = "efekt", duration = 10 }, { signal, progress }) {
    const built = this.#buildEffect(kind, params, { width, height, duration });
    const ffmpeg = await this.#libass();
    const outPath = this.#outPath(`${name}-${kind}`, ".mov");
    progress(0.01, "Efekt olu\u015Fturuluyor");
    await renderOverlay(
      ffmpeg,
      { ass: built.ass, assPath: outPath.replace(/\.mov$/, ".ass"), outPath, width, height, fps, duration: built.duration, codec, fontsDir: this.config.fontsDir, images: built.images },
      { signal, onProgress: (p) => progress(p, `Video olu\u015Fturuluyor %${Math.round(p * 100)}`) }
    );
    return { path: outPath, duration: built.duration, count: built.count ?? null };
  }
  /** Efektin kısa, döngülü önizlemesi (gerçek çıktıyla aynı çizim). */
  async previewEffect({ kind, params = {}, width = 1080, height = 1920, still = false }, { signal } = {}) {
    const built = this.#buildEffect(kind, params, { width, height, duration: 5 });
    const ffmpeg = await this.#libass();
    const outPath = (0, import_node_path8.join)(this.config.dirs.cache, `efekt-${(0, import_node_crypto5.randomUUID)().slice(0, 8)}.${still ? "png" : "gif"}`);
    const duration = Math.min(6, built.duration);
    await renderPreviewGif(ffmpeg, { ass: built.ass, outPath, width, height, duration, fontsDir: this.config.fontsDir, images: built.images, still: still ? Math.min(duration * 0.45, 1.6) : void 0 }, { signal });
    return { path: outPath, duration: built.duration };
  }
  // --- Geçişler ---
  /** Eklentiyle gelen geçiş sesinin yolu (yoksa null). Sesler yazı tiplerinin yanındaki "gecis" klasöründedir. */
  #transitionSound(id) {
    const dir = this.config.transitionSoundsDir ?? (this.config.fontsDir ? (0, import_node_path8.join)((0, import_node_path8.dirname)(this.config.fontsDir), "gecis") : null);
    const p = dir ? (0, import_node_path8.join)(dir, `${id}.wav`) : null;
    return p && (0, import_node_fs9.existsSync)(p) ? p : null;
  }
  /** Arayüz için geçiş listesi. */
  listTransitions() {
    return { items: TRANSITIONS.map((t) => ({ id: t.id, group: t.group, name: t.name, sub: t.sub, tint: t.tint, sound: this.#transitionSound(t.file ?? t.id) ? t.sound : null })) };
  }
  /** Geçişin döngülü önizlemesi: iki sahne arasındaki kesimin üstünde. */
  async previewTransition({ id, color = "#000000", width = 1920, height = 1080 }, { signal } = {}) {
    const built = buildTransition({ width, height, id, color, lead: 0.45, tail: 0.55 });
    const ffmpeg = await this.#libass();
    const key = (0, import_node_crypto5.createHash)("sha1").update(`${built.ass}|${width}x${height}`).digest("hex").slice(0, 10);
    const outPath = (0, import_node_path8.join)(this.config.dirs.cache, `gecis-${id}-${key}.gif`);
    if (!(0, import_node_fs9.existsSync)(outPath) || !(0, import_node_fs9.statSync)(outPath).size) await renderTransitionGif(ffmpeg, { ass: built.ass, outPath, width, height, duration: built.duration, mid: built.mid }, { signal });
    return { path: outPath, duration: built.duration };
  }
  /**
   * Geçişi sekans boyutunda şeffaf video olarak hazırlar. Aynı ayarlarla ikinci kez istenirse
   * var olan dosyalar döner (kurgu programı aynı medyayı yeniden kullanır).
   * @returns {{path:string, videoPath:string, audioPath:string|null, duration:number, mid:number, name:string}}
   *   path: sürükleyip bırakılacak tek dosya (ses varsa içinde); videoPath: yalnızca görüntü;
   *   audioPath: hizalanmış ses; mid: kesimin geleceği an (dosyanın başından sn)
   */
  async renderTransition({ id, color = "#000000", width = 1920, height = 1080, fps = 30, codec = "qtrle", sound = true, volumeDb = -8, separate = true }, { signal, progress = () => {
  } } = {}) {
    const meta = TRANSITIONS.find((t) => t.id === id);
    if (!meta) throw badRequest(`Bilinmeyen ge\xE7i\u015F: ${id}`);
    const built = buildTransition({ width, height, id, color: meta.tint ? color : "#000000" });
    const ffmpeg = await this.#libass();
    const rate = Math.max(1, Number(fps) || 30);
    const vol = Math.max(-40, Math.min(6, Number(volumeDb) || 0));
    const dir = (0, import_node_path8.join)(this.config.outputDir, "Gecisler");
    (0, import_node_fs9.mkdirSync)(dir, { recursive: true });
    const MB = 6;
    const vKey = (0, import_node_crypto5.createHash)("sha1").update(`${built.ass}|${width}x${height}|${rate}|${codec}|mb${MB}`).digest("hex").slice(0, 8);
    const base = (0, import_node_path8.join)(dir, safeName(`Makas Gecis - ${meta.name} ${width}x${height} ${Math.round(rate * 100) / 100}fps ${vKey}`));
    const videoPath = `${base} goruntu.mov`;
    const ready = (p) => (0, import_node_fs9.existsSync)(p) && (0, import_node_fs9.statSync)(p).size > 0;
    const src = sound ? this.#transitionSound(meta.file ?? id) : null;
    const tag = `ses${vol >= 0 ? "+" : ""}${Math.round(vol)}`;
    const path = `${base} ${tag}.mov`;
    const audioPath = `${base} ${tag}.wav`;
    const single = !separate && Boolean(src);
    if (single && ready(path) && ready(audioPath)) return { path, videoPath: path, audioPath, duration: built.duration, mid: built.mid, name: meta.name };
    if (!ready(videoPath)) {
      progress(0.05, "Ge\xE7i\u015F olu\u015Fturuluyor");
      const tmp = `${base} goruntu.tmp.mov`;
      await renderOverlay(ffmpeg, { ass: built.ass, assPath: `${base}.ass`, outPath: tmp, width, height, fps: rate, duration: built.duration, codec, motionBlur: MB }, { signal, onProgress: (p) => progress(0.05 + p * 0.75, "Ge\xE7i\u015F olu\u015Fturuluyor") });
      (0, import_node_fs9.rmSync)(videoPath, { force: true });
      (0, import_node_fs9.copyFileSync)(tmp, videoPath);
      (0, import_node_fs9.rmSync)(tmp, { force: true });
    }
    if (!src) return { path: videoPath, videoPath, audioPath: null, duration: built.duration, mid: built.mid, name: meta.name };
    if (!ready(path) || !ready(audioPath)) {
      progress(0.85, "Ses ekleniyor");
      await muxTransitionSound(ffmpeg, { video: videoPath, sound: src, outMov: path, outWav: audioPath, offset: built.mid - meta.anchor, duration: built.duration, volumeDb: vol }, { signal });
    }
    progress(1, "Haz\u0131r");
    if (single) {
      (0, import_node_fs9.rmSync)(videoPath, { force: true });
      return { path, videoPath: path, audioPath, duration: built.duration, mid: built.mid, name: meta.name };
    }
    return { path, videoPath, audioPath, duration: built.duration, mid: built.mid, name: meta.name };
  }
  // --- Görüntülü geçişler (iki klibin karelerinden) ---
  listClipTransitions() {
    return { items: CLIP_TRANSITIONS.map((t) => ({ id: t.id, name: t.name, sub: t.sub, sound: this.#transitionSound(t.file) ? t.sound : null })) };
  }
  /** Önizleme: iki örnek sahne (ızgaralı renk geçişleri) arasında geçişin döngülü GIF'i. */
  async previewClipTransition({ id, width = 1920, height = 1080 }, { signal } = {}) {
    if (!CLIP_TRANSITIONS.some((t) => t.id === id)) throw badRequest(`Bilinmeyen ge\xE7i\u015F: ${id}`);
    this.tools.require("ffmpeg");
    const ffmpeg = this.tools.resolve("ffmpeg");
    const w = width >= height ? 320 : 180;
    const h = Math.round(w * height / width / 2) * 2;
    const outPath = (0, import_node_path8.join)(this.config.dirs.cache, `gecis-klip-${id}-${w}x${h}-v2.gif`);
    if ((0, import_node_fs9.existsSync)(outPath) && (0, import_node_fs9.statSync)(outPath).size) return { path: outPath };
    const [half, lead, tail2] = [0.35, 0.45, 0.6];
    const scene = (c0, c1, d) => ["-f", "lavfi", "-i", `gradients=s=${w}x${h}:c0=${c0}:c1=${c1}:x0=0:y0=0:x1=${w}:y1=${h}:d=${d.toFixed(2)}:r=20:speed=0.00001,drawgrid=w=${Math.round(w / 8)}:h=${Math.round(w / 8)}:t=1:c=white@0.28`];
    await renderClipTransition(
      ffmpeg,
      {
        id,
        a: { input: scene("0x2563eb", "0x0ea5a4", half * 2) },
        b: { input: scene("0xf97316", "0xdb2777", half * 2) },
        half,
        lead,
        tail: tail2,
        width: w,
        height: h,
        fps: 20,
        samples: 3,
        extraFilter: "split[g1][g2];[g1]palettegen=max_colors=96[gp];[g2][gp]paletteuse=dither=bayer:bayer_scale=3",
        outArgs: ["-loop", "0"],
        outPath
      },
      { signal }
    );
    return { path: outPath };
  }
  /**
   * Kesimin iki yanındaki kliplerden geçiş videosu üretir.
   * @param at kesim anı (sekansın başından sn); bu anda biten ve başlayan iki klip aranır
   * @param fit 'native': kaynak pikseli × ölçek (Premiere); 'fit': kareye sığdır × ölçek (Resolve)
   * @returns {{videoPath, audioPath, path, start, duration, mid, name}} start: videonun sekansta konacağı an
   */
  async renderClipTransitionAt({ source, at, id, duration = 0.5, fit = "native", sound = true, volumeDb = -8 }, { signal, progress = () => {
  } } = {}) {
    const meta = CLIP_TRANSITIONS.find((t) => t.id === id);
    if (!meta) throw badRequest(`Bilinmeyen ge\xE7i\u015F: ${id}`);
    this.tools.require("ffmpeg");
    const ffmpeg = this.tools.resolve("ffmpeg");
    const tl = this.#loadTimeline(source);
    const plan = timelinePlan(tl);
    const T = Number(at);
    const tol = 1.5 / plan.fps;
    let A = null;
    let B = null;
    for (const track of plan.video) {
      const a = track.find((p) => p.enabled !== false && Math.abs(p.end - T) <= tol);
      const b = track.find((p) => p.enabled !== false && Math.abs(p.start - T) <= tol);
      if (a && b) {
        A = a;
        B = b;
        break;
      }
    }
    if (!A || !B) throw badRequest("Bu anda birle\u015Fen iki klip bulunamad\u0131. Oynatma \xE7ubu\u011Funu iki klibin birle\u015Fti\u011Fi kesime getirin.");
    for (const p of [A, B]) if (!(0, import_node_fs9.existsSync)(p.path)) throw badRequest(`Kaynak dosya bulunamad\u0131: ${(0, import_node_path8.basename)(p.path)}`);
    const wanted = Math.min(Math.max(0.15, Number(duration) || 0.5) / 2, A.end - A.start, B.end - B.start);
    const half = Math.max(2, Math.floor(wanted * plan.fps + 0.5)) / plan.fps;
    if (wanted < 0.1) throw badRequest("Klipler ge\xE7i\u015F i\xE7in \xE7ok k\u0131sa (en az 0,1 sn gerekir).");
    const still = (p) => /\.(png|jpe?g|tiff?|bmp|webp)$/i.test(p.path);
    const input = (p, ss) => still(p) ? ["-loop", "1", "-t", (half * 2).toFixed(4), "-i", p.path] : ["-ss", Math.max(0, ss).toFixed(4), "-t", (half * 2 + 0.5).toFixed(4), "-i", p.path];
    const ssA = A.srcIn + (A.end - A.start) - half;
    const ssB = B.srcIn - half;
    const dir = (0, import_node_path8.join)(this.config.outputDir, "Gecisler");
    (0, import_node_fs9.mkdirSync)(dir, { recursive: true });
    const base = (0, import_node_path8.join)(dir, safeName(`Makas Gecis - ${meta.name} ${tl.name} ${T.toFixed(2)}sn ${stamp()}`));
    const videoPath = `${base} goruntu.mov`;
    progress(0.1, "Ge\xE7i\u015F olu\u015Fturuluyor");
    await renderClipTransition(
      ffmpeg,
      {
        id,
        a: { input: input(A, ssA), scale: (A.scale ?? 100) / 100, startPad: still(A) ? 0 : Math.max(0, -ssA) },
        b: { input: input(B, ssB), scale: (B.scale ?? 100) / 100, startPad: still(B) ? 0 : Math.max(0, -ssB) },
        half,
        width: plan.width,
        height: plan.height,
        fps: plan.fps,
        fit: fit === "fit" ? "fit" : "native",
        extraFilter: "format=yuv422p10le",
        outArgs: ["-c:v", "prores_ks", "-profile:v", "3", "-vendor", "apl0", "-color_primaries", "bt709", "-color_trc", "bt709", "-colorspace", "bt709"],
        outPath: videoPath
      },
      { signal }
    );
    const out = { videoPath, audioPath: null, path: videoPath, start: T - half, duration: half * 2, mid: half, name: meta.name };
    const src = sound ? this.#transitionSound(meta.file) : null;
    if (src) {
      progress(0.85, "Ses ekleniyor");
      out.path = `${base}.mov`;
      out.audioPath = `${base}.wav`;
      await muxTransitionSound(ffmpeg, { video: videoPath, sound: src, outMov: out.path, outWav: out.audioPath, offset: half - meta.anchor, duration: half * 2, volumeDb: Math.max(-40, Math.min(6, Number(volumeDb) || 0)) }, { signal });
    }
    progress(1, "Haz\u0131r");
    return out;
  }
  /** Vurgu zoom'u: seçili altyazılarda vurgu kelimesinde görüntü yakınlaşır (yeni sekans). */
  punchZoom({ source, segments, every = 2, scale = 112, name }) {
    if (!Array.isArray(segments) || !segments.length) throw badRequest("Altyaz\u0131 sat\u0131r\u0131 yok");
    const tl = this.#loadTimeline(source);
    const spans = punchSpans(segments, { every }).map(([s, e]) => [s * tl.fps, e * tl.fps]);
    if (!spans.length) throw badRequest("Yak\u0131nla\u015Facak vurgu bulunamad\u0131");
    const seqName = name ?? derivedName(tl.name, "Zoom");
    const count = punchZoom(tl, spans, { scale, name: seqName });
    const xmlPath = this.#outPath(seqName, ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, serializeTimeline(tl), "utf8");
    return { xmlPath, name: seqName, count };
  }
  // --- Renk eşleme ---
  /**
   * Referans görselin renklerine benzeyen bir LUT üretir. Kaynak: zaman çizelgesinin ilk görüntü
   * parçasından eşit aralıklı kareler. Önce/sonra önizlemesi de hazırlanır.
   */
  async colorMatch({ source, reference, strength = 1, protectSkin = true, name, camera = "rec709", highlights, exposure, contrast, saturation, temperature, look, lookStrength = 1, fx }, { signal, progress } = {}) {
    const prof = findProfile(camera);
    if (!prof) throw badRequest("Bilinmeyen kamera profili");
    const isLog = Boolean(prof.curve);
    if (reference && !(0, import_node_fs9.existsSync)(reference)) throw badRequest("Referans g\xF6rsel bulunamad\u0131");
    if (look && !findLook(look)) throw badRequest("Bilinmeyen g\xF6r\xFCn\xFCm");
    if (!reference && !look && !filmFxActive(fx) && !isLog && !exposure && !temperature && (contrast ?? 1) === 1 && (saturation ?? 1) === 1) throw badRequest("Bir referans g\xF6rsel, g\xF6r\xFCn\xFCm ya da log kamera profili se\xE7in");
    const stageFns = colorStages(camera, { highlights, exposure: exposure ?? 0, contrast: contrast ?? 1, saturation: saturation ?? 1, temperature: temperature ?? 0 });
    const pre = stageFns.length ? (r, g, b) => stageFns.reduce((v, st) => st.fn(v[0], v[1], v[2]), [r, g, b]) : void 0;
    const tl = this.#loadTimeline(source);
    const plan = timelinePlan(tl);
    const pieces = (plan.video.find((t) => t.some((p) => p.enabled !== false)) ?? []).filter((p) => p.enabled !== false && !/\.(png|jpe?g|gif|tiff?|psd)$/i.test(p.path));
    if (!pieces.length) throw badRequest("Zaman \xE7izelgesinde video klibi yok");
    const total = pieces[pieces.length - 1].end;
    const at = (t) => {
      const p = pieces.find((x) => t >= x.start && t < x.end) ?? pieces[0];
      return { path: p.path, time: p.srcIn + Math.max(0, Math.min(p.end - p.start - 0.05, t - p.start)) };
    };
    const N = 6;
    const frames = [];
    for (let i = 0; i < N; i++) {
      progress == null ? void 0 : progress(i / (N + 3), "Videonun renkleri \xF6l\xE7\xFCl\xFCyor");
      const f = at(total * (i + 0.5) / N);
      try {
        frames.push(await this.media.grabRgb(f.path, { time: f.time, signal }));
      } catch {
      }
    }
    if (!frames.length) throw badRequest("Videodan kare okunamad\u0131");
    progress == null ? void 0 : progress(N / (N + 3), "Referans \xF6l\xE7\xFCl\xFCyor");
    const refPixels = reference ? await this.media.grabRgb(reference, { width: 240, signal }).catch(() => {
      throw badRequest("Referans g\xF6rsel okunamad\u0131 (PNG, JPG ya da bir video karesi se\xE7in)");
    }) : null;
    const lutSize = isLog ? 65 : 33;
    const m2 = matchColors(Buffer.concat(frames), refPixels, { strength, protectSkin, pre, size: lutSize });
    const { match, matchColor, matchTone } = m2;
    const lookFn = look ? lookTransform(look, lookStrength) : null;
    const finalFn = lookFn ? (r, g, b) => lookFn(...m2.transform(r, g, b)) : m2.transform;
    const cube = lookFn ? buildCube(finalFn, { size: lutSize }) : m2.cube;
    const base = name ?? `${tl.name} - Renk`;
    const lutPath = this.#outPath(base, ".cube");
    (0, import_node_fs9.writeFileSync)(lutPath, cube, "utf8");
    if (match && lookFn) {
      stageFns.push({ id: "look-ref", label: "LOOK-REFERANS", match: ["LOOK 1", "LOOK"], fn: match });
    } else if (match) {
      stageFns.push({ id: "look-color", label: "LOOK-RENK", match: ["LOOK 1", "LOOK"], fn: matchColor });
      stageFns.push({ id: "look-tone", label: "LOOK-TON", match: ["LOOK 2", "LOOK"], fn: matchTone });
    }
    if (lookFn) stageFns.push({ id: "look-preset", label: "LOOK-HAZIR", match: match ? ["LOOK 2", "FILM LOOK", "LOOK"] : ["LOOK 1", "LOOK 2", "FILM LOOK", "LOOK"], fn: lookFn });
    const stages = stageFns.map((st, i) => {
      const path = lutPath.replace(/\.cube$/, `-${String(i + 1).padStart(2, "0")}-${st.label}.cube`);
      (0, import_node_fs9.writeFileSync)(path, buildCube(st.fn, { size: st.size ?? 33, title: `Makas ${st.label}` }), "utf8");
      return { id: st.id, label: st.label, match: st.match, path };
    });
    progress == null ? void 0 : progress((N + 1) / (N + 3), "\xD6nizleme haz\u0131rlan\u0131yor");
    const ffmpeg = this.tools.require("ffmpeg");
    const mid = at(total / 2);
    const id = (0, import_node_crypto5.randomUUID)().slice(0, 8);
    const out = (tag) => (0, import_node_path8.join)(this.config.dirs.cache, `renk-${id}-${tag}.jpg`);
    const lutCopy = (0, import_node_path8.join)(this.config.dirs.cache, `renk-${id}.cube`);
    (0, import_node_fs9.writeFileSync)(lutCopy, cube, "utf8");
    const grab = (vf, dest, input = mid.path, time = mid.time) => run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", ...time > 0 ? ["-ss", time.toFixed(3)] : [], "-i", input, "-frames:v", "1", "-update", "1", "-vf", vf, "-q:v", "3", dest], { cwd: this.config.dirs.cache, signal });
    await grab("scale=640:-2", out("once"));
    await grab(`scale=640:-2,lut3d=file=renk-${id}.cube`, out("sonra-temel"));
    if (filmFxActive(fx)) await this.#fxImage(out("sonra-temel"), out("sonra"), fx, signal);
    else (0, import_node_fs9.copyFileSync)(out("sonra-temel"), out("sonra"));
    if (reference) await grab("scale=640:-2", out("ref"), reference, 0);
    (0, import_node_fs9.rmSync)(lutCopy, { force: true });
    progress == null ? void 0 : progress(1, "Tamamland\u0131");
    return { lutPath, before: out("once"), after: out("sonra"), afterBase: out("sonra-temel"), reference: reference ? out("ref") : null, frames: frames.length, stages };
  }
  /** İlk görüntü parçasındaki video klipleri (görseller hariç). */
  #videoPieces(tl) {
    const plan = timelinePlan(tl);
    return (plan.video.find((t) => t.some((p) => p.enabled !== false)) ?? []).filter((p) => p.enabled !== false && !/\.(png|jpe?g|gif|tiff?|psd)$/i.test(p.path));
  }
  /**
   * Otomatik düzeltme önerisi: karelerden pozlama, sıcaklık ve kontrast değerleri hesaplar.
   * Değerler "Ayar" kaydırıcılarıyla aynı birimdedir (stop, -1…1, çarpan).
   */
  async colorAuto({ source, camera = "rec709", highlights }, { signal } = {}) {
    const prof = findProfile(camera);
    if (!prof) throw badRequest("Bilinmeyen kamera profili");
    const tl = this.#loadTimeline(source);
    const pieces = this.#videoPieces(tl);
    if (!pieces.length) throw badRequest("Zaman \xE7izelgesinde video klibi yok");
    const total = pieces[pieces.length - 1].end;
    const stages = colorStages(camera, { highlights });
    const toLin3 = (v) => v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
    const lum = [];
    let nr = 0;
    let nb = 0;
    let nn = 0;
    for (let i = 0; i < 6; i++) {
      const t = total * (i + 0.5) / 6;
      const p = pieces.find((x) => t >= x.start && t < x.end) ?? pieces[0];
      let buf;
      try {
        buf = await this.media.grabRgb(p.path, { time: p.srcIn + Math.max(0, Math.min(p.end - p.start - 0.05, t - p.start)), width: 96, signal });
      } catch {
        continue;
      }
      for (let k = 0; k + 2 < buf.length; k += 3) {
        const o = stages.reduce((v, st) => st.fn(v[0], v[1], v[2]), [buf[k] / 255, buf[k + 1] / 255, buf[k + 2] / 255]);
        const r = toLin3(o[0]);
        const g = toLin3(o[1]);
        const b = toLin3(o[2]);
        const y = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        lum.push(y);
        const mx = Math.max(r, g, b);
        const mn = Math.min(r, g, b);
        if (y > 0.04 && y < 0.7 && mx > 0 && (mx - mn) / mx < 0.28) {
          nr += r / y;
          nb += b / y;
          nn++;
        }
      }
    }
    if (lum.length < 500) throw badRequest("Videodan kare okunamad\u0131");
    lum.sort((a, b) => a - b);
    const q = (f) => lum[Math.min(lum.length - 1, Math.floor(f * lum.length))];
    const gam = (v) => v <= 31308e-7 ? v * 12.92 : 1.055 * v ** (1 / 2.4) - 0.055;
    const med = Math.max(4e-3, q(0.5));
    const exposure = Math.max(-1.5, Math.min(1.5, Math.log2(0.16 / med) * 0.6));
    let temperature = 0;
    if (nn > 200) {
      const R = nr / nn;
      const B = nb / nn;
      temperature = Math.max(-0.6, Math.min(0.6, (B - R) / (0.25 * (R + B)) * 0.5));
    }
    const spread = gam(Math.min(1, q(0.95) * 2 ** exposure)) - gam(Math.min(1, q(0.05) * 2 ** exposure));
    const contrast = Math.max(0.9, Math.min(1.35, 0.62 / Math.max(0.2, spread)));
    const round = (v, d) => Number((Math.round(v / d) * d).toFixed(2));
    return { exposure: round(exposure, 0.1), temperature: round(temperature, 0.05), contrast: round(contrast, 0.05), neutral: nn };
  }
  /**
   * Klipleri birbirine eşitler: referans klibin (oynatma kafasındaki ya da ilk klip) kaynak dosyasına
   * göre diğer her kaynak dosya için ayrı bir LUT üretir. Aynı dosyadan gelen tüm parçalar aynı LUT'u alır.
   */
  async colorMatchClips({ source, at = null, strength = 1, protectSkin = true, name }, { signal, progress }) {
    const tl = this.#loadTimeline(source);
    const pieces = this.#videoPieces(tl);
    if (!pieces.length) throw badRequest("Zaman \xE7izelgesinde video klibi yok");
    const byFile = /* @__PURE__ */ new Map();
    for (const p of pieces) (byFile.get(p.path) ?? byFile.set(p.path, []).get(p.path)).push(p);
    if (byFile.size < 2) throw badRequest("E\u015Fitlemek i\xE7in zaman \xE7izelgesinde en az iki farkl\u0131 kaynak video olmal\u0131 (\xF6r. iki kamera).");
    const refPiece = at != null && pieces.find((p) => at >= p.start && at < p.end) || pieces[0];
    const sample2 = async (list, n = 5) => {
      const bufs = [];
      const dur = list.reduce((t, p) => t + (p.end - p.start), 0);
      for (let i = 0; i < n; i++) {
        let t = dur * (i + 0.5) / n;
        const p = list.find((x) => t < x.end - x.start ? true : (t -= x.end - x.start, false)) ?? list[0];
        try {
          bufs.push(await this.media.grabRgb(p.path, { time: p.srcIn + Math.max(0, Math.min(p.end - p.start - 0.05, t)), signal }));
        } catch {
        }
      }
      if (!bufs.length) throw badRequest(`Kare okunamad\u0131: ${list[0].path}`);
      return Buffer.concat(bufs);
    };
    const ffmpeg = this.tools.require("ffmpeg");
    const id = (0, import_node_crypto5.randomUUID)().slice(0, 8);
    const thumb = async (p, tag, cube) => {
      const out = (0, import_node_path8.join)(this.config.dirs.cache, `esitle-${id}-${tag}.jpg`);
      const time = p.srcIn + (p.end - p.start) / 2;
      let vf = "scale=320:-2";
      if (cube) {
        (0, import_node_fs9.writeFileSync)((0, import_node_path8.join)(this.config.dirs.cache, `esitle-${id}.cube`), cube, "utf8");
        vf += `,lut3d=file=esitle-${id}.cube`;
      }
      await run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", ...time > 0 ? ["-ss", time.toFixed(3)] : [], "-i", p.path, "-frames:v", "1", "-update", "1", "-vf", vf, "-q:v", "4", out], { cwd: this.config.dirs.cache, signal });
      return out;
    };
    progress == null ? void 0 : progress(0.02, "Referans klip \xF6l\xE7\xFCl\xFCyor");
    const refPixels = await sample2(byFile.get(refPiece.path));
    const base = name ?? `${tl.name} - Esitle`;
    const others = [...byFile.entries()].filter(([f]) => f !== refPiece.path);
    const items = [];
    for (let i = 0; i < others.length; i++) {
      const [file, list] = others[i];
      progress == null ? void 0 : progress((i + 0.2) / others.length, `${i + 1}/${others.length}. kaynak e\u015Fitleniyor`);
      const { cube } = matchColors(await sample2(list), refPixels, { strength, protectSkin });
      const lutPath = this.#outPath(`${base} ${String(i + 1).padStart(2, "0")}`, ".cube");
      (0, import_node_fs9.writeFileSync)(lutPath, cube, "utf8");
      const mid = list[Math.floor(list.length / 2)];
      items.push({ file, name: file.split(/[\\/]/).pop(), clips: list.length, lutPath, before: await thumb(mid, `${i}-once`), after: await thumb(mid, `${i}-sonra`, cube) });
    }
    (0, import_node_fs9.rmSync)((0, import_node_path8.join)(this.config.dirs.cache, `esitle-${id}.cube`), { force: true });
    progress == null ? void 0 : progress(1, "Tamamland\u0131");
    return { reference: { file: refPiece.path, name: refPiece.path.split(/[\\/]/).pop(), thumb: await thumb(refPiece, "ref") }, items };
  }
  /** Bir JPG kareye film efektlerini uygular (önizleme). */
  async #fxImage(input, output, fx, signal) {
    const ffmpeg = this.tools.require("ffmpeg");
    const graph = filmFxGraph(fx, { width: 640, inp: "[0:v]", out: "[fx]" });
    await run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", input, "-filter_complex", graph, "-map", "[fx]", "-frames:v", "1", "-update", "1", "-q:v", "3", output], { signal });
    return output;
  }
  /** Film efektleri değişince "sonra" önizlemesini hızlıca yeniler (LUT'lu kare üzerinden). */
  async colorFxPreview({ image, fx }, { signal } = {}) {
    if (!image || !(0, import_node_fs9.existsSync)(image)) throw badRequest("\xD6nce rengi olu\u015Fturun");
    const out = (0, import_node_path8.join)(this.config.dirs.cache, `renk-fx-${(0, import_node_crypto5.randomUUID)().slice(0, 8)}.jpg`);
    if (filmFxActive(fx)) await this.#fxImage(image, out, fx, signal);
    else (0, import_node_fs9.copyFileSync)(image, out);
    return { path: out };
  }
  /**
   * Rengi ve film efektlerini videoya işler: ilk görüntü parçalarındaki her kaynak dosya LUT ve
   * efektlerle ProRes'e çevrilir, görüntü klipleri bu dosyalara bağlanmış yeni bir sekans kurulur.
   * Ses klipleri asıl dosyalarda kalır.
   */
  async colorRender({ source, lutPath, fx, name }, { signal, progress }) {
    var _a;
    const tl = this.#loadTimeline(source);
    const used = /* @__PURE__ */ new Map();
    for (const t of tl.video) {
      for (const it of t.items) {
        const f = it.kind === "clipitem" && it.fileId ? tl.files.get(it.fileId) : null;
        if (t.index !== 1 && tl.video.length > 1) continue;
        if ((f == null ? void 0 : f.path) && (0, import_node_fs9.existsSync)(f.path) && !/\.(png|jpe?g|gif|tiff?|psd)$/i.test(f.path)) used.set(f.path, f);
      }
    }
    if (!used.size) throw badRequest("\u0130\u015Flenecek video klibi yok");
    const ffmpeg = this.tools.require("ffmpeg");
    const work = (0, import_node_fs9.mkdtempSync)((0, import_node_path8.join)(this.config.dirs.cache, "renk-isle-"));
    const hasLut = lutPath && (0, import_node_fs9.existsSync)(lutPath);
    if (hasLut) (0, import_node_fs9.copyFileSync)(lutPath, (0, import_node_path8.join)(work, "renk.cube"));
    const seqName = name ?? derivedName(tl.name, "Renk");
    const replace = /* @__PURE__ */ new Map();
    const files = [...used.values()];
    try {
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        const secs = (f.duration || 1) / (((_a = f.rate) == null ? void 0 : _a.fps) || tl.fps || 25);
        const out = this.#outPath(`${seqName} ${String(i + 1).padStart(2, "0")}`, ".mov");
        const lut = hasLut ? `[0:v]lut3d=file=renk.cube[l];` : "";
        const graph = `${lut}${filmFxGraph(fx, { width: f.width || 1920, inp: hasLut ? "[l]" : "[0:v]", out: "[fx]" })}`;
        await run(
          ffmpeg,
          ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-progress", "pipe:2", "-i", f.path, "-filter_complex", graph, "-map", "[fx]", "-an", "-c:v", "prores_ks", "-profile:v", "2", "-pix_fmt", "yuv422p10le", "-vendor", "apl0", out],
          {
            cwd: work,
            signal,
            onStderrLine: (line) => {
              const m2 = /^out_time_us=(\d+)/.exec(line);
              if (m2) progress == null ? void 0 : progress((i + Math.min(1, Number(m2[1]) / 1e6 / secs)) / files.length, `${i + 1}/${files.length}. klip i\u015Fleniyor`);
            }
          }
        );
        replace.set(f.path, out);
      }
    } finally {
      (0, import_node_fs9.rmSync)(work, { recursive: true, force: true });
    }
    const count = relinkVideo(tl, replace);
    setSequenceName(tl, seqName);
    const xmlPath = this.#outPath(seqName, ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, serializeTimeline(tl), "utf8");
    progress == null ? void 0 : progress(1, "Tamamland\u0131");
    return { xmlPath, name: seqName, clips: count, files: files.length };
  }
  /**
   * Hazır görünümlerin videonuzdaki bir kare üzerindeki küçük önizlemeleri. Kamera log ise önce
   * Rec.709'a çevrilir. `image` verilirse kare yerine o görsel kullanılır.
   * @returns {{items:{id:string,label:string,desc:string,path:string}[]}}
   */
  async colorLooks({ source, image, camera = "rec709", highlights, at = 0.5 }, { signal } = {}) {
    let path = image;
    let time = 0;
    if (!path) {
      const tl = this.#loadTimeline(source);
      const plan = timelinePlan(tl);
      const pieces = (plan.video.find((t2) => t2.some((p2) => p2.enabled !== false)) ?? []).filter((p2) => p2.enabled !== false && !/\.(png|jpe?g|gif|tiff?|psd)$/i.test(p2.path));
      if (!pieces.length) throw badRequest("Zaman \xE7izelgesinde video klibi yok");
      const t = pieces[pieces.length - 1].end * Math.max(0, Math.min(0.98, at));
      const p = pieces.find((x) => t >= x.start && t < x.end) ?? pieces[0];
      path = p.path;
      time = p.srcIn + Math.max(0, Math.min(p.end - p.start - 0.05, t - p.start));
    }
    if (!path || !(0, import_node_fs9.existsSync)(path)) throw badRequest("\xD6nizleme i\xE7in kare bulunamad\u0131");
    const W = 320;
    const src = await this.media.grabRgb(path, { time, width: W, signal });
    const H = Math.floor(src.length / (W * 3));
    if (H < 2) throw badRequest("Kare okunamad\u0131");
    const stages = colorStages(camera, { highlights });
    const pre = (r, g, b) => stages.reduce((v, st) => st.fn(v[0], v[1], v[2]), [r, g, b]);
    const base = Buffer.alloc(W * H * 3);
    for (let i = 0; i < W * H * 3; i += 3) {
      const o = stages.length ? pre(src[i] / 255, src[i + 1] / 255, src[i + 2] / 255) : [src[i] / 255, src[i + 1] / 255, src[i + 2] / 255];
      base[i] = Math.round(o[0] * 255);
      base[i + 1] = Math.round(o[1] * 255);
      base[i + 2] = Math.round(o[2] * 255);
    }
    const ffmpeg = this.tools.require("ffmpeg");
    const id = (0, import_node_crypto5.randomUUID)().slice(0, 8);
    const encode = async (buf, tag) => {
      const raw = (0, import_node_path8.join)(this.config.dirs.cache, `gorunum-${id}-${tag}.rgb`);
      const out = (0, import_node_path8.join)(this.config.dirs.cache, `gorunum-${id}-${tag}.jpg`);
      (0, import_node_fs9.writeFileSync)(raw, buf);
      try {
        await run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", `${W}x${H}`, "-i", raw, "-frames:v", "1", "-update", "1", "-q:v", "3", out], { signal });
      } finally {
        (0, import_node_fs9.rmSync)(raw, { force: true });
      }
      return out;
    };
    const items = [{ id: "", label: "Orijinal", desc: stages.length ? "Yaln\u0131zca Rec.709 d\xF6n\xFC\u015F\xFCm\xFC" : "De\u011Fi\u015Fiklik yok", path: await encode(base, "orijinal") }];
    for (const lk of LOOKS) {
      const fn = lookTransform(lk.id, 1);
      const cache = /* @__PURE__ */ new Map();
      const buf = Buffer.alloc(base.length);
      for (let i = 0; i < base.length; i += 3) {
        const key = base[i] << 16 | base[i + 1] << 8 | base[i + 2];
        let v = cache.get(key);
        if (!v) {
          const o = fn(base[i] / 255, base[i + 1] / 255, base[i + 2] / 255);
          v = [Math.round(o[0] * 255), Math.round(o[1] * 255), Math.round(o[2] * 255)];
          cache.set(key, v);
        }
        buf[i] = v[0];
        buf[i + 1] = v[1];
        buf[i + 2] = v[2];
      }
      items.push({ id: lk.id, label: lk.label, desc: lk.desc, path: await encode(buf, lk.id) });
    }
    return { items, width: W, height: H };
  }
  // --- Ses ile eşitleme ---
  /**
   * Ayrı kayıtları (kamera sesleri, harici mikrofon) sese göre hizalar. Referans: ilk ses
   * parçasındaki ilk klip. Her kaynak dosyanın klipleri (görüntüsüyle birlikte) kaydırılır.
   */
  async syncTimeline({ source, name }, { signal, progress }) {
    var _a;
    const tl = this.#loadTimeline(source);
    const firsts = /* @__PURE__ */ new Map();
    for (const t of tl.audio) {
      for (const it of t.items) {
        if (it.kind === "clipitem" && it.fileId && ((_a = tl.files.get(it.fileId)) == null ? void 0 : _a.path) && !firsts.has(it.fileId)) firsts.set(it.fileId, it);
      }
    }
    if (firsts.size < 2) throw badRequest("E\u015Fitlemek i\xE7in en az iki ayr\u0131 kay\u0131t gerekli (\xF6r. iki kamera ya da kamera + harici mikrofon), her biri bir ses par\xE7as\u0131nda.");
    const [[refId, ref]] = firsts;
    const sec = (it, frames) => {
      var _a2;
      return frames / (((_a2 = it.rate) == null ? void 0 : _a2.fps) || tl.fps);
    };
    const envOf = (id) => this.media.fileEnvelope(tl.files.get(id).path, { windowSec: 0.01, signal });
    progress(0.02, `${tl.files.get(refId).name ?? "Referans"} dinleniyor`);
    const refEnv = await envOf(refId);
    const results = [];
    let k = 0;
    for (const [id, it] of firsts) {
      if (id === refId) continue;
      k++;
      progress(k / firsts.size, `${tl.files.get(id).name ?? "kay\u0131t"} e\u015Fitleniyor`);
      const r = findSyncOffset(refEnv, await envOf(id));
      const file = tl.files.get(id);
      if (r.confidence < 1.5) {
        results.push({ name: file.name, skipped: true, confidence: r.confidence });
        continue;
      }
      const want = ref.start / tl.fps - sec(ref, ref.in) + sec(it, it.in) + r.offset;
      const delta = Math.round((want - it.start / tl.fps) * tl.fps);
      shiftFile(tl, id, delta);
      results.push({ name: file.name, offset: Math.round(r.offset * 1e3) / 1e3, moved: delta / tl.fps, confidence: r.confidence });
    }
    const minStart = Math.min(...[...tl.video, ...tl.audio].flatMap((t) => t.items.filter((x) => x.kind === "clipitem").map((x) => x.start)));
    if (minStart < 0) for (const id of new Set([...tl.video, ...tl.audio].flatMap((t) => t.items.map((x) => x.fileId)).filter(Boolean))) shiftFile(tl, id, -minStart);
    const seqName = name ?? derivedName(tl.name, "E\u015Fitlendi");
    setSequenceName(tl, seqName);
    const xmlPath = this.#outPath(seqName, ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, serializeTimeline(tl), "utf8");
    progress(1, "Tamamland\u0131");
    return { xmlPath, name: seqName, reference: tl.files.get(refId).name, results };
  }
  // --- Müzik videosu ---
  /** Müziğin vuruşlarına göre klasördeki kliplerden yeni sekans kurar (her `every` vuruşta kesim). */
  async musicEdit({ music, folder, every = 2, name, vertical = false }, { signal, progress }) {
    if (!music || !(0, import_node_fs9.existsSync)(music)) throw badRequest("M\xFCzik dosyas\u0131 bulunamad\u0131");
    if (!folder || !(0, import_node_fs9.existsSync)(folder)) throw badRequest("Klip klas\xF6r\xFC bulunamad\u0131");
    const paths = (0, import_node_fs9.readdirSync)(folder).filter((f) => /\.(mp4|mov|m4v|mxf)$/i.test(f) && !f.startsWith(".")).sort((a, b) => a.localeCompare(b, "tr", { numeric: true })).map((f) => (0, import_node_path8.join)(folder, f));
    if (!paths.length) throw badRequest("Klas\xF6rde video yok (mp4, mov, m4v)");
    progress(0.05, "M\xFCzik dinleniyor");
    const mInfo = await this.media.probe(music);
    const env = await this.media.fileEnvelope(music, { windowSec: 0.01, signal });
    const { bpm, beats } = detectBeats(env);
    const clips = [];
    for (const [i, p] of paths.entries()) {
      progress(0.3 + i / paths.length * 0.6, `${(0, import_node_path8.basename)(p)} inceleniyor`);
      const m2 = await this.media.probe(p);
      if (m2.hasVideo && m2.duration > 0.5) clips.push({ id: `f${i + 1}`, path: p, name: (0, import_node_path8.basename)(p), duration: m2.duration, fps: m2.fps, width: m2.width, height: m2.height });
    }
    if (!clips.length) throw badRequest("Okunabilen video bulunamad\u0131");
    const cuts = beatCuts(beats, clips, { every: Math.max(1, Number(every) || 2), maxLength: mInfo.duration });
    if (!cuts.length) throw badRequest("M\xFCzikte vuru\u015F bulunamad\u0131");
    const fps = clips[0].fps || 25;
    const [W, H] = vertical ? [1080, 1920] : [1920, 1080];
    const total = Math.round(Math.min(mInfo.duration, cuts[cuts.length - 1].end) * fps);
    const seqName = name ?? `${(0, import_node_path8.basename)(music, (0, import_node_path8.extname)(music))} - M\xFCzik videosu`;
    const xml = buildSequenceFromClips({
      name: seqName,
      fps,
      width: W,
      height: H,
      fill: true,
      duration: total,
      files: [
        ...clips.map((c) => ({ id: c.id, path: c.path, name: c.name, fps: c.fps, frames: Math.round(c.duration * c.fps), width: c.width, height: c.height, hasVideo: true, audioChannels: 0 })),
        { id: "music", path: music, name: (0, import_node_path8.basename)(music), fps, frames: Math.round(mInfo.duration * fps), hasVideo: false, audioChannels: mInfo.audioChannels || 2 }
      ],
      video: [cuts.map((c) => ({ fileId: c.fileId, name: clips.find((x) => x.id === c.fileId).name, start: Math.round(c.start * fps), end: Math.round(c.end * fps), sourceIn: c.sourceIn }))],
      audio: [[{ fileId: "music", name: (0, import_node_path8.basename)(music), start: 0, end: total, sourceIn: 0 }]]
    });
    const xmlPath = this.#outPath(seqName, ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, xml, "utf8");
    progress(1, "Tamamland\u0131");
    return { xmlPath, name: seqName, bpm, cuts: cuts.length, clips: clips.length };
  }
  // --- B-roll ---
  /** Klasördeki görüntüleri konuşmadaki kelimelere göre üst parçaya yerleştirir (yeni sekans). */
  async placeBroll({ source, transcriptId, folder, clipLen = 2.5, minGap = 4, name }, { signal, progress }) {
    if (!folder || !(0, import_node_fs9.existsSync)(folder)) throw badRequest("B-roll klas\xF6r\xFC bulunamad\u0131");
    const t = this.getTranscript(transcriptId);
    const files = [];
    const walk = (dir, depth = 0) => {
      for (const e of (0, import_node_fs9.readdirSync)(dir, { withFileTypes: true })) {
        if (e.name.startsWith(".")) continue;
        const p = (0, import_node_path8.join)(dir, e.name);
        if (e.isDirectory() && depth < 4) walk(p, depth + 1);
        else if (/\.(mp4|mov|m4v|mxf)$/i.test(e.name)) files.push(p);
      }
    };
    walk(folder);
    if (!files.length) throw badRequest("Klas\xF6rde video bulunamad\u0131 (mp4, mov, m4v)");
    const rough = matchBroll(t.words ?? [], files.map((p) => ({ path: p, name: (0, import_node_path8.basename)(p), duration: 0 })), { clipLen, minGap });
    const needed = [...new Set(rough.map((r) => r.path))];
    const info = /* @__PURE__ */ new Map();
    for (const [i, p] of needed.entries()) {
      if (signal == null ? void 0 : signal.aborted) throw new Error("\u0130ptal edildi");
      progress(i / Math.max(1, needed.length), `${(0, import_node_path8.basename)(p)} inceleniyor`);
      info.set(p, await this.media.probe(p));
    }
    const placed = matchBroll(
      t.words ?? [],
      needed.filter((p) => {
        var _a;
        return (_a = info.get(p)) == null ? void 0 : _a.hasVideo;
      }).map((p) => ({ path: p, name: (0, import_node_path8.basename)(p), duration: info.get(p).duration })),
      { clipLen, minGap }
    );
    if (!placed.length) throw badRequest('Konu\u015Fmada B-roll dosya adlar\u0131yla e\u015Fle\u015Fen kelime bulunamad\u0131. Dosyalar\u0131 "kahve.mp4", "sahil g\xFCn bat\u0131m\u0131.mov" gibi adland\u0131r\u0131n.');
    const tl = this.#loadTimeline(source);
    addVideoClips(
      tl,
      placed.map((p) => {
        const m2 = info.get(p.path);
        return { ...p, fps: m2.fps, width: m2.width, height: m2.height, frames: Math.round(m2.duration * m2.fps) };
      })
    );
    const seqName = name ?? derivedName(tl.name, "B-roll");
    setSequenceName(tl, seqName);
    const xmlPath = this.#outPath(seqName, ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, serializeTimeline(tl), "utf8");
    progress(1, "Tamamland\u0131");
    return { xmlPath, name: seqName, placed: placed.map((p) => ({ name: p.name, word: p.word, start: p.start, duration: p.duration })), files: files.length };
  }
  // --- Ses iyileştirme ---
  /**
   * Konuşma sesini iyileştirir: düşük frekans uğultusu, arka plan gürültüsü, dinamik ve
   * YouTube ses seviyesi (-14 LUFS). Her kaynak dosya bir kez işlenir; yeni zaman çizelgesinde
   * ses klipleri işlenmiş dosyalara bağlanır, görüntü ve kesimler aynı kalır.
   */
  async enhanceAudio({ source, audioTracks = [], name, denoise = true, loudness = -14 }, { signal, progress }) {
    var _a;
    const ffmpeg = this.tools.require("ffmpeg");
    const tl = this.#loadTimeline(source);
    const tracks = audioTracks.map(Number);
    const paths = /* @__PURE__ */ new Set();
    for (const t of tl.audio) {
      if (tracks.length && !tracks.includes(t.index)) continue;
      for (const it of t.items) if (it.kind === "clipitem" && it.fileId && ((_a = tl.files.get(it.fileId)) == null ? void 0 : _a.path)) paths.add(tl.files.get(it.fileId).path);
    }
    if (!paths.size) throw badRequest("Se\xE7ili ses par\xE7alar\u0131nda klip yok");
    const filters = ["highpass=f=80", ...denoise ? ["afftdn=nf=-25"] : [], "acompressor=threshold=-20dB:ratio=3:attack=5:release=100:makeup=2", `loudnorm=I=${loudness}:TP=-1.5:LRA=11`];
    const replace = /* @__PURE__ */ new Map();
    let i = 0;
    for (const p of paths) {
      progress(i / paths.size, `${(0, import_node_path8.basename)(p)} iyile\u015Ftiriliyor`);
      const out = this.#outPath(`${(0, import_node_path8.basename)(p, (0, import_node_path8.extname)(p))}-ses`, ".wav");
      await run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", p, "-vn", "-af", filters.join(","), "-ar", "48000", "-c:a", "pcm_s24le", out], { signal });
      replace.set(p, out);
      i++;
    }
    const n = relinkAudio(tl, replace, tracks);
    const seqName = name ?? derivedName(tl.name, "Ses");
    setSequenceName(tl, seqName);
    const xmlPath = this.#outPath(seqName, ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, serializeTimeline(tl), "utf8");
    progress(1, "Tamamland\u0131");
    return { xmlPath, name: seqName, clips: n, files: paths.size };
  }
  // --- Shorts / bölümler ---
  findHighlights({ transcriptId, min = 20, max = 60, count = 5 }) {
    const t = this.getTranscript(transcriptId);
    return { items: findHighlights(t.words ?? [], { min, max, count }) };
  }
  buildChapters({ transcriptId }) {
    const t = this.getTranscript(transcriptId);
    const chapters = buildChapters(t.words ?? []);
    return { chapters, text: chaptersText(chapters) };
  }
  /** Sekansın [start, end] aralığından dikey (9:16) yeni sekans. */
  async verticalClip({ source, start, end, name, width = 1080, height = 1920, track = true }) {
    const tl = this.#loadTimeline(source);
    const keepFrames = [[Math.floor(start * tl.fps), Math.ceil(end * tl.fps)]];
    const seqName = name ?? `${derivedName(tl.name, "Short")}`;
    rippleKeep(tl, keepFrames, { name: seqName });
    makeVertical(tl, { width, height });
    const xml = serializeTimeline(tl);
    const xmlPath = this.#outPath(seqName, ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, xml, "utf8");
    const framing = [];
    if (track) {
      const plan = timelinePlan(readTimeline(xml));
      for (const pc of plan.video[0] ?? []) {
        try {
          const x = await this.media.motionCenter(pc.path, { start: pc.srcIn, duration: Math.min(20, pc.srcOut - pc.srcIn), srcWidth: pc.srcWidth || 1920, srcHeight: pc.srcHeight || 1080 });
          framing.push({ start: pc.start, x });
        } catch {
        }
      }
    }
    return { xmlPath, name: seqName, keep: keepFrames.map(([s, e]) => [s / tl.fps, e / tl.fps]), width, height, framing };
  }
  // --- MultiCam ---
  async analyzeMulticam(params, { signal, progress }) {
    const { source, speakers, wideVideoTrack = null, options = {} } = params;
    if (!Array.isArray(speakers) || speakers.length < 1) throw badRequest("En az bir konu\u015Fmac\u0131 tan\u0131mlay\u0131n");
    const tl = this.#loadTimeline(source);
    const duration = tl.duration / tl.fps;
    const window = 0.05;
    const prepared = [];
    for (const [i, sp] of speakers.entries()) {
      const sources = audioTrackSources(tl, Number(sp.audioTrack)).map(
        (s) => sp.channel === null || sp.channel === void 0 || sp.channel === "auto" ? s : { ...s, channel: Number(sp.channel) }
      );
      if (!sources.length) throw badRequest(`A${sp.audioTrack} par\xE7as\u0131nda ses klibi yok`);
      const env = await this.media.trackEnvelope(sources, duration, {
        windowSec: ENV_WINDOW,
        signal,
        onProgress: (p) => progress((i + p) / speakers.length * 0.95, `${sp.name ?? `Konu\u015Fmac\u0131 ${i + 1}`} analiz ediliyor`)
      });
      prepared.push({
        id: sp.name ?? `Konu\u015Fmac\u0131 ${i + 1}`,
        camera: String(sp.videoTrack),
        env: downsampleEnvelope(env, Math.round(window / ENV_WINDOW)),
        threshold: Number.isFinite(sp.threshold) ? sp.threshold : void 0
      });
    }
    const id = this.#remember("multicam", { source, speakers, wideVideoTrack, prepared, duration, fps: tl.fps });
    return { analysisId: id, ...this.recomputeMulticam(id, options) };
  }
  recomputeMulticam(analysisId, options = {}) {
    const a = this.#analysis(analysisId, "multicam");
    const plan = planMulticam(a.prepared, {
      ...cleanOptions(options),
      windowSec: 0.05,
      duration: a.duration,
      wideCamera: a.wideVideoTrack ? String(a.wideVideoTrack) : null
    });
    a.lastSegments = plan.segments;
    return { duration: a.duration, ...plan };
  }
  applyMulticam({ analysisId, segments, mode = "disable", name }) {
    const a = this.#analysis(analysisId, "multicam");
    const segs = segments ?? a.lastSegments;
    const tl = this.#loadTimeline(a.source);
    const cameraTracks = [.../* @__PURE__ */ new Set([...a.speakers.map((s) => Number(s.videoTrack)), ...a.wideVideoTrack ? [Number(a.wideVideoTrack)] : []])];
    const seqName = name ?? `${tl.name} - MultiCam`;
    const res = applyMulticam(
      tl,
      segs.map((s) => ({ start: Math.round(s.start * tl.fps), end: Math.round(s.end * tl.fps), camera: Number(s.camera) })),
      { cameraTracks, mode, name: seqName }
    );
    const xmlPath = this.#outPath(seqName, ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, serializeTimeline(tl), "utf8");
    return { xmlPath, name: seqName, cuts: res.cuts };
  }
  /** XML'deki zaman çizelgesinin API ile yeniden kurulacak planı (Resolve). */
  timelinePlan(xmlPath) {
    return timelinePlan(readTimeline((0, import_node_fs9.readFileSync)(xmlPath, "utf8")));
  }
  /** Klip listesinden sekans XML'i (Resolve JavaScript API'si FCP 7 XML vermediğinde). */
  sequenceFromClips(desc) {
    const xmlPath = this.#outPath((desc == null ? void 0 : desc.name) || "zaman-cizelgesi", ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, buildSequenceFromClips(desc), "utf8");
    return { xmlPath, name: desc == null ? void 0 : desc.name };
  }
  /** Tek dosyadan sekans XML'i (kurgu programına bağlı değilken). */
  async sequenceFromFile(path) {
    const info = await this.media.probe(path);
    const xmlPath = this.#outPath((0, import_node_path8.basename)(path, (0, import_node_path8.extname)(path)), ".xml");
    (0, import_node_fs9.writeFileSync)(xmlPath, buildSequenceFromMedia(info), "utf8");
    return { xmlPath };
  }
};
function cleanOptions(options) {
  const out = {};
  for (const [k, v] of Object.entries(options ?? {})) {
    if (v === null || v === void 0 || v === "") continue;
    out[k] = typeof v === "string" && /^-?\d+(\.\d+)?$/.test(v) ? Number(v) : v;
  }
  return out;
}

// engine/sfxlab.js
var import_node_crypto7 = require("crypto");
var import_node_zlib2 = require("zlib");
var import_node_fs10 = require("fs");
var import_node_path9 = require("path");

// core/s3.js
var import_node_crypto6 = require("crypto");
function sha256Hex(data) {
  return (0, import_node_crypto6.createHash)("sha256").update(data).digest("hex");
}
function hmac(key, data) {
  return (0, import_node_crypto6.createHmac)("sha256", key).update(data, "utf8").digest();
}
function encodeKey(key) {
  return key.split("/").map((part) => encodeURIComponent(part).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`)).join("/");
}
function amzDates(date) {
  const iso = date.toISOString().replace(/[:-]|\.\d{3}/g, "");
  return { amzDate: iso, dateStamp: iso.slice(0, 8) };
}
function signRequest(req) {
  const { method, accessKeyId, secretAccessKey, region = "auto", service = "s3" } = req;
  const url = new URL(req.url);
  const { amzDate, dateStamp } = amzDates(req.date ?? /* @__PURE__ */ new Date());
  const payloadHash = req.payloadHash ?? sha256Hex(req.body ?? "");
  const headers = { ...req.headers ?? {} };
  headers.host = url.host;
  headers["x-amz-date"] = amzDate;
  headers["x-amz-content-sha256"] = payloadHash;
  const lower = Object.fromEntries(Object.entries(headers).map(([k, v]) => [k.toLowerCase(), String(v).trim().replace(/\s+/g, " ")]));
  const signedHeaderNames = Object.keys(lower).sort();
  const canonicalHeaders = signedHeaderNames.map((k) => `${k}:${lower[k]}
`).join("");
  const signedHeaders = signedHeaderNames.join(";");
  const query = [...url.searchParams.entries()].map(([k, v]) => [encodeURIComponent(k), encodeURIComponent(v)]).sort(([a, av], [b, bv]) => a === b ? av < bv ? -1 : 1 : a < b ? -1 : 1).map(([k, v]) => `${k}=${v}`).join("&");
  const canonicalRequest = [method, url.pathname || "/", query, canonicalHeaders, signedHeaders, payloadHash].join("\n");
  const scope = `${dateStamp}/${region}/${service}/aws4_request`;
  const stringToSign = ["AWS4-HMAC-SHA256", amzDate, scope, sha256Hex(canonicalRequest)].join("\n");
  const kDate = hmac(`AWS4${secretAccessKey}`, dateStamp);
  const kRegion = hmac(kDate, region);
  const kService = hmac(kRegion, service);
  const kSigning = hmac(kService, "aws4_request");
  const signature = (0, import_node_crypto6.createHmac)("sha256", kSigning).update(stringToSign, "utf8").digest("hex");
  const out = { ...headers };
  delete out.host;
  out.Authorization = `AWS4-HMAC-SHA256 Credential=${accessKeyId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;
  return { headers: out, signature, canonicalRequest, stringToSign };
}
function objectUrl(endpoint, bucket, key) {
  return `${endpoint.replace(/\/+$/, "")}/${encodeURIComponent(bucket)}/${encodeKey(key)}`;
}

// engine/sfxlab.js
var BUILT_IN_CATALOG = true ? "https://makasai.net/sfx/catalog.json" : "";
var DEFAULT_CATEGORIES = [
  { id: "whoosh", name: "Whoosh & Ge\xE7i\u015F", icon: "wind", color: "#6EA8FF" },
  { id: "impact", name: "Vurgu & Darbe", icon: "zap", color: "#FF6B6B" },
  { id: "komik", name: "Komik", icon: "laugh", color: "#FFD43B" },
  { id: "pop", name: "Pop & Aray\xFCz", icon: "mouse-pointer-click", color: "#B197FC" },
  { id: "riser", name: "Riser & Gerilim", icon: "trending-up", color: "#FF922B" },
  { id: "glitch", name: "Glitch & Dijital", icon: "cpu", color: "#3BC9DB" },
  { id: "sosyal", name: "Sosyal Medya", icon: "bell", color: "#F06595" },
  { id: "ambiyans", name: "Ambiyans", icon: "cloud", color: "#69DB7C" },
  { id: "oyun", name: "Oyun & Retro", icon: "gamepad-2", color: "#A9E34B" },
  { id: "diger", name: "Di\u011Fer", icon: "music", color: "#ADB5BD" }
];
var AUDIO_TYPES = {
  ".wav": "audio/wav",
  ".mp3": "audio/mpeg",
  ".aif": "audio/aiff",
  ".aiff": "audio/aiff",
  ".flac": "audio/flac",
  ".ogg": "audio/ogg",
  ".m4a": "audio/mp4"
};
function slug2(text) {
  return foldText(text).replace(/\s+/g, "-").slice(0, 48) || "ses";
}
function emptyCatalog() {
  return { version: 1, name: "SFX Lab", updatedAt: null, categories: DEFAULT_CATEGORIES, sounds: [] };
}
function prettyName(file) {
  let n = (0, import_node_path9.basename)(file, (0, import_node_path9.extname)(file)).replace(/^ES_/i, "").replace(/epidemic ?sound/gi, " ").replace(/[_.]+/g, " ").replace(/([a-zğüşöçı])([A-ZĞÜŞÖÇİ])/g, "$1 $2").replace(/\s*[-–]\s*/g, " ").replace(/\(?\b(final|copy|kopya|edit|master|export|v\d+|new|yeni)\b\)?/gi, " ").replace(/^\s*\d+\s+/, "").replace(/\b(sfx|fx|se)\b/gi, " ").replace(/\s+/g, " ").trim();
  if (!n) n = (0, import_node_path9.basename)(file, (0, import_node_path9.extname)(file));
  n = n.split(" ").map((w) => /^\d+$/.test(w) ? w.padStart(2, "0") : w.charAt(0).toLocaleUpperCase("tr-TR") + w.slice(1).toLocaleLowerCase("tr-TR")).join(" ");
  return n;
}
var CATEGORY_HINTS = [
  ["oyun", /8 ?bit|retro|arcade|chiptune|pixel|video ?game|game ?over|oyun/i],
  ["whoosh", /whoosh|swoosh|swish|woosh|transition|gecis|geçiş|swipe|swoop|fly ?by|zoom/i],
  ["impact", /impact|hit|boom|punch|slam|thud|kick|bass ?drop|darbe|vurgu|braam|stomp/i],
  ["riser", /riser|rise|tension|build ?up|suspense|gerilim|uplifter|reverse/i],
  ["glitch", /glitch|digital|static|noise|error|bit ?crush|data|elektrik|tv|dijital/i],
  ["pop", /pop|click|tap|ui|button|bubble|blip|beep|tick|notification ?ui|mouse|klik|tık/i],
  ["sosyal", /bell|ding|notif|like|subscribe|bildirim|zil|camera ?shutter|cash|coin|ka-?ching|mesaj|message|tiktok|instagram/i],
  ["komik", /funny|comic|cartoon|laugh|boing|fail|bruh|vine|meme|komik|kahkaha|gülme|gulme|duck|squeak|honk|sad ?trombone|record ?scratch/i],
  ["ambiyans", /ambien|ambience|atmos|room ?tone|rain|wind|nature|city|crowd|forest|ocean|wave|yağmur|yagmur|rüzgar|ruzgar|doğa|doga|kalabalık/i]
];
function guessCategory(file) {
  const parts = String(file).split(/[\\/]/);
  const name = parts.pop() ?? "";
  const folder = parts.slice(-2).join(" ");
  for (const text of [name, folder]) for (const [id, re] of CATEGORY_HINTS) if (re.test(text)) return id;
  return "diger";
}
function uniqueName(base, used) {
  const key = (n) => n.toLocaleLowerCase("tr-TR");
  let name = base;
  for (let n = 2; used.has(key(name)); n++) name = `${base} ${n}`;
  used.add(key(name));
  return name;
}
var LICENSED_SOURCES = [
  ["Epidemic Sound", /epidemic ?sound|\bES_|^ES /i],
  ["Artlist", /artlist/i],
  ["Envato", /envato|audiojungle/i],
  ["Motion Array", /motion ?array/i],
  ["Pond5", /pond5/i],
  ["Soundsnap", /soundsnap/i],
  ["Storyblocks", /storyblocks|audioblocks/i],
  ["Soundstripe", /soundstripe/i],
  ["Musicbed", /musicbed/i],
  ["Boom Library", /boom ?library/i]
];
function licensedSource(path, content) {
  const head = content.subarray(0, 65536).toString("latin1");
  const tail2 = content.subarray(Math.max(0, content.length - 65536)).toString("latin1");
  for (const [name, re] of LICENSED_SOURCES) {
    if (re.test((0, import_node_path9.basename)(path)) || re.test(head) || re.test(tail2)) return name;
  }
  return null;
}
var fileId = (content) => (0, import_node_crypto7.createHash)("sha1").update(content).digest("hex").slice(0, 12);
function audioFilesIn(dir, out = [], depth = 0) {
  if (depth > 6) return out;
  for (const e of (0, import_node_fs10.readdirSync)(dir, { withFileTypes: true })) {
    if (e.name.startsWith(".") || e.name === "__MACOSX") continue;
    const full = (0, import_node_path9.join)(dir, e.name);
    if (e.isDirectory()) audioFilesIn(full, out, depth + 1);
    else if (AUDIO_TYPES[(0, import_node_path9.extname)(e.name).toLowerCase()]) out.push(full);
  }
  return out;
}
function peaksFromEnvelope(env, count = 48) {
  const out = [];
  const step = env.length / count;
  for (let i = 0; i < count; i++) {
    let max = -100;
    for (let j = Math.floor(i * step); j < Math.max(Math.floor((i + 1) * step), Math.floor(i * step) + 1) && j < env.length; j++) {
      if (env[j] > max) max = env[j];
    }
    out.push(Math.round(Math.max(0, Math.min(1, (max + 60) / 60)) * 100));
  }
  return out;
}
var SfxLab = class {
  constructor(config, tools, media) {
    this.config = config;
    this.tools = tools;
    this.media = media;
    this.dir = (0, import_node_path9.join)(config.dataDir, "sfx");
    this.filesDir = (0, import_node_path9.join)(this.dir, "files");
    (0, import_node_fs10.mkdirSync)(this.filesDir, { recursive: true });
    this.cachePath = (0, import_node_path9.join)(this.dir, "catalog.json");
    this.metaPath = (0, import_node_path9.join)(this.dir, "catalog-meta.json");
    this.cached = null;
  }
  catalogUrl() {
    return (this.config.settings.sfxCatalogUrl || BUILT_IN_CATALOG).trim();
  }
  #readCache() {
    if (this.cached) return this.cached;
    try {
      this.cached = JSON.parse((0, import_node_fs10.readFileSync)(this.cachePath, "utf8"));
    } catch {
      this.cached = null;
    }
    return this.cached;
  }
  #meta() {
    try {
      return JSON.parse((0, import_node_fs10.readFileSync)(this.metaPath, "utf8"));
    } catch {
      return {};
    }
  }
  /** Kataloğu getirir; ağ yoksa son kaydedilen kopya kullanılır. */
  async catalog({ refresh = false } = {}) {
    var _a, _b, _c;
    const url = this.catalogUrl();
    const meta = this.#meta();
    let error = null;
    let current = meta.url === url;
    const fresh = meta.fetchedAt && Date.now() - meta.fetchedAt < 10 * 60 * 1e3 && meta.url === url;
    if (url && (refresh || !fresh || !this.#readCache())) {
      try {
        const headers = meta.etag && meta.url === url && this.#readCache() ? { "If-None-Match": meta.etag } : {};
        const r = await requestJson(url, { headers, timeoutMs: 15e3 });
        if (r.status === 304) {
          (0, import_node_fs10.writeFileSync)(this.metaPath, JSON.stringify({ ...meta, fetchedAt: Date.now() }));
        } else if (r.status >= 200 && r.status < 300 && ((_a = r.data) == null ? void 0 : _a.sounds)) {
          this.cached = r.data;
          current = true;
          (0, import_node_fs10.writeFileSync)(this.cachePath, JSON.stringify(r.data));
          (0, import_node_fs10.writeFileSync)(this.metaPath, JSON.stringify({ url, etag: r.headers.etag ?? null, fetchedAt: Date.now() }));
        } else error = `Katalog al\u0131namad\u0131 (HTTP ${r.status})`;
      } catch (e) {
        error = `Katalog al\u0131namad\u0131: ${e.message}`;
      }
    }
    if (error && this.isAdmin()) {
      try {
        const direct = await this.#adminCatalog();
        error = ((_b = direct.sounds) == null ? void 0 : _b.length) ? `${error}. Sesler kovada var (${direct.sounds.length}) ama herkese a\xE7\u0131k adres okunam\u0131yor: Ayarlar'daki "K\xFCt\xFCphane adresi"ni ve kovada "Public Development URL"nin a\xE7\u0131k oldu\u011Funu kontrol edin.` : `${error}. Kovada hen\xFCz katalog yok: ilk sesi "Y\xFCkle" ile ekleyin.`;
        if ((_c = direct.sounds) == null ? void 0 : _c.length) return { configured: true, url, error, ...this.#decorate(direct) };
      } catch (e) {
        error = `${error}. Kovaya da ba\u011Flan\u0131lamad\u0131: ${e.message}`;
      }
    }
    const data = (current || !url ? this.#readCache() : null) ?? emptyCatalog();
    return { configured: Boolean(url), url, error, ...this.#decorate(data) };
  }
  /**
   * Kataloğu arayüz için hazırlar. Binlerce seste her aramada yeniden hesaplamamak için sonuç
   * katalog, adres ve favoriler değişene kadar saklanır; "indirildi mi" yalnızca gösterilen
   * sesler için diske sorulur.
   */
  #decorate(data) {
    var _a;
    const base = this.catalogUrl();
    const favKey = (this.config.settings.sfxFavorites ?? []).join(",");
    const memo = this.decorated;
    if (memo && memo.data === data && memo.base === base && memo.favKey === favKey) return memo.result;
    const resolveUrl = (p) => !p ? null : /^https?:\/\//.test(p) ? p : base ? new URL(p, base).toString() : null;
    const favs = new Set(this.config.settings.sfxFavorites ?? []);
    const categories = ((_a = data.categories) == null ? void 0 : _a.length) ? data.categories : DEFAULT_CATEGORIES;
    const counts = {};
    for (const s of data.sounds ?? []) counts[s.category] = (counts[s.category] ?? 0) + 1;
    const catNames = Object.fromEntries(categories.map((c) => [c.id, c.name]));
    const hay = /* @__PURE__ */ new Map();
    const result = {
      name: data.name ?? "SFX Lab",
      updatedAt: data.updatedAt ?? null,
      categories: categories.map((c) => ({ ...c, count: counts[c.id] ?? 0 })),
      sounds: (data.sounds ?? []).map((s) => {
        hay.set(s.id, tokenize(`${s.name} ${(s.tags ?? []).join(" ")} ${catNames[s.category] ?? ""}`));
        return { ...s, previewUrl: resolveUrl(s.preview), fileUrl: resolveUrl(s.file), favorite: favs.has(s.id), localPath: this.#localPath(s) };
      })
    };
    this.decorated = { data, base, favKey, result, hay };
    return result;
  }
  #localPath(s) {
    return (0, import_node_path9.join)(this.filesDir, s.category || "diger", `${slug2(s.name)}-${s.id}${(0, import_node_path9.extname)(s.file || ".wav") || ".wav"}`);
  }
  async search({ q = "", category = null, favoritesOnly = false, limit = 200, offset = 0 } = {}) {
    var _a;
    const cat = await this.catalog();
    const terms = tokenize(q);
    const hay = ((_a = this.decorated) == null ? void 0 : _a.result.sounds) === cat.sounds ? this.decorated.hay : null;
    const items = cat.sounds.filter((s) => {
      if (category && category !== "all" && s.category !== category) return false;
      if (favoritesOnly && !s.favorite) return false;
      if (!terms.length) return true;
      const h = (hay == null ? void 0 : hay.get(s.id)) ?? tokenize(`${s.name} ${(s.tags ?? []).join(" ")}`);
      return terms.every((t) => h.some((x) => x.startsWith(t)));
    });
    const page = items.slice(offset, offset + limit).map((s) => ({ ...s, downloaded: (0, import_node_fs10.existsSync)(s.localPath) }));
    return { total: items.length, items: page, categories: cat.categories, configured: cat.configured, error: cat.error };
  }
  /** Sesi yerel önbelleğe indirir (zaman çizelgesine eklemeden önce). */
  async download(id, { onProgress, signal } = {}) {
    const cat = await this.catalog();
    const s = cat.sounds.find((x) => x.id === id);
    if (!s) throw Object.assign(new Error("Ses bulunamad\u0131"), { status: 404 });
    if ((0, import_node_fs10.existsSync)(s.localPath)) return { path: s.localPath, sound: { ...s, downloaded: true } };
    if (!s.fileUrl) throw new Error("Ses adresi yok");
    (0, import_node_fs10.mkdirSync)((0, import_node_path9.join)(this.filesDir, s.category || "diger"), { recursive: true });
    await downloadFile(s.fileUrl, s.localPath, { onProgress, signal });
    return { path: s.localPath, sound: { ...s, downloaded: true } };
  }
  setFavorite(id, on) {
    const favs = new Set(this.config.settings.sfxFavorites ?? []);
    if (on) favs.add(id);
    else favs.delete(id);
    this.config.update({ sfxFavorites: [...favs] });
    return on;
  }
  // --- Yönetici ---
  adminSettings() {
    const a = this.config.settings.sfxAdmin ?? {};
    return { endpoint: "", bucket: "", accessKeyId: "", secretAccessKey: "", region: "auto", catalogKey: "catalog.json", ...a };
  }
  isAdmin() {
    const a = this.adminSettings();
    return Boolean(a.endpoint && a.bucket && a.accessKeyId && a.secretAccessKey);
  }
  async #s3(method, key, { body, contentType, cacheControl, contentEncoding } = {}) {
    var _a;
    const a = this.adminSettings();
    if (!this.isAdmin()) throw Object.assign(new Error("Y\xF6netici depolama bilgileri girilmemi\u015F"), { status: 412 });
    const url = objectUrl(a.endpoint, a.bucket, key);
    const headers = {};
    if (contentType) headers["content-type"] = contentType;
    if (cacheControl) headers["cache-control"] = cacheControl;
    if (contentEncoding) headers["content-encoding"] = contentEncoding;
    const payload = body == null ? null : Buffer.isBuffer(body) ? body : Buffer.from(body);
    const signed = signRequest({
      method,
      url,
      headers,
      payloadHash: sha256Hex(payload ?? ""),
      accessKeyId: a.accessKeyId,
      secretAccessKey: a.secretAccessKey,
      region: a.region || "auto"
    });
    const r = await request(url, { method, headers: signed.headers, body: payload, timeoutMs: 3e5 });
    if (r.status >= 300 && !(method === "GET" && r.status === 404) && !(method === "DELETE" && r.status === 404)) {
      const msg = ((_a = r.body.toString("utf8").match(/<Message>([^<]+)/)) == null ? void 0 : _a[1]) ?? `HTTP ${r.status}`;
      throw new Error(`Depolama hatas\u0131 (${method} ${key}): ${msg}`);
    }
    return r;
  }
  async #adminCatalog() {
    const a = this.adminSettings();
    const r = await this.#s3("GET", a.catalogKey);
    if (r.status === 404) return emptyCatalog();
    return JSON.parse(maybeGunzip(r.body).toString("utf8"));
  }
  async #adminSaveCatalog(data) {
    const a = this.adminSettings();
    data.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    await this.#s3("PUT", a.catalogKey, {
      body: (0, import_node_zlib2.gzipSync)(JSON.stringify(data)),
      contentType: "application/json; charset=utf-8",
      contentEncoding: "gzip",
      cacheControl: "public, max-age=60"
    });
    this.cached = null;
    return data;
  }
  /** Bağlantıyı dener ve yöneticiye kataloğun durumunu gösterir. */
  async adminTest() {
    var _a;
    const data = await this.#adminCatalog();
    return { ok: true, sounds: ((_a = data.sounds) == null ? void 0 : _a.length) ?? 0, categories: (data.categories ?? DEFAULT_CATEGORIES).length };
  }
  /**
   * Dosyaları işler (önizleme MP3 + dalga formu) ve buluta yükler.
   * @param {{files:string[], category:string, tags?:string[], normalize?:boolean}} params
   */
  /**
   * @param credit kaynak/lisans satırı (ör. "Oculus Audio Pack 1 · CC BY 4.0"); kullanıcının kaynakçasında görünür
   * @param optimize 48 kHz'den yüksek ya da WAV/MP3 dışı dosyaları 48 kHz / 24 bit WAV'a çevirir
   */
  async adminUpload({ files, category = "diger", tags = [], credit = "", optimize = true, concurrency = 4 }, { progress, signal } = {}) {
    var _a;
    if (!(files == null ? void 0 : files.length)) throw Object.assign(new Error("Dosya se\xE7ilmedi"), { status: 400 });
    const ffmpeg = this.tools.require("ffmpeg");
    const expanded = [];
    for (const f of files) {
      const p = typeof f === "string" ? f : f.path;
      if (/\.zip$/i.test(p)) {
        progress == null ? void 0 : progress(0, `${(0, import_node_path9.basename)(p)} a\xE7\u0131l\u0131yor`);
        for (const a of audioFilesIn(await this.#extractZip(p))) expanded.push(a);
      } else expanded.push(f);
    }
    files = expanded;
    const data = await this.#adminCatalog();
    data.categories = ((_a = data.categories) == null ? void 0 : _a.length) ? data.categories : DEFAULT_CATEGORIES;
    const existing = new Set(data.sounds.map((s) => s.id));
    const usedNames = new Set(data.sounds.map((s) => s.name.toLocaleLowerCase("tr-TR")));
    const added = [];
    const skipped = [];
    const tmpDir = (0, import_node_path9.join)(this.dir, "upload-tmp");
    (0, import_node_fs10.mkdirSync)(tmpDir, { recursive: true });
    const started = Date.now();
    let done = 0;
    let saving = Promise.resolve();
    const save = () => saving = saving.then(() => this.#adminSaveCatalog(data));
    const report = (msg) => {
      const frac = done / files.length;
      const elapsed = (Date.now() - started) / 1e3;
      const left = done > 3 ? Math.round(elapsed / done * (files.length - done)) : null;
      const eta = left == null ? "" : left > 3600 ? ` \xB7 ~${Math.round(left / 360) / 10} sa kald\u0131` : left > 60 ? ` \xB7 ~${Math.round(left / 60)} dk kald\u0131` : ` \xB7 ~${left} sn kald\u0131`;
      progress == null ? void 0 : progress(frac, `${done}/${files.length} \xB7 ${msg}${eta}`);
    };
    const one = async (item) => {
      var _a2;
      const file = typeof item === "string" ? item : item.path;
      let ext = (0, import_node_path9.extname)(file).toLowerCase();
      if (!AUDIO_TYPES[ext]) return skipped.push({ file, reason: "Desteklenmeyen bi\xE7im" });
      let content = (0, import_node_fs10.readFileSync)(file);
      const id = fileId(content);
      if (existing.has(id)) return skipped.push({ file, reason: "Zaten var" });
      existing.add(id);
      const name = uniqueName(((_a2 = item.name) == null ? void 0 : _a2.trim()) || prettyName(file), usedNames);
      const info = await this.media.probe(file);
      const env = await this.media.fileEnvelope(file, { windowSec: 0.01 });
      const previewPath = (0, import_node_path9.join)(tmpDir, `${id}.mp3`);
      await run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", file, "-vn", "-ac", "2", "-ar", "44100", "-b:a", "128k", previewPath], { signal });
      if (optimize && (![".wav", ".mp3"].includes(ext) || info.sampleRate > 48e3)) {
        const wavPath = (0, import_node_path9.join)(tmpDir, `${id}.wav`);
        await run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", file, "-vn", "-ar", String(Math.min(48e3, info.sampleRate || 48e3)), "-c:a", "pcm_s24le", wavPath], { signal });
        content = (0, import_node_fs10.readFileSync)(wavPath);
        (0, import_node_fs10.rmSync)(wavPath, { force: true });
        ext = ".wav";
      }
      const cat = item.category || (category === "auto" ? guessCategory(file) : category);
      const licensed = item.licensed ?? licensedSource(file, content);
      const fileKey = `sounds/${cat}/${slug2(name)}-${id}${ext}`;
      const previewKey = `previews/${id}.mp3`;
      await this.#s3("PUT", fileKey, { body: content, contentType: AUDIO_TYPES[ext], cacheControl: "public, max-age=31536000, immutable" });
      await this.#s3("PUT", previewKey, { body: (0, import_node_fs10.readFileSync)(previewPath), contentType: "audio/mpeg", cacheControl: "public, max-age=31536000, immutable" });
      (0, import_node_fs10.rmSync)(previewPath, { force: true });
      const entry = {
        id,
        name,
        category: cat,
        ...licensed ? { licensed } : {},
        ...credit ? { credit: String(credit).trim() } : {},
        tags: [.../* @__PURE__ */ new Set([...tags, ...tokenize(name).filter((t) => t.length > 2 && !/^\d+$/.test(t))])].slice(0, 12),
        duration: Math.round(info.duration * 1e3) / 1e3,
        file: fileKey,
        preview: previewKey,
        peaks: peaksFromEnvelope(env),
        size: content.length,
        addedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      data.sounds.push(entry);
      added.push(entry);
      if (added.length % 25 === 0) save();
      return null;
    };
    let next = 0;
    let failed = null;
    const worker = async () => {
      while (next < files.length && !failed) {
        if (signal == null ? void 0 : signal.aborted) throw new Error("\u0130ptal edildi");
        const item = files[next++];
        const file = typeof item === "string" ? item : item.path;
        try {
          await one(item);
        } catch (e) {
          if (signal == null ? void 0 : signal.aborted) throw e;
          skipped.push({ file, reason: "Hata" });
          if (/Depolama|bağlan|zaman aşımı|ECONN|ENOTFOUND/i.test(e.message) && skipped.filter((x) => x.reason === "Hata").length >= 5) failed = e;
        }
        done++;
        report((0, import_node_path9.basename)(file));
      }
    };
    try {
      await Promise.all(Array.from({ length: Math.max(1, Math.min(8, concurrency)) }, worker));
    } finally {
      if (added.length) await save();
    }
    if (failed) throw new Error(`Y\xFCkleme durdu (${added.length} ses eklendi, kald\u0131\u011F\u0131 yerden devam etmek i\xE7in yeniden ba\u015Flat\u0131n): ${failed.message}`);
    progress == null ? void 0 : progress(1, "Tamamland\u0131");
    return { added: added.length, skipped, total: data.sounds.length };
  }
  /**
   * Kesim yerleri için kısa sesler: kategoriden en çok `count` farklı, 0,2–1,6 sn'lik ses indirilir
   * ve ses seviyesi ayarlanmış (volumeDb) 48 kHz stereo WAV kopyaları döner.
   */
  async autoSounds({ category = "whoosh", count = 6, volumeDb = -10 } = {}) {
    const { items } = await this.search({ category, limit: 400 });
    let pool = items.filter((s) => s.duration >= 0.2 && s.duration <= 1.6);
    if (!pool.length) pool = (await this.search({ limit: 400 })).items.filter((s) => s.duration >= 0.2 && s.duration <= 1.2);
    if (!pool.length) throw Object.assign(new Error("SFX Lab'da k\u0131sa ses bulunamad\u0131 (0,2\u20131,6 sn). \xD6nce ses y\xFCkleyin."), { status: 412 });
    const step = Math.max(1, Math.floor(pool.length / count));
    const chosen = pool.filter((_, i) => i % step === 0).slice(0, count);
    const ffmpeg = this.tools.require("ffmpeg");
    const out = [];
    for (const s of chosen) {
      const { path } = await this.download(s.id);
      const leveled = (0, import_node_path9.join)(this.dir, "auto", `${s.id}${volumeDb}.wav`);
      if (!(0, import_node_fs10.existsSync)(leveled)) {
        (0, import_node_fs10.mkdirSync)((0, import_node_path9.join)(this.dir, "auto"), { recursive: true });
        await run(ffmpeg, ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-i", path, "-vn", "-af", `volume=${volumeDb}dB`, "-ar", "48000", "-ac", "2", "-c:a", "pcm_s24le", leveled]);
      }
      out.push({ path: leveled, name: s.name, duration: s.duration, credit: s.credit ?? null });
    }
    return out;
  }
  /** Yönetici: depoya dosya yazar (güncelleme yayını gibi SFX dışı içerikler için). */
  adminPut(key, body, opts = {}) {
    return this.#s3("PUT", key, { body, ...opts });
  }
  /** Herkese açık deponun kökü (katalog adresinin klasörü), yoksa null. */
  publicBase() {
    const url = this.catalogUrl();
    try {
      return url ? new URL(".", url).toString() : null;
    } catch {
      return null;
    }
  }
  /** Kullanıcılar için kaynakça: ses kaynağı/lisans satırları ve kaç seste geçtiği. */
  async credits() {
    const cat = await this.catalog();
    const counts = /* @__PURE__ */ new Map();
    for (const s of cat.sounds) if (s.credit) counts.set(s.credit, (counts.get(s.credit) ?? 0) + 1);
    return { items: [...counts.entries()].map(([credit, count]) => ({ credit, count })) };
  }
  /** Yüklenmiş seslerin adlarını düzeltir, "Diğer"dekileri adına göre kategoriye taşır. */
  async adminTidy() {
    const data = await this.#adminCatalog();
    let renamed = 0;
    let moved = 0;
    for (const s of data.sounds) {
      if (!s.licensed) {
        const src = licensedSource(s.name, Buffer.alloc(0));
        if (src) s.licensed = src;
      }
      const name = prettyName(`${s.name}${(0, import_node_path9.extname)(s.file || ".wav")}`);
      if (name && name !== s.name) {
        s.name = name;
        renamed++;
      }
      if (!s.category || s.category === "diger") {
        const cat = guessCategory(`${s.file ?? ""}/${s.name}`.replace(/^sounds\/diger\//, ""));
        if (cat !== "diger") {
          s.category = cat;
          moved++;
        }
      }
      s.tags = [.../* @__PURE__ */ new Set([...s.tags ?? [], ...tokenize(s.name).filter((t) => t.length > 2 && !/^\d+$/.test(t))])].slice(0, 12);
    }
    await this.#adminSaveCatalog(data);
    return { renamed, moved, total: data.sounds.length };
  }
  /** ZIP'i geçici klasöre açar (büyük arşivler için sistemin unzip/tar aracı). */
  async #extractZip(zip) {
    const dest = (0, import_node_path9.join)(this.dir, "zip-tmp", (0, import_node_crypto7.createHash)("sha1").update(zip).digest("hex").slice(0, 10));
    (0, import_node_fs10.rmSync)(dest, { recursive: true, force: true });
    (0, import_node_fs10.mkdirSync)(dest, { recursive: true });
    if (process.platform === "win32") await run("tar", ["-xf", zip, "-C", dest]);
    else await run("unzip", ["-q", "-o", zip, "-d", dest]);
    return dest;
  }
  /** Yükleme önizlemesi: klasördeki sesler, düzeltilmiş adları ve tahmini kategorileri. */
  async scanFolder(dir) {
    if (!dir || !(0, import_node_fs10.existsSync)(dir)) throw Object.assign(new Error("Klas\xF6r bulunamad\u0131"), { status: 400 });
    if (/\.zip$/i.test(dir)) dir = await this.#extractZip(dir);
    const data = await this.#adminCatalog();
    const inLibrary = new Set(data.sounds.map((s) => s.id));
    const used = new Set(data.sounds.map((s) => s.name.toLocaleLowerCase("tr-TR")));
    const seen = /* @__PURE__ */ new Map();
    const files = audioFilesIn(dir).map((path) => {
      const content = (0, import_node_fs10.readFileSync)(path);
      const id = fileId(content);
      const source = licensedSource(path, content);
      if (inLibrary.has(id)) return { path, name: prettyName(path), status: "library" };
      if (seen.has(id)) return { path, name: prettyName(path), status: "duplicate", sameAs: seen.get(id) };
      const name = uniqueName(prettyName(path), used);
      seen.set(id, name);
      return { path, id, name, category: guessCategory(path), status: "new", licensed: source };
    });
    return { files, new: files.filter((f) => f.status === "new").length, skipped: files.filter((f) => f.status !== "new").length, licensed: files.filter((f) => f.licensed).length };
  }
  async adminUpdate({ id, name, category, tags }) {
    const data = await this.#adminCatalog();
    const s = data.sounds.find((x) => x.id === id);
    if (!s) throw Object.assign(new Error("Ses bulunamad\u0131"), { status: 404 });
    if (name) s.name = name;
    if (category) s.category = category;
    if (Array.isArray(tags)) s.tags = tags;
    await this.#adminSaveCatalog(data);
    return s;
  }
  async adminDelete({ ids }) {
    const data = await this.#adminCatalog();
    const remove = data.sounds.filter((s) => ids.includes(s.id));
    for (const s of remove) {
      await this.#s3("DELETE", s.file);
      if (s.preview) await this.#s3("DELETE", s.preview);
    }
    data.sounds = data.sounds.filter((s) => !ids.includes(s.id));
    await this.#adminSaveCatalog(data);
    return { removed: remove.length, total: data.sounds.length };
  }
  async adminSaveCategories({ categories }) {
    const data = await this.#adminCatalog();
    data.categories = categories.map((c) => ({ id: slug2(c.id || c.name), name: c.name, icon: c.icon || "music", color: c.color || "#ADB5BD" }));
    await this.#adminSaveCatalog(data);
    return data.categories;
  }
};

// engine/updater.js
var import_node_fs11 = require("fs");
var import_node_path10 = require("path");

// engine/unzip.js
var import_node_zlib3 = require("zlib");
function readZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
    if (buf.readUInt32LE(i) === 101010256) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error("Ge\xE7ersiz ZIP dosyas\u0131");
  const count = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const entries = [];
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 33639248) throw new Error("Bozuk ZIP dizini");
    const method = buf.readUInt16LE(p + 10);
    const csize = buf.readUInt32LE(p + 20);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const madeBy = buf.readUInt16LE(p + 4) >> 8;
    const attrs = buf.readUInt32LE(p + 38);
    const local = buf.readUInt32LE(p + 42);
    const name = buf.toString("utf8", p + 46, p + 46 + nameLen);
    p += 46 + nameLen + extraLen + commentLen;
    if (buf.readUInt32LE(local) !== 67324752) throw new Error("Bozuk ZIP kayd\u0131");
    const start = local + 30 + buf.readUInt16LE(local + 26) + buf.readUInt16LE(local + 28);
    const raw = () => buf.subarray(start, start + csize);
    entries.push({
      name,
      dir: name.endsWith("/"),
      // Unix'te oluşturulmuşsa dosya izinleri (çalıştırılabilir betikler için)
      mode: madeBy === 3 ? attrs >>> 16 & 511 : null,
      data: () => {
        if (method === 0) return Buffer.from(raw());
        if (method === 8) return (0, import_node_zlib3.inflateRawSync)(raw());
        throw new Error(`Desteklenmeyen ZIP s\u0131k\u0131\u015Ft\u0131rmas\u0131: ${method}`);
      }
    });
  }
  return entries;
}

// engine/updater.js
var API2 = "https://api.github.com";
var ARTIFACT = "Makas";
var PRESERVE = /* @__PURE__ */ new Set(["WorkflowIntegration.node", ".debug"]);
var PACKAGE_DIR = { premiere: "dist/premiere/com.makas.panel/", resolve: "dist/resolve/Makas/" };
var Updater = class {
  /**
   * @param {import('./config.js').Config} config
   * @param {{installDir?:string, host?:'premiere'|'resolve', apiBase?:string, channelBase?:()=>string|null}} opts
   *   channelBase: herkese açık yayın kanalının adresi (…/updates/), yoksa null
   */
  constructor(config, { installDir, host, apiBase = API2, channelBase = () => null } = {}) {
    this.channelBase = channelBase;
    this.config = config;
    this.installDir = installDir && (0, import_node_fs11.existsSync)(installDir) ? installDir : null;
    this.host = host ?? null;
    this.apiBase = apiBase;
    this.latest = null;
  }
  current() {
    if (!this.installDir) return null;
    try {
      return JSON.parse((0, import_node_fs11.readFileSync)((0, import_node_path10.join)(this.installDir, "build.json"), "utf8"));
    } catch {
      return { version: null, sha: null, build: null };
    }
  }
  settings() {
    const s = this.config.settings.update ?? {};
    const cur = this.current();
    return { token: s.token ?? "", repo: s.repo || (cur == null ? void 0 : cur.repo) || "peassa/Eklenti", branch: s.branch || (cur == null ? void 0 : cur.branch) || "", lastCheck: s.lastCheck ?? null };
  }
  info() {
    const s = this.settings();
    return {
      enabled: Boolean(this.installDir && PACKAGE_DIR[this.host]),
      host: this.host,
      current: this.current(),
      repo: s.repo,
      branch: s.branch,
      hasToken: Boolean(s.token),
      channel: Boolean(this.channelBase()),
      lastCheck: s.lastCheck,
      latest: this.latest
    };
  }
  /** @param {'repo'|'actions'} scope hata mesajında hangi iznin eksik olduğunu söylemek için */
  async #api(path, scope = "actions") {
    const { token } = this.settings();
    if (!token) throw Object.assign(new Error("GitHub eri\u015Fim anahtar\u0131 girilmemi\u015F (Ayarlar > G\xFCncellemeler)"), { status: 412 });
    const r = await request(`${this.apiBase}${path}`, {
      headers: { Accept: "application/vnd.github+json", Authorization: `Bearer ${token}`, "X-GitHub-Api-Version": "2022-11-28" },
      timeoutMs: 2e4
    });
    let data = null;
    try {
      data = JSON.parse(r.body.toString("utf8"));
    } catch {
      data = null;
    }
    if (r.status === 401) throw new Error("GitHub eri\u015Fim anahtar\u0131 ge\xE7ersiz ya da s\xFCresi dolmu\u015F");
    if (r.status === 403 || r.status === 404) {
      const repo = this.settings().repo;
      throw new Error(
        scope === "repo" ? `Anahtar ${repo} deposunu g\xF6remiyor. GitHub'da anahtar\u0131 d\xFCzenleyin: Repository access > Only select repositories > ${repo}.` : `Anahtar\u0131n Actions izni yok. GitHub'da anahtar\u0131 d\xFCzenleyin: Permissions > Actions > Read-only.`
      );
    }
    if (r.status >= 400) throw new Error((data == null ? void 0 : data.message) ?? `GitHub hatas\u0131 (HTTP ${r.status})`);
    return data;
  }
  /** Yayın kanalındaki sürüm (anahtarsız). */
  async #checkChannel() {
    var _a, _b;
    const base = this.channelBase();
    let r;
    try {
      r = await requestJson(`${new URL("latest.json", base)}?t=${Date.now()}`, { timeoutMs: 15e3 });
    } catch (e) {
      throw new Error(`G\xFCncelleme sunucusuna ula\u015F\u0131lamad\u0131: ${e.message}`);
    }
    this.config.update({ update: { ...this.config.settings.update ?? {}, lastCheck: (/* @__PURE__ */ new Date()).toISOString() } });
    const cur = this.current();
    if (r.status === 404 || !((_a = r.data) == null ? void 0 : _a.sha) || !((_b = r.data) == null ? void 0 : _b.file)) {
      this.latest = null;
      return { available: false, current: cur, latest: null, channel: true };
    }
    if (r.status >= 400) throw new Error(`G\xFCncelleme sunucusu hata verdi (HTTP ${r.status})`);
    const d = r.data;
    if (!/^[\w.-]+\.zip$/.test(String(d.file))) throw new Error("G\xFCncelleme bilgisi ge\xE7ersiz");
    this.latest = { url: new URL(d.file, base).toString(), sha: String(d.sha), build: d.build ?? null, date: d.date ?? null, size: d.size ?? null, notes: String(d.notes ?? "").slice(0, 200), public: true };
    return { available: !(cur == null ? void 0 : cur.sha) || cur.sha !== this.latest.sha, current: cur, latest: this.latest, channel: true };
  }
  /** En yeni paketi bulur ve kuruluyla karşılaştırır (anahtar varsa GitHub, yoksa yayın kanalı). */
  async check() {
    var _a;
    const s = this.settings();
    if (!s.token && this.channelBase()) return this.#checkChannel();
    const branch = s.branch || (await this.#api(`/repos/${s.repo}`, "repo")).default_branch;
    const list = await this.#api(`/repos/${s.repo}/actions/artifacts?name=${ARTIFACT}&per_page=50`);
    const art = ((list == null ? void 0 : list.artifacts) ?? []).filter((a) => {
      var _a2;
      return !a.expired && a.name === ARTIFACT && ((_a2 = a.workflow_run) == null ? void 0 : _a2.head_branch) === branch;
    }).sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))[0];
    this.config.update({ update: { ...this.config.settings.update ?? {}, lastCheck: (/* @__PURE__ */ new Date()).toISOString() } });
    const cur = this.current();
    if (!art) {
      this.latest = null;
      return { available: false, current: cur, latest: null, branch };
    }
    let run2 = null;
    try {
      run2 = await this.#api(`/repos/${s.repo}/actions/runs/${art.workflow_run.id}`);
    } catch {
      run2 = null;
    }
    this.latest = {
      artifactId: art.id,
      url: art.archive_download_url,
      sha: art.workflow_run.head_sha,
      build: (run2 == null ? void 0 : run2.run_number) ?? null,
      date: art.created_at,
      size: art.size_in_bytes,
      notes: String(((_a = run2 == null ? void 0 : run2.head_commit) == null ? void 0 : _a.message) ?? "").split("\n")[0].slice(0, 200),
      branch
    };
    return { available: !(cur == null ? void 0 : cur.sha) || cur.sha !== this.latest.sha, current: cur, latest: this.latest, branch };
  }
  async #download(latest, signal) {
    const { token } = this.settings();
    const r = await request(latest.url, {
      headers: latest.public ? {} : { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" },
      signal,
      timeoutMs: 12e4
    });
    if (r.status !== 200) throw new Error(`Paket indirilemedi (HTTP ${r.status})`);
    return r.body;
  }
  /**
   * Yönetici: GitHub'daki en yeni paketi herkese açık yayın kanalına koyar. Önce paket, sonra
   * latest.json yazılır; böylece kullanıcılar hiçbir an eksik dosyaya yönlendirilmez.
   * @param {(key:string, body:Buffer, opts:{contentType:string, cacheControl:string})=>Promise<any>} put depoya yazma
   */
  async publish(put, { signal, progress } = {}) {
    if (!this.settings().token) throw Object.assign(new Error("Yay\u0131nlamak i\xE7in GitHub eri\u015Fim anahtar\u0131 gerekli (Ayarlar > G\xFCncellemeler)"), { status: 412 });
    progress == null ? void 0 : progress(0.05, "En yeni paket aran\u0131yor");
    const { latest } = await this.check();
    if (!latest || latest.public) throw new Error("GitHub'da yay\u0131nlanacak paket bulunamad\u0131");
    progress == null ? void 0 : progress(0.2, "Paket indiriliyor");
    const outer = readZip(await this.#download(latest, signal));
    const inner = outer.find((e) => !e.dir && e.name.endsWith(".zip"));
    if (!inner) throw new Error("Paket beklenen bi\xE7imde de\u011Fil");
    const body = inner.data();
    const version = readZip(body).filter((e) => e.name.endsWith("/build.json")).map((e) => JSON.parse(e.data().toString("utf8")))[0];
    if ((version == null ? void 0 : version.sha) !== latest.sha) throw new Error("Paketin i\xE7indeki s\xFCr\xFCm bilgisi beklenenle e\u015Fle\u015Fmiyor");
    const file = `makas-${latest.sha.slice(0, 12)}.zip`;
    progress == null ? void 0 : progress(0.5, "Paket y\xFCkleniyor");
    await put(`updates/${file}`, body, { contentType: "application/zip", cacheControl: "public, max-age=31536000, immutable" });
    progress == null ? void 0 : progress(0.9, "S\xFCr\xFCm duyuruluyor");
    const info = { sha: latest.sha, build: latest.build, version: version.version ?? null, date: latest.date, notes: latest.notes, size: body.length, file };
    await put("updates/latest.json", Buffer.from(JSON.stringify(info)), { contentType: "application/json; charset=utf-8", cacheControl: "public, max-age=60" });
    progress == null ? void 0 : progress(1, "Yay\u0131nland\u0131");
    return info;
  }
  /** En yeni paketi indirip çalışan eklentinin klasörünü yerinde günceller. */
  async install({ signal, progress } = {}) {
    if (!this.installDir || !PACKAGE_DIR[this.host]) throw new Error("G\xFCncelleme yaln\u0131zca Premiere ve Resolve eklentisinde kullan\u0131labilir");
    try {
      (0, import_node_fs11.accessSync)(this.installDir, import_node_fs11.constants.W_OK);
    } catch {
      throw new Error("Makas klas\xF6r\xFCne yazma izni yok. Kurulumu bir kez yeniden \xE7al\u0131\u015Ft\u0131r\u0131n; yeni kurulum uygulama i\xE7i g\xFCncellemeye izin verir.");
    }
    progress == null ? void 0 : progress(0.03, "Yeni s\xFCr\xFCm aran\u0131yor");
    const latest = this.latest ?? (await this.check()).latest;
    if (!latest) throw new Error("Bu dal i\xE7in indirilebilir paket bulunamad\u0131");
    progress == null ? void 0 : progress(0.1, "\u0130ndiriliyor");
    const body = await this.#download(latest, signal);
    progress == null ? void 0 : progress(0.6, "Paket a\xE7\u0131l\u0131yor");
    const outer = readZip(body);
    const innerEntry = outer.find((e) => !e.dir && e.name.endsWith(".zip"));
    const entries = innerEntry ? readZip(innerEntry.data()) : outer;
    const prefix = PACKAGE_DIR[this.host];
    const files = [];
    for (const e of entries) {
      if (e.dir) continue;
      const at = e.name.indexOf(prefix);
      if (at < 0) continue;
      const rel = e.name.slice(at + prefix.length);
      if (!rel || rel.split("/").some((p) => p === ".." || p === "") || rel.startsWith("/")) continue;
      files.push({ rel, entry: e });
    }
    if (!files.some((f) => f.rel === "build.json")) throw new Error("Paket bu eklenti i\xE7in dosya i\xE7ermiyor");
    if (latest.public) {
      const b = JSON.parse(files.find((f) => f.rel === "build.json").entry.data().toString("utf8"));
      if (b.sha !== latest.sha) throw new Error("\u0130ndirilen paket duyurulan s\xFCr\xFCmle e\u015Fle\u015Fmiyor; biraz sonra yeniden deneyin");
    }
    progress == null ? void 0 : progress(0.75, "Dosyalar g\xFCncelleniyor");
    const keep = new Set(files.map((f) => f.rel));
    for (const { rel, entry } of files) {
      const dest = (0, import_node_path10.join)(this.installDir, ...rel.split("/"));
      (0, import_node_fs11.mkdirSync)((0, import_node_path10.dirname)(dest), { recursive: true });
      const tmp = `${dest}.makas-yeni`;
      (0, import_node_fs11.writeFileSync)(tmp, entry.data());
      if (entry.mode) (0, import_node_fs11.chmodSync)(tmp, entry.mode);
      (0, import_node_fs11.renameSync)(tmp, dest);
    }
    removeStale(this.installDir, this.installDir, keep);
    progress == null ? void 0 : progress(1, "Tamamland\u0131");
    return { installed: { ...latest }, restart: true };
  }
};
function removeStale(root, dir, keep) {
  for (const e of (0, import_node_fs11.readdirSync)(dir, { withFileTypes: true })) {
    const full = (0, import_node_path10.join)(dir, e.name);
    const rel = (0, import_node_path10.relative)(root, full).split(import_node_path10.sep).join("/");
    if (e.isDirectory()) {
      removeStale(root, full, keep);
      try {
        if (!(0, import_node_fs11.readdirSync)(full).length) (0, import_node_fs11.rmdirSync)(full);
      } catch {
      }
    } else if (!keep.has(rel) && !PRESERVE.has(e.name)) {
      (0, import_node_fs11.rmSync)(full, { force: true });
    }
  }
}

// engine/license.js
var import_node_child_process2 = require("child_process");
var import_node_crypto8 = require("crypto");
var import_node_fs12 = require("fs");
var import_node_os5 = require("os");
var import_node_path11 = require("path");
var BUILT_IN = typeof define_MAKAS_LICENSE_default === "object" && define_MAKAS_LICENSE_default ? define_MAKAS_LICENSE_default : {};
var REFRESH_MS = 12 * 36e5;
var FREE_METHODS = /^(app\.|settings\.|license\.|update\.|jobs\.|models\.|fs\.|diagnostics\.|transcripts\.list$)/;
function spkiFromRaw(raw) {
  return (0, import_node_crypto8.createPublicKey)({ key: Buffer.concat([Buffer.from("302a300506032b6570032100", "hex"), raw]), format: "der", type: "spki" });
}
var fromB64url = (s) => Buffer.from(String(s).replace(/-/g, "+").replace(/_/g, "/"), "base64");
function readLicenseToken(token, publicKeyB64) {
  try {
    const [body, sig] = String(token).split(".");
    if (!body || !sig) return null;
    const ok = (0, import_node_crypto8.verify)(null, Buffer.from(body), spkiFromRaw(Buffer.from(publicKeyB64, "base64")), fromB64url(sig));
    return ok ? JSON.parse(fromB64url(body).toString("utf8")) : null;
  } catch {
    return null;
  }
}
var License = class {
  /**
   * @param {import('./config.js').Config} config
   * @param {{url?:string, publicKey?:string, now?:()=>number}} opts
   */
  constructor(config, { url = process.env.MAKAS_LICENSE_URL || BUILT_IN.url, publicKey = process.env.MAKAS_LICENSE_PUBKEY || BUILT_IN.publicKey, site = process.env.MAKAS_SITE_URL || BUILT_IN.site || "https://makasai.net", now = () => Date.now() } = {}) {
    this.config = config;
    this.url = url ? String(url).replace(/\/+$/, "") : "";
    this.publicKey = publicKey || "";
    this.site = String(site).replace(/\/+$/, "");
    this.now = now;
    this.path = (0, import_node_path11.join)(config.dataDir, "license.json");
    this.state = this.#load();
    this.refreshing = null;
  }
  get enabled() {
    return Boolean(this.url && this.publicKey);
  }
  #load() {
    try {
      if ((0, import_node_fs12.existsSync)(this.path)) return JSON.parse((0, import_node_fs12.readFileSync)(this.path, "utf8"));
    } catch {
    }
    return {};
  }
  #save() {
    (0, import_node_fs12.writeFileSync)(this.path, JSON.stringify(this.state, null, 2), { mode: 384 });
  }
  get deviceId() {
    if (!this.state.deviceId) {
      this.state.deviceId = (0, import_node_crypto8.randomUUID)();
      this.#save();
    }
    return this.state.deviceId;
  }
  /**
   * Bilgisayarın donanım kimliğinin özeti. Veri klasörü silinse de değişmez; sunucu bunu yalnızca
   * "bu bilgisayarda deneme kullanıldı mı" sorusu için tutar. Okunamazsa boş kalır.
   */
  #machine() {
    var _a, _b, _c;
    if (this.machine !== void 0) return this.machine;
    let raw = "";
    try {
      const run2 = (cmd, args) => (0, import_node_child_process2.execFileSync)(cmd, args, { encoding: "utf8", timeout: 4e3, windowsHide: true, stdio: ["ignore", "pipe", "ignore"] });
      if ((0, import_node_os5.platform)() === "darwin") raw = ((_a = /"IOPlatformUUID"\s*=\s*"([^"]+)"/.exec(run2("/usr/sbin/ioreg", ["-rd1", "-c", "IOPlatformExpertDevice"]))) == null ? void 0 : _a[1]) ?? "";
      else if ((0, import_node_os5.platform)() === "win32") raw = ((_b = /MachineGuid\s+REG_SZ\s+(\S+)/.exec(run2("reg", ["query", "HKLM\\SOFTWARE\\Microsoft\\Cryptography", "/v", "MachineGuid"]))) == null ? void 0 : _b[1]) ?? "";
      else raw = (0, import_node_fs12.readFileSync)("/etc/machine-id", "utf8").trim();
    } catch {
      raw = "";
    }
    if (!raw) {
      try {
        const macs = Object.values((0, import_node_os5.networkInterfaces)()).flat().filter((n) => n && !n.internal && n.mac && n.mac !== "00:00:00:00:00:00").map((n) => n.mac);
        const uniq = [...new Set(macs)].sort();
        if (uniq.length) raw = `yedek:${uniq.join(",")}:${((_c = (0, import_node_os5.cpus)()[0]) == null ? void 0 : _c.model) ?? ""}`;
      } catch {
        raw = "";
      }
    }
    this.machine = raw ? (0, import_node_crypto8.createHash)("sha256").update(`makas:${raw}`).digest("hex") : null;
    return this.machine;
  }
  #device() {
    const machine = this.#machine();
    return { name: (0, import_node_os5.hostname)().replace(/\.local$/, ""), platform: (0, import_node_os5.platform)(), ...machine ? { machine } : {} };
  }
  async #post(path, body) {
    var _a;
    let r;
    try {
      r = await requestJson(`${this.url}${path}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        timeoutMs: 2e4
      });
    } catch (e) {
      throw Object.assign(new Error("Lisans sunucusuna ba\u011Flan\u0131lamad\u0131. \u0130nternet ba\u011Flant\u0131n\u0131z\u0131 kontrol edin."), { status: 503, offline: true, cause: e });
    }
    if (r.status >= 400) {
      const err = new Error(((_a = r.data) == null ? void 0 : _a.error) || `Lisans sunucusu hata verdi (${r.status})`);
      err.status = r.status;
      err.data = r.data;
      throw err;
    }
    return r.data;
  }
  #accept(data) {
    const payload = readLicenseToken(data.license, this.publicKey);
    if (!payload || payload.device !== this.deviceId) throw Object.assign(new Error("Lisans do\u011Frulanamad\u0131"), { status: 502 });
    this.state.license = data.license;
    this.state.devices = data.devices ?? [];
    this.state.checkedAt = this.now();
    if (data.trialUsed) this.state.trialUsed = true;
    else if (payload.plan === "pro" || payload.plan === "trial" && payload.until > this.now()) delete this.state.trialUsed;
    this.#save();
  }
  /** Arayüz için durum. */
  status() {
    if (!this.enabled) return { enabled: false, valid: true, plan: "dev" };
    const t = this.now();
    const lic = this.state.license ? readLicenseToken(this.state.license, this.publicKey) : null;
    const base = { enabled: true, site: this.site, loggedIn: Boolean(this.state.session), email: this.state.email ?? (lic == null ? void 0 : lic.email) ?? null, devices: this.state.devices ?? [], deviceId: this.deviceId };
    if (this.state.pendingDevices) return { ...base, valid: false, plan: "none", reason: "device-limit", devices: this.state.pendingDevices };
    if (!lic || lic.device !== this.deviceId) return { ...base, valid: false, plan: "none", reason: this.state.session ? "refresh" : "login" };
    const offlineLeft = lic.offline - t;
    if (offlineLeft <= 0) return { ...base, valid: false, plan: lic.plan, reason: "offline" };
    const active = (lic.plan === "pro" || lic.plan === "trial") && lic.until > t;
    const daysLeft = Math.max(0, Math.ceil((lic.until - t) / 864e5));
    return { ...base, valid: active, plan: active ? lic.plan : "expired", until: lic.until, daysLeft, offlineDays: Math.ceil(offlineLeft / 864e5), reason: active ? null : "expired", ...!active && this.state.trialUsed ? { trialUsed: true } : {} };
  }
  /** Lisans yoksa ya da süresi geçtiyse hata fırlatır (ücretli işlemlerden önce). */
  async require() {
    if (!this.enabled) return;
    let st = this.status();
    if (!st.valid && this.state.session && st.reason !== "device-limit") {
      await this.refresh().catch(() => {
      });
      st = this.status();
    }
    if (st.valid) {
      if (this.now() - (this.state.checkedAt ?? 0) > REFRESH_MS) this.refresh().catch(() => {
      });
      return;
    }
    const msg = {
      login: "Makas\u2019\u0131 kullanmak i\xE7in giri\u015F yap\u0131n (Hesap).",
      refresh: "Lisans do\u011Frulanamad\u0131; internete ba\u011Flan\u0131p Hesap \u2192 Yenile\u2019ye bas\u0131n.",
      offline: "Makas 14 g\xFCnd\xFCr internete ba\u011Flanmad\u0131; lisans\u0131 yenilemek i\xE7in internete ba\u011Flan\u0131n.",
      expired: st.trialUsed ? "Bu bilgisayarda \xFCcretsiz deneme daha \xF6nce kullan\u0131ld\u0131. Devam etmek i\xE7in Hesap \u2192 Abone ol." : st.plan === "expired" ? "Deneme s\xFCreniz / aboneli\u011Finiz bitti. Devam etmek i\xE7in Hesap \u2192 Abone ol." : "Lisans ge\xE7ersiz.",
      "device-limit": "Bu hesap en fazla 2 cihazda kullan\u0131labilir; Hesap\u2019tan bir cihaz\u0131 \xE7\u0131kar\u0131n."
    }[st.reason] ?? "Lisans gerekli.";
    throw Object.assign(new Error(msg), { status: 402, code: "LICENSE" });
  }
  /** E-posta + şifreyle giriş (hesap sitede açılır). */
  async login(email, password) {
    var _a;
    const mail = String(email ?? "").trim().toLowerCase();
    try {
      const data = await this.#post("/auth/login", { email: mail, password: String(password ?? ""), deviceId: this.deviceId, device: this.#device() });
      this.state.email = mail;
      this.state.session = data.session;
      delete this.state.pendingDevices;
      this.#accept(data);
    } catch (e) {
      if (((_a = e.data) == null ? void 0 : _a.code) === "DEVICE_LIMIT") {
        this.state.email = mail;
        this.state.session = e.data.session;
        this.state.pendingDevices = e.data.devices;
        this.#save();
        return this.status();
      }
      throw e;
    }
    return this.status();
  }
  async start(email) {
    const data = await this.#post("/auth/start", { email });
    this.state.email = String(email).trim().toLowerCase();
    this.#save();
    return data;
  }
  async verify(code) {
    var _a;
    if (!this.state.email) throw Object.assign(new Error("\xD6nce e-posta adresinizi yaz\u0131n"), { status: 400 });
    try {
      const data = await this.#post("/auth/verify", { email: this.state.email, code, deviceId: this.deviceId, device: this.#device() });
      this.state.session = data.session;
      delete this.state.pendingDevices;
      this.#accept(data);
    } catch (e) {
      if (((_a = e.data) == null ? void 0 : _a.code) === "DEVICE_LIMIT") {
        this.state.session = e.data.session;
        this.state.pendingDevices = e.data.devices;
        this.#save();
        return this.status();
      }
      throw e;
    }
    return this.status();
  }
  async refresh() {
    if (!this.enabled || !this.state.session) return this.status();
    this.refreshing ??= this.#post("/license/refresh", { session: this.state.session, deviceId: this.deviceId, device: this.#device() }).then((data) => {
      delete this.state.pendingDevices;
      this.#accept(data);
    }).catch((e) => {
      var _a;
      if (((_a = e.data) == null ? void 0 : _a.code) === "DEVICE_LIMIT") {
        this.state.pendingDevices = e.data.devices;
        this.#save();
        return;
      }
      if (e.status === 401) {
        delete this.state.session;
        delete this.state.license;
        this.#save();
      }
      throw e;
    }).finally(() => {
      this.refreshing = null;
    });
    await this.refreshing;
    return this.status();
  }
  async removeDevice(deviceId) {
    const data = await this.#post("/devices/remove", { session: this.state.session, deviceId });
    if (deviceId === this.deviceId) return this.logout();
    this.state.devices = data.devices;
    this.#save();
    if (this.state.pendingDevices) return this.refresh();
    return this.status();
  }
  async logout() {
    const session = this.state.session;
    this.state = { deviceId: this.state.deviceId };
    this.#save();
    if (session) await this.#post("/auth/logout", { session }).catch(() => {
    });
    return this.status();
  }
  async checkoutUrl(period) {
    return this.#post("/checkout", { session: this.state.session, period });
  }
  async portalUrl() {
    return this.#post("/portal", { session: this.state.session });
  }
};

// engine/diagnostics.js
var import_node_fs13 = require("fs");
var import_node_os6 = require("os");
var import_node_path12 = require("path");
var MAX_EVENTS = 200;
var MAX_FILE = 512 * 1024;
var stamp2 = (d = /* @__PURE__ */ new Date()) => d.toISOString().replace("T", " ").slice(0, 19);
function tail(path, lines) {
  try {
    if (!(0, import_node_fs13.existsSync)(path)) return [];
    return (0, import_node_fs13.readFileSync)(path, "utf8").trimEnd().split("\n").slice(-lines);
  } catch {
    return [];
  }
}
var Diagnostics = class {
  constructor(config) {
    this.config = config;
    this.events = [];
    this.file = config.dataDir ? (0, import_node_path12.join)(config.dataDir, "makas.log") : null;
  }
  /** @param {'hata'|'bilgi'} kind */
  note(kind, text) {
    const line = `${stamp2()} [${kind}] ${String(text).replace(/\s+/g, " ").slice(0, 600)}`;
    this.events.push(line);
    if (this.events.length > MAX_EVENTS) this.events.shift();
    if (!this.file) return;
    try {
      if ((0, import_node_fs13.existsSync)(this.file) && (0, import_node_fs13.statSync)(this.file).size > MAX_FILE) (0, import_node_fs13.writeFileSync)(this.file, "");
      (0, import_node_fs13.appendFileSync)(this.file, `${line}
`);
    } catch {
    }
  }
  /** @param {{version:string, build?:object, host?:string, tools?:object, models?:string[], license?:object, sfx?:object}} info */
  report(info) {
    var _a, _b, _c, _d;
    const t = info.tools ?? {};
    const tool = (name) => {
      const x = t[name];
      if (!(x == null ? void 0 : x.ok)) return `${name}: YOK`;
      return `${name}: ${x.path} \xB7 ${x.version ?? "s\xFCr\xFCm bilinmiyor"}${name === "ffmpeg" ? ` \xB7 altyaz\u0131 \xE7izimi: ${x.subtitles ? "var" : "YOK"}` : ""}`;
    };
    const history = this.file ? tail(this.file, 80) : this.events.slice(-80);
    const out = [
      "=== Makas tan\u0131lama raporu ===",
      `Tarih: ${stamp2()}`,
      `Makas: ${info.version}${((_a = info.build) == null ? void 0 : _a.build) ? ` \xB7 yap\u0131 ${info.build.build}` : ""}${((_b = info.build) == null ? void 0 : _b.sha) ? ` \xB7 ${String(info.build.sha).slice(0, 7)}` : ""}`,
      `Program: ${info.host ?? "bilinmiyor"}`,
      `Sistem: ${(0, import_node_os6.platform)()} ${(0, import_node_os6.release)()} \xB7 ${(0, import_node_os6.arch)()} \xB7 Node ${process.versions.node}${process.versions.electron ? ` \xB7 Electron ${process.versions.electron}` : ""}`,
      "",
      "--- Bile\u015Fenler ---",
      tool("ffmpeg"),
      tool("ffprobe"),
      tool("whisper"),
      `Konu\u015Fma modelleri: ${(info.models ?? []).join(", ") || "YOK"}`,
      "",
      "--- Durum ---",
      `Lisans: ${((_c = info.license) == null ? void 0 : _c.enabled) ? `${info.license.plan}${info.license.valid ? "" : ` (ge\xE7ersiz: ${info.license.reason})`}` : "kapal\u0131 (geli\u015Ftirici s\xFCr\xFCm\xFC)"}`,
      `SFX Lab: ${((_d = info.sfx) == null ? void 0 : _d.configured) ? `ba\u011Fl\u0131${info.sfx.error ? ` \xB7 HATA: ${info.sfx.error}` : ` \xB7 ${info.sfx.count} ses`}` : "adres yok"}`,
      "",
      `--- Son kay\u0131tlar (${history.length}) ---`,
      ...history.length ? history : ["(kay\u0131t yok)"]
    ];
    const resolveLog = this.config.dataDir ? tail((0, import_node_path12.join)(this.config.dataDir, "makas-resolve.log"), 60) : [];
    if (resolveLog.length) out.push("", `--- Resolve g\xFCnl\xFC\u011F\xFC (son ${resolveLog.length} sat\u0131r) ---`, ...resolveLog);
    return out.join("\n").split((0, import_node_os6.homedir)()).join("~");
  }
  save(text) {
    const d = /* @__PURE__ */ new Date();
    const name = `Makas-rapor-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}-${String(d.getHours()).padStart(2, "0")}${String(d.getMinutes()).padStart(2, "0")}.txt`;
    const desktop = (0, import_node_path12.join)((0, import_node_os6.homedir)(), "Desktop");
    const path = (0, import_node_path12.join)((0, import_node_fs13.existsSync)(desktop) ? desktop : this.config.dataDir, name);
    (0, import_node_fs13.writeFileSync)(path, text, "utf8");
    return path;
  }
};

// engine/toolinstall.js
var import_node_fs14 = require("fs");
var import_node_os7 = require("os");
var import_node_path13 = require("path");
var TOOLS_BASE = (process.env.MAKAS_TOOLS_BASE || "https://makasai.net/tools").replace(/\/+$/, "");
var RIEDL = "https://ffmpeg.martin-riedl.de/redirect/latest/macos";
function toolPlan(os = (0, import_node_os7.platform)(), cpu = (0, import_node_os7.arch)()) {
  if (os === "darwin") {
    const a = cpu === "arm64" ? "arm64" : "amd64";
    return [
      { id: "ffmpeg", title: "ffmpeg (ses ve video i\u015Fleme)", url: `${RIEDL}/${a}/release/ffmpeg.zip`, kind: "zip", files: ["ffmpeg"], needs: ["ffmpeg"] },
      { id: "ffprobe", title: "ffprobe (dosya inceleme)", url: `${RIEDL}/${a}/release/ffprobe.zip`, kind: "zip", files: ["ffprobe"], needs: ["ffprobe"] },
      { id: "whisper", title: "Konu\u015Fma tan\u0131ma program\u0131", url: `${TOOLS_BASE}/mac/whisper-cli`, kind: "file", files: ["whisper-cli"], needs: ["whisper"] }
    ];
  }
  if (os === "win32") {
    return [
      { id: "ffmpeg", title: "ffmpeg ve ffprobe (ses ve video i\u015Fleme)", url: "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip", kind: "zip", files: ["ffmpeg.exe", "ffprobe.exe"], needs: ["ffmpeg", "ffprobe"] },
      { id: "whisper", title: "Konu\u015Fma tan\u0131ma program\u0131", url: "https://github.com/ggml-org/whisper.cpp/releases/latest/download/whisper-bin-x64.zip", kind: "zip", files: "siblings:whisper-cli.exe", needs: ["whisper"] }
    ];
  }
  return [];
}
function pickFromZip(buf, files) {
  const entries = readZip(buf).filter((e) => !e.dir);
  if (typeof files === "string" && files.startsWith("siblings:")) {
    const target = files.slice("siblings:".length).toLowerCase();
    const hit = entries.find((e) => (0, import_node_path13.basename)(e.name).toLowerCase() === target);
    if (!hit) throw new Error(`${files.slice(9)} ar\u015Fivde bulunamad\u0131`);
    const dir = (0, import_node_path13.dirname)(hit.name);
    return entries.filter((e) => (0, import_node_path13.dirname)(e.name) === dir).map((e) => ({ name: (0, import_node_path13.basename)(e.name), data: e.data() }));
  }
  return files.map((f) => {
    const hit = entries.find((e) => (0, import_node_path13.basename)(e.name).toLowerCase() === f.toLowerCase());
    if (!hit) throw new Error(`${f} ar\u015Fivde bulunamad\u0131`);
    return { name: (0, import_node_path13.basename)(hit.name), data: hit.data() };
  });
}
async function installTools({ tools, config, force = false, plan = toolPlan() }, { progress = () => {
}, signal } = {}) {
  var _a, _b, _c;
  if (!plan.length) throw Object.assign(new Error("Bu i\u015Fletim sisteminde bile\u015Fenler kendili\u011Finden kurulam\u0131yor. ffmpeg ve whisper.cpp programlar\u0131n\u0131 kendiniz kurup yollar\u0131n\u0131 Ayarlar\u2019dan g\xF6sterin."), { status: 400 });
  const bin = (0, import_node_path13.join)(config.dirs.tools, "bin");
  (0, import_node_fs14.mkdirSync)(bin, { recursive: true });
  const st = await tools.status().catch(() => ({}));
  const have = { ffmpeg: Boolean(((_a = st.ffmpeg) == null ? void 0 : _a.ok) && st.ffmpeg.subtitles !== false), ffprobe: Boolean((_b = st.ffprobe) == null ? void 0 : _b.ok), whisper: Boolean((_c = st.whisper) == null ? void 0 : _c.ok) };
  const todo = plan.filter((s) => force || s.needs.some((n) => !have[n]));
  const out = { installed: [], skipped: plan.filter((s) => !todo.includes(s)).map((s) => s.id), failed: [] };
  for (let i = 0; i < todo.length; i++) {
    const step = todo[i];
    const at = (frac) => (i + frac) / todo.length;
    const tmp = (0, import_node_path13.join)(bin, `.indir-${step.id}`);
    try {
      progress(at(0), `${step.title} indiriliyor`);
      await downloadFile(step.url, tmp, { signal, timeoutMs: 18e4, onProgress: (ratio) => progress(at(ratio * 0.9), `${step.title} indiriliyor (%${Math.round(ratio * 100)})`) });
      progress(at(0.92), `${step.title} kuruluyor`);
      const picked = step.kind === "zip" ? pickFromZip((0, import_node_fs14.readFileSync)(tmp), step.files) : [{ name: step.files[0], data: (0, import_node_fs14.readFileSync)(tmp) }];
      for (const f of picked) {
        if (/^(ffmpeg|ffprobe|whisper-cli)(\.exe)?$/i.test(f.name) && f.data.length < 2e5) throw new Error(`${f.name} indirilemedi (dosya \xE7ok k\xFC\xE7\xFCk)`);
        const dest = (0, import_node_path13.join)(bin, f.name);
        const part = `${dest}.yeni`;
        (0, import_node_fs14.writeFileSync)(part, f.data);
        if ((0, import_node_os7.platform)() !== "win32") (0, import_node_fs14.chmodSync)(part, 493);
        (0, import_node_fs14.rmSync)(dest, { force: true });
        (0, import_node_fs14.renameSync)(part, dest);
      }
      out.installed.push(step.id);
    } catch (e) {
      if (signal == null ? void 0 : signal.aborted) throw e;
      out.failed.push({ id: step.id, error: e.message });
    } finally {
      (0, import_node_fs14.rmSync)(tmp, { force: true });
    }
  }
  tools.cache = {};
  progress(1, out.failed.length ? "Baz\u0131 bile\u015Fenler kurulamad\u0131" : "Bile\u015Fenler haz\u0131r");
  if (out.failed.length && !out.installed.length) {
    throw Object.assign(new Error(`Bile\u015Fenler indirilemedi: ${out.failed.map((f) => `${f.id} (${f.error})`).join("; ")}. \u0130nternet ba\u011Flant\u0131n\u0131z\u0131 denetleyip yeniden deneyin.`), { status: 502 });
  }
  return out;
}

// engine/service.js
function createService({ dataDir, port, fontsDir, installDir, host } = {}) {
  var _a;
  const config = new Config(dataDir);
  if (port) config.settings.port = port;
  config.fontsDir = fontsDir && (0, import_node_fs15.existsSync)(fontsDir) ? fontsDir : null;
  const tools = new Tools(config);
  const media = new Media(tools, config);
  const whisper = new Whisper(tools, config);
  const diag = new Diagnostics(config);
  const jobs = new JobManager({ onError: (type, message) => diag.note("hata", `i\u015F ${type}: ${message}`) });
  const library = new Library(config);
  const freesound = new Freesound(config, library);
  const bridge = new Bridge();
  const flows = new Workflows({ config, tools, media, whisper });
  const sfx = new SfxLab(config, tools, media);
  flows.sfx = sfx;
  const updater = new Updater(config, {
    installDir,
    host,
    apiBase: process.env.MAKAS_UPDATE_API || void 0,
    // Yayın kanalı SFX Lab deposunun yanında durur: …/updates/latest.json
    channelBase: () => sfx.publicBase() ? new URL("updates/", sfx.publicBase()).toString() : null
  });
  const license = new License(config);
  const job = (type, fn, meta) => jobs.start(type, fn, meta);
  const methods = {
    // Uygulama
    "app.status": async () => ({
      app: APP_NAME,
      version: APP_VERSION,
      platform: (0, import_node_os8.platform)(),
      tools: await tools.status(),
      models: whisper.listModels().filter((m2) => m2.installed).map((m2) => m2.id),
      dataDir: config.dataDir,
      sfxConfigured: Boolean(sfx.catalogUrl()),
      sfxAdmin: sfx.isAdmin(),
      license: license.status()
    }),
    // Eksik programları (ffmpeg, ffprobe, konuşma tanıma) Makas'ın kendi klasörüne indirir
    "app.installTools": ({ force = false } = {}) => job("tools-install", (ctx) => installTools({ tools, config, force }, ctx)),
    "settings.get": () => config.publicSettings(),
    "settings.update": (patch) => {
      var _a2;
      const p = { ...patch };
      if (typeof p.freesoundToken === "string" && p.freesoundToken.startsWith("\u2022\u2022\u2022\u2022")) delete p.freesoundToken;
      if (p.update) {
        const prev = config.settings.update ?? {};
        p.update = { ...prev, ...p.update };
        if (typeof p.update.token === "string" && p.update.token.startsWith("\u2022\u2022\u2022\u2022")) p.update.token = prev.token ?? "";
      }
      if (p.sfxAdmin && typeof p.sfxAdmin.secretAccessKey === "string" && p.sfxAdmin.secretAccessKey.startsWith("\u2022\u2022\u2022\u2022")) {
        p.sfxAdmin = { ...p.sfxAdmin, secretAccessKey: ((_a2 = config.settings.sfxAdmin) == null ? void 0 : _a2.secretAccessKey) ?? "" };
      }
      config.update(p);
      tools.cache = {};
      return config.publicSettings();
    },
    "app.presets": () => ({
      captions: CAPTION_PRESETS,
      styles: ASS_STYLES,
      codecs: Object.fromEntries(Object.entries(OVERLAY_CODECS).map(([k, v]) => [k, v.label])),
      libraryKinds: Object.fromEntries(Object.entries(KINDS).map(([k, v]) => [k, v.label])),
      fillerKinds: FILLER_KINDS,
      models: MODEL_CATALOG
    }),
    // Modeller
    "models.list": () => whisper.listModels(),
    "models.download": ({ id }) => {
      const running = jobs.list().find((j) => j.type === "model-download" && j.meta.model === id && (j.status === "running" || j.status === "queued"));
      return running ?? job("model-download", ({ signal, progress }) => whisper.download(id, { signal, onProgress: progressReporter(progress) }), { model: id });
    },
    "models.import": ({ path }) => ({ path: whisper.importModel(path) }),
    // Kaynak
    "source.inspect": ({ source }) => flows.inspect(source),
    "source.fromFile": ({ path }) => flows.sequenceFromFile(path),
    "source.fromClips": (desc) => flows.sequenceFromClips(desc),
    "source.timelinePlan": ({ xmlPath }) => flows.timelinePlan(xmlPath),
    // Transkript ve altyazı
    transcribe: (params) => job("transcribe", (ctx) => flows.transcribe(params, ctx), { source: params.source }),
    "transcripts.list": () => flows.listTranscripts(),
    "transcripts.get": ({ id }) => flows.getTranscript(id),
    "transcripts.updateWords": ({ id, words }) => flows.updateTranscriptWords(id, words),
    "transcripts.remap": ({ id, keep }) => flows.remapTranscript(id, keep),
    "captions.build": (params) => ({ segments: flows.buildCaptions(params) }),
    "captions.export": (params) => flows.exportCaptions(params),
    "captions.render": (params) => job("render-captions", (ctx) => flows.renderCaptions(params, ctx)),
    // Sessizlik ve dolgu sesleri
    "silence.analyze": (params) => job("silence", (ctx) => flows.analyzeSilence(params, ctx)),
    "silence.recompute": ({ analysisId, options }) => flows.recomputeSilence(analysisId, options),
    "silence.apply": (params) => flows.applySilence(params),
    "fillers.detect": (params) => flows.detectFillers(params),
    "edit.apply": (params) => flows.applyEdit(params),
    "audio.enhance": (params) => job("audio-enhance", (ctx) => flows.enhanceAudio(params, ctx)),
    "audio.snippet": (params) => flows.audioSnippet(params),
    // MultiCam
    "clips.highlights": (params) => flows.findHighlights(params),
    "clips.chapters": (params) => flows.buildChapters(params),
    "clips.vertical": (params) => flows.verticalClip(params),
    "sync.timeline": (params) => job("sync", (ctx) => flows.syncTimeline(params, ctx)),
    "music.edit": (params) => job("music-edit", (ctx) => flows.musicEdit(params, ctx)),
    "effects.kineticPreview": (params) => flows.kineticPreview(params),
    "effects.preview": (params) => flows.previewEffect(params),
    "effects.render": (params) => job("effect", (ctx) => flows.renderEffect(params, ctx)),
    "effects.emojiMatch": ({ segments }) => ({ items: matchEmoji(segments ?? []) }),
    "transitions.list": () => flows.listTransitions(),
    "transitions.preview": (params) => flows.previewTransition(params),
    "transitions.render": (params) => job("transition", (ctx) => flows.renderTransition(params, ctx)),
    "transitions.clipList": () => flows.listClipTransitions(),
    "transitions.clipPreview": (params) => flows.previewClipTransition(params),
    "transitions.clipRender": (params) => job("clip-transition", (ctx) => flows.renderClipTransitionAt(params, ctx)),
    "color.match": (params) => job("color-match", (ctx) => flows.colorMatch(params, ctx)),
    "color.looks": (params) => flows.colorLooks(params),
    "color.auto": (params) => flows.colorAuto(params),
    "color.matchClips": (params) => job("color-match-clips", (ctx) => flows.colorMatchClips(params, ctx)),
    "color.fxPreview": (params) => flows.colorFxPreview(params),
    "color.render": (params) => job("color-render", (ctx) => flows.colorRender(params, ctx)),
    "effects.punchZoom": (params) => flows.punchZoom(params),
    "broll.place": (params) => job("broll", (ctx) => flows.placeBroll(params, ctx)),
    "multicam.analyze": (params) => job("multicam", (ctx) => flows.analyzeMulticam(params, ctx)),
    "multicam.recompute": ({ analysisId, options }) => flows.recomputeMulticam(analysisId, options),
    "multicam.apply": (params) => flows.applyMulticam(params),
    // İşler
    "jobs.get": ({ id }) => jobs.get(id) ?? Promise.reject(Object.assign(new Error("\u0130\u015F bulunamad\u0131"), { status: 404 })),
    "jobs.list": () => jobs.list(),
    // Uygulama içi güncelleme
    "update.info": () => updater.info(),
    "update.check": () => updater.check(),
    "update.publish": () => job("update-publish", ({ signal, progress }) => updater.publish((key, body, opts) => sfx.adminPut(key, body, opts), { signal, progress })),
    "update.install": () => job("update", ({ signal, progress }) => updater.install({ signal, progress })),
    "jobs.cancel": ({ id }) => ({ ok: jobs.cancel(id) }),
    // Yerel kütüphane
    "library.folders": () => library.folders(),
    "library.addFolder": ({ path, kind }) => library.addFolder(path, kind),
    "library.removeFolder": ({ path }) => library.removeFolder(path),
    "library.scan": () => job("library-scan", (ctx) => library.scan(ctx)),
    "library.search": (params) => library.search(params),
    "library.favorite": ({ path, on }) => ({ favorite: library.setFavorite(path, Boolean(on)) }),
    "library.attributions": () => ({ lines: library.attributions() }),
    // SFX Lab (bulut kütüphanesi)
    // Arayüze ses listesi değil özet gider (binlerce ses IPC'den geçmesin); liste sfx.search ile sayfa sayfa
    "sfx.catalog": async ({ refresh } = {}) => {
      const { sounds, ...rest } = await sfx.catalog({ refresh });
      return { ...rest, count: sounds.length };
    },
    "sfx.search": (params) => sfx.search(params),
    "sfx.download": ({ id }) => sfx.download(id),
    "sfx.favorite": ({ id, on }) => ({ favorite: sfx.setFavorite(id, Boolean(on)) }),
    "sfx.admin.test": () => sfx.adminTest(),
    "sfx.admin.tidy": () => sfx.adminTidy(),
    "sfx.credits": () => sfx.credits(),
    "sfx.admin.scanFolder": ({ dir }) => sfx.scanFolder(dir),
    "sfx.admin.upload": (params) => job("sfx-upload", (ctx) => sfx.adminUpload(params, ctx)),
    "sfx.admin.update": (params) => sfx.adminUpdate(params),
    "sfx.admin.delete": (params) => sfx.adminDelete(params),
    "sfx.admin.categories": (params) => sfx.adminSaveCategories(params),
    // Freesound
    "freesound.search": (params) => freesound.search(params),
    "freesound.download": ({ sound }) => freesound.download(sound),
    // Hesap ve lisans
    "license.status": () => license.status(),
    "license.login": ({ email, password }) => license.login(email, password),
    "license.start": ({ email }) => license.start(email),
    "license.verify": ({ code }) => license.verify(code),
    "license.refresh": () => license.refresh(),
    "license.removeDevice": ({ deviceId }) => license.removeDevice(deviceId),
    "license.logout": () => license.logout(),
    "license.checkout": ({ period }) => license.checkoutUrl(period),
    "license.portal": () => license.portalUrl(),
    // Tanılama
    "diagnostics.note": ({ text, kind }) => {
      diag.note(kind === "bilgi" ? "bilgi" : "hata", text);
      return { ok: true };
    },
    /**
     * Otomatik denetim (Test turu): kurgu programı gerekmeden sınanabilen her şeyi gerçekten çalıştırır.
     * Her satır: { id, title, ok, detail, hint }.
     */
    "diagnostics.selfTest": async () => {
      var _a2, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
      const items = [];
      const add = (id, title, ok, detail = "", hint = "") => items.push({ id, title, ok: Boolean(ok), detail: String(detail ?? "").slice(0, 200), hint });
      const st = await tools.status().catch(() => ({}));
      const fix = "Ana sayfa > Kurulumu tamamla > Bile\u015Fenleri indir.";
      add("ffmpeg", "Ses ve video i\u015Fleme (ffmpeg)", (_a2 = st.ffmpeg) == null ? void 0 : _a2.ok, ((_b = st.ffmpeg) == null ? void 0 : _b.version) ?? "", fix);
      add("ffprobe", "Dosya inceleme (ffprobe)", (_c = st.ffprobe) == null ? void 0 : _c.ok, "", fix);
      add("libass", "Altyaz\u0131, efekt ve ge\xE7i\u015F \xE7izimi (libass)", (_d = st.ffmpeg) == null ? void 0 : _d.subtitles, "", fix);
      add("whisper", "Konu\u015Fma tan\u0131ma program\u0131", (_e = st.whisper) == null ? void 0 : _e.ok, ((_f = st.whisper) == null ? void 0 : _f.version) ?? "", fix);
      const models = whisper.listModels().filter((m2) => m2.installed);
      add("model", "Konu\u015Fma modeli", models.length > 0, models.map((m2) => m2.id).join(", "), "Ayarlar > Konu\u015Fma tan\u0131ma modelleri > \u0130ndir.");
      try {
        (0, import_node_fs15.mkdirSync)(config.outputDir, { recursive: true });
        const probe = (0, import_node_path14.join)(config.outputDir, `.makas-deneme-${Date.now()}`);
        (0, import_node_fs15.writeFileSync)(probe, "x");
        (0, import_node_fs15.rmSync)(probe, { force: true });
        add("disk", "\xC7\u0131kt\u0131 klas\xF6r\xFCne yazma", true, config.outputDir);
      } catch (e) {
        add("disk", "\xC7\u0131kt\u0131 klas\xF6r\xFCne yazma", false, e.message, "Ayarlar\u2019dan yaz\u0131labilir bir \xE7\u0131kt\u0131 klas\xF6r\xFC se\xE7in.");
      }
      if ((_g = st.ffmpeg) == null ? void 0 : _g.subtitles) {
        try {
          const r = await flows.renderTransition({ id: "supurme", width: 320, height: 180, fps: 25, codec: host === "resolve" ? "prores" : "qtrle" }, {});
          add("gecis", "Ge\xE7i\u015F \xFCretimi (\u015Feffaf video + ses)", (0, import_node_fs15.existsSync)(r.videoPath) && r.audioPath && (0, import_node_fs15.existsSync)(r.audioPath), r.audioPath ? "" : "ge\xE7i\u015F sesi bulunamad\u0131", "Eklentiyi yeniden kurun.");
        } catch (e) {
          add("gecis", "Ge\xE7i\u015F \xFCretimi (\u015Feffaf video + ses)", false, e.message, "Tan\u0131lama raporunu g\xF6nderin.");
        }
      }
      if ((_h = st.ffmpeg) == null ? void 0 : _h.ok) {
        try {
          const wav = (0, import_node_path14.join)(config.dirs.cache, "deneme-kaydi.wav");
          await run(tools.resolve("ffmpeg"), ["-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-f", "lavfi", "-i", "aevalsrc='if(lt(mod(t,2),1),0.3*sin(2*PI*440*t),0)':d=4:s=16000", wav]);
          const r = await flows.analyzeSilence({ source: { kind: "file", path: wav }, options: { minSilence: 0.3 } }, { signal: void 0, progress: () => {
          } });
          add("sessizlik", "Sessizlik analizi", ((_i = r.keep) == null ? void 0 : _i.length) === 2, `${((_j = r.keep) == null ? void 0 : _j.length) ?? 0} konu\u015Fma par\xE7as\u0131 bulundu (beklenen 2)`, "Tan\u0131lama raporunu g\xF6nderin.");
        } catch (e) {
          add("sessizlik", "Sessizlik analizi", false, e.message, "Tan\u0131lama raporunu g\xF6nderin.");
        }
      }
      const cat = await sfx.catalog().catch((e) => ({ error: e.message, sounds: [] }));
      add("sfx", "SFX Lab ses k\xFCt\xFCphanesi", (((_k = cat.sounds) == null ? void 0 : _k.length) ?? 0) > 0, cat.error || `${((_l = cat.sounds) == null ? void 0 : _l.length) ?? 0} ses`, "\u0130nternet ba\u011Flant\u0131n\u0131z\u0131 ve Ayarlar > SFX Lab adresini denetleyin.");
      const ls = license.status();
      add("lisans", "Hesap ve lisans", ls.valid, !ls.enabled ? "geli\u015Ftirici s\xFCr\xFCm\xFC (lisans kapal\u0131)" : ls.valid ? `${ls.plan}${ls.daysLeft != null ? ` \xB7 ${ls.daysLeft} g\xFCn` : ""}` : ls.reason ?? "", "Hesap ekran\u0131ndan giri\u015F yap\u0131n.");
      diag.note("bilgi", `otomatik denetim: ${items.filter((x) => !x.ok).map((x) => x.id).join(", ") || "hepsi tamam"}`);
      return { items, ok: items.every((x) => x.ok) };
    },
    "diagnostics.report": async ({ save = false } = {}) => {
      var _a2;
      const cat = await sfx.catalog().catch((e) => ({ configured: Boolean(sfx.catalogUrl()), error: e.message, sounds: [] }));
      const text = diag.report({
        version: APP_VERSION,
        build: updater.info().current,
        host: host ?? "taray\u0131c\u0131",
        tools: await tools.status().catch(() => ({})),
        models: whisper.listModels().filter((m2) => m2.installed).map((m2) => m2.id),
        license: license.status(),
        sfx: { configured: cat.configured, error: cat.error, count: ((_a2 = cat.sounds) == null ? void 0 : _a2.length) ?? 0 }
      });
      return { text, path: save ? diag.save(text) : null };
    },
    // Dosya sistemi (geliştirme modunda dosya seçmek için)
    "fs.list": ({ dir, ext }) => listDirectory(dir, ext)
  };
  if (sfx.catalogUrl()) {
    const warm = setTimeout(() => sfx.search({ limit: 1 }).catch(() => {
    }), 4e3);
    (_a = warm.unref) == null ? void 0 : _a.call(warm);
  }
  async function call(method, params = {}) {
    const fn = methods[method];
    if (!fn) throw Object.assign(new Error(`Bilinmeyen i\u015Flem: ${method}`), { status: 404 });
    try {
      if (!FREE_METHODS.test(method)) await license.require();
      return await fn(params ?? {});
    } catch (e) {
      if ((e == null ? void 0 : e.status) !== 402 && method !== "jobs.get") diag.note("hata", `${method}: ${(e == null ? void 0 : e.message) ?? e}`);
      throw e;
    }
  }
  return { call, methods: Object.keys(methods), config, license, tools, media, whisper, jobs, library, freesound, bridge, flows, sfx };
}
function listDirectory(dir, extFilter) {
  if (!dir) {
    const roots = [{ name: "Ev klas\xF6r\xFC", path: (0, import_node_os8.homedir)(), dir: true }];
    if ((0, import_node_os8.platform)() === "win32") {
      for (const letter of "CDEFGHIJKLMNOPQRSTUVWXYZ") if ((0, import_node_fs15.existsSync)(`${letter}:\\`)) roots.push({ name: `${letter}:`, path: `${letter}:\\`, dir: true });
    } else if ((0, import_node_os8.platform)() === "darwin" && (0, import_node_fs15.existsSync)("/Volumes")) roots.push({ name: "Diskler", path: "/Volumes", dir: true });
    else roots.push({ name: "K\xF6k", path: "/", dir: true });
    return { dir: null, parent: null, entries: roots };
  }
  const abs = (0, import_node_path14.resolve)(dir);
  const exts = extFilter ? String(extFilter).split(",").map((e) => e.trim().toLowerCase()) : null;
  const entries = [];
  for (const e of (0, import_node_fs15.readdirSync)(abs, { withFileTypes: true })) {
    if (e.name.startsWith(".")) continue;
    const full = (0, import_node_path14.join)(abs, e.name);
    if (e.isDirectory()) entries.push({ name: e.name, path: full, dir: true });
    else if (!exts || exts.includes((0, import_node_path14.extname)(e.name).toLowerCase())) entries.push({ name: e.name, path: full, dir: false });
  }
  entries.sort((a, b) => a.dir === b.dir ? a.name.localeCompare(b.name, "tr") : a.dir ? -1 : 1);
  const parent = (0, import_node_path14.parse)(abs).root === abs ? null : (0, import_node_path14.dirname)(abs);
  return { dir: abs, parent, entries };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createService,
  listDirectory
});
