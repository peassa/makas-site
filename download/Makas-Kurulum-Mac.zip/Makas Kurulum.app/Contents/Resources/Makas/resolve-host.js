// Makas — DaVinci Resolve zaman çizelgesi işlemleri (Workflow Integration API).
//
// Resolve sürümüne göre API çağrıları ya doğrudan değer ya da Promise döndürür; bu yüzden
// her çağrı `await` ile yapılır (değer döndürenlerde de sorunsuz çalışır).
// Kareler Resolve'da zaman çizelgesinin başlangıç karesinden (çoğunlukla 01:00:00:00) sayılır;
// arayüze her zaman sekans başından itibaren saniye olarak verilir.

'use strict';

const fs = require('fs');
const path = require('path');

// Arayüzdeki mini zaman çizelgesi için yeterli; her klip Resolve'a 4 ayrı istek demek
const MAX_CLIPS = 60;

// --- Zaman kodu ---

function timecodeToFrames(tc, fps, dropFrame) {
  const parts = String(tc).replace(/[;.]/g, ':').split(':').map((n) => parseInt(n, 10));
  if (parts.length !== 4 || parts.some((n) => !Number.isFinite(n))) return 0;
  const [h, m, s, f] = parts;
  const base = Math.round(fps);
  let frames = ((h * 60 + m) * 60 + s) * base + f;
  if (dropFrame) {
    const d = Math.round(base / 15);
    const minutes = h * 60 + m;
    frames -= d * (minutes - Math.floor(minutes / 10));
  }
  return frames;
}

function framesToTimecode(frames, fps, dropFrame) {
  const base = Math.round(fps);
  let n = Math.max(0, Math.round(frames));
  if (dropFrame) {
    // SMPTE drop-frame: her dakika başında (10'un katları hariç) d kare atlanır
    const d = Math.round(base / 15);
    const per10 = base * 600 - d * 9;
    const per1 = base * 60 - d;
    const tens = Math.floor(n / per10);
    const rem = n % per10;
    n += d * 9 * tens + (rem > d ? d * Math.floor((rem - d) / per1) : 0);
  }
  const f = n % base;
  const s = Math.floor(n / base) % 60;
  const m = Math.floor(n / (base * 60)) % 60;
  const h = Math.floor(n / (base * 3600));
  const p = (x) => String(x).padStart(2, '0');
  return `${p(h)}:${p(m)}:${p(s)}${dropFrame ? ';' : ':'}${p(f)}`;
}

const round = (n) => Math.round(n * 100) / 100;

function samePath(a, b) {
  const norm = (p) => path.resolve(String(p)).replace(/\\/g, '/');
  return process.platform === 'darwin' || process.platform === 'win32' ? norm(a).toLowerCase() === norm(b).toLowerCase() : norm(a) === norm(b);
}

/**
 * @param {object} o
 * @param {() => Promise<any>} o.getResolve  Resolve nesnesi (bağlantı yoksa hata fırlatır)
 * @param {string} o.cacheDir                XML anlık görüntüleri için klasör
 * @param {object} [o.ui]                    { pickFiles, pickFolder, openUrl, setPinned } (Electron)
 * @param {(desc:object)=>Promise<{xmlPath:string}>} [o.buildXml]  klip listesinden FCP 7 XML üretir (motor)
 * @param {(xmlPath:string)=>Promise<object>} [o.planXml]  XML'i API ile kurulacak plana çevirir (motor)
 * @param {(msg:string)=>void} [o.log]  tanılama günlüğü
 */
/** LUT dosyalarını Resolve'un LUT klasörüne (Makas alt klasörü) kopyalayan yardımcı. */
function makeLutInstaller(log) {
  const os = require('os');
  const home = os.homedir();
  const roots =
    process.platform === 'darwin'
      ? ['/Library/Application Support/Blackmagic Design/DaVinci Resolve/LUT', path.join(home, 'Library/Application Support/Blackmagic Design/DaVinci Resolve/LUT')]
      : process.platform === 'win32'
        ? [path.join(process.env.PROGRAMDATA || 'C:\\ProgramData', 'Blackmagic Design/DaVinci Resolve/Support/LUT'), path.join(process.env.APPDATA || home, 'Blackmagic Design/DaVinci Resolve/Support/LUT')]
        : ['/opt/resolve/LUT', '/home/resolve/LUT', path.join(home, '.local/share/DaVinciResolve/LUT')];
  let lutDir = null;
  for (const root of roots) {
    try {
      if (!fs.existsSync(root)) continue;
      fs.mkdirSync(path.join(root, 'Makas'), { recursive: true });
      lutDir = path.join(root, 'Makas');
      break;
    } catch (e) {
      log?.(`LUT klasörüne yazılamadı (${root}): ${e.message}`);
    }
  }
  // Resolve'un bulabileceği yere, Türkçe harf ve boşluk içermeyen adla kopyalar; denenecek yolları verir
  const install = (src) => {
    const safe = `${path
      .basename(src, path.extname(src))
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/ı/g, 'i')
      .replace(/[^A-Za-z0-9_-]+/g, '_')
      .slice(-70)}.cube`;
    const list = [];
    if (lutDir) {
      try {
        fs.copyFileSync(src, path.join(lutDir, safe));
        list.push(path.join(lutDir, safe), `Makas/${safe}`);
      } catch (e) {
        log?.(`LUT kopyalanamadı: ${e.message}`);
      }
    }
    list.push(src);
    return list;
  };
  return { install, lutDir };
}

function createResolveHost({ getResolve, cacheDir, ui = {}, buildXml, planXml, log }) {
  let clipCache = null;

  async function project() {
    const resolve = await getResolve();
    const pm = await resolve.GetProjectManager();
    const p = pm ? await pm.GetCurrentProject() : null;
    if (!p) throw new Error('Resolve\'da açık proje yok');
    return p;
  }

  async function timeline(p) {
    const tl = await (p ?? (await project())).GetCurrentTimeline();
    if (!tl) throw new Error('Etkin zaman çizelgesi yok. Bir zaman çizelgesi açın.');
    return tl;
  }

  async function timing(tl, p) {
    let fps = parseFloat(await tl.GetSetting('timelineFrameRate'));
    if (!Number.isFinite(fps) || fps <= 0) fps = parseFloat(await p.GetSetting('timelineFrameRate')) || 25;
    const df = String(await tl.GetSetting('timelineDropFrameTimecode')) === '1';
    const start = Number(await tl.GetStartFrame()) || 0;
    return { fps, df, start };
  }

  async function playheadSeconds(tl, t) {
    const tc = String((await tl.GetCurrentTimecode()) ?? '');
    if (!tc) return 0;
    return Math.max(0, (timecodeToFrames(tc, t.fps, t.df || tc.includes(';')) - t.start) / t.fps);
  }

  async function trackInfo(tl, kind, t) {
    const count = Number(await tl.GetTrackCount(kind)) || 0;
    const out = [];
    for (let i = 1; i <= count; i++) {
      const items = (await tl.GetItemListInTrack(kind, i)) ?? [];
      const clips = [];
      for (const it of items.slice(0, MAX_CLIPS)) {
        const s = Number(await it.GetStart());
        const e = Number(await it.GetEnd());
        let enabled = true;
        try {
          if (it.GetClipEnabled) enabled = (await it.GetClipEnabled()) !== false;
        } catch {
          /* eski sürümler */
        }
        clips.push({ name: String(await it.GetName()), start: round((s - t.start) / t.fps), end: round((e - t.start) / t.fps), enabled });
      }
      let name = `${kind === 'video' ? 'V' : 'A'}${i}`;
      try {
        name = (await tl.GetTrackName(kind, i)) || name;
      } catch {
        /* yok sayılır */
      }
      out.push({ index: i, name, items: items.length, clips });
    }
    return out;
  }

  async function findPoolItem(p, file) {
    const pool = await p.GetMediaPool();
    const stack = [await pool.GetRootFolder()];
    while (stack.length) {
      const folder = stack.pop();
      for (const clip of (await folder.GetClipList()) ?? []) {
        let fp = null;
        try {
          fp = await clip.GetClipProperty('File Path');
        } catch {
          fp = null;
        }
        if (fp && samePath(fp, file)) return clip;
      }
      stack.push(...((await folder.GetSubFolderList()) ?? []));
    }
    return null;
  }

  async function importMedia(p, file) {
    const existing = await findPoolItem(p, file);
    if (existing) return existing;
    const pool = await p.GetMediaPool();
    const items = await pool.ImportMedia([file]);
    if (!items || !items.length) throw new Error(`Medya havuzuna eklenemedi: ${path.basename(file)}`);
    return items[0];
  }

  async function clipFrames(item, fps) {
    let frames = 0;
    try {
      frames = parseInt(await item.GetClipProperty('Frames'), 10) || 0;
    } catch {
      frames = 0;
    }
    return frames > 1 ? frames : Math.round(5 * fps);
  }

  async function freeTrack(tl, kind, start, end, minIndex = 1) {
    const count = Number(await tl.GetTrackCount(kind)) || 0;
    for (let i = minIndex; i <= count; i++) {
      let busy = false;
      for (const it of (await tl.GetItemListInTrack(kind, i)) ?? []) {
        if (Number(await it.GetStart()) < end && Number(await it.GetEnd()) > start) {
          busy = true;
          break;
        }
      }
      if (!busy) return i;
    }
    if (kind === 'audio') await tl.AddTrack('audio', 'stereo');
    else await tl.AddTrack(kind);
    const after = Number(await tl.GetTrackCount(kind)) || 0;
    if (after <= count) throw new Error('Yeni parça eklenemedi');
    return after;
  }

  async function uniqueTimelineName(p, name) {
    const names = new Set();
    const n = Number(await p.GetTimelineCount()) || 0;
    for (let i = 1; i <= n; i++) {
      const t = await p.GetTimelineByIndex(i);
      if (t) names.add(String(await t.GetName()));
    }
    if (!names.has(name)) return name;
    let k = 2;
    while (names.has(`${name} (${k})`)) k++;
    return `${name} (${k})`;
  }

  async function append(p, clip) {
    const pool = await p.GetMediaPool();
    let added;
    try {
      added = await pool.AppendToTimeline([clip]);
    } catch (e) {
      // Bazı sürümlerin JavaScript API'si konumlu ekleme bilgisini (nesne) kabul etmiyor
      if (/argument/i.test(String(e && e.message))) {
        throw new Error('Dosya medya havuzuna eklendi, ancak bu Resolve sürümü konumlu eklemeye izin vermedi. Medya havuzundan zaman çizelgesine sürükleyin.');
      }
      throw e;
    }
    if (!added || (Array.isArray(added) && !added.length)) throw new Error('Zaman çizelgesine eklenemedi');
    return added;
  }

  /**
   * Plandaki parçalardan yeni bir zaman çizelgesi kurar: boş zaman çizelgesi, kaynak klipler
   * medya havuzundan, her parça kaynaktaki giriş/çıkışıyla doğru parçaya ve konuma.
   */
  let buildStats = null;

  // Kurulum yarıda kalırsa yarım zaman çizelgesi silinir ve önceki zaman çizelgesine dönülür
  async function buildTimeline(p, pool, plan, name, framing = null) {
    const src = await p.GetCurrentTimeline();
    const tl = await pool.CreateEmptyTimeline(name);
    if (!tl) throw new Error('Yeni zaman çizelgesi oluşturulamadı');
    try {
      return await fillTimeline(p, pool, plan, name, framing, src, tl);
    } catch (e) {
      try {
        if (src) await p.SetCurrentTimeline(src);
        await pool.DeleteTimelines([tl]);
      } catch {
        /* silinemezse boş zaman çizelgesi kalır */
      }
      throw e;
    }
  }

  async function fillTimeline(p, pool, plan, name, framing, src, tl) {
    await p.SetCurrentTimeline(tl);
    // Kaynak zaman çizelgesinin çözünürlüğü (ör. dikey 1080×1920) ve kare hızı
    const settings = [
      ['useCustomSettings', '1'],
      ['timelineFrameRate', src ? String(await src.GetSetting('timelineFrameRate')) : String(plan.fps)],
      ['timelineResolutionWidth', String(plan.width)],
      ['timelineResolutionHeight', String(plan.height)],
    ];
    for (const [k, v] of settings) {
      try {
        await tl.SetSetting(k, v);
      } catch {
        /* bazı ayarlar boş zaman çizelgesinde bile değiştirilemeyebilir */
      }
    }
    const t = await timing(tl, p);
    const ensureTracks = async (kind, n) => {
      for (let c = Number(await tl.GetTrackCount(kind)) || 0; c < n; c++) {
        if (kind === 'audio') await tl.AddTrack('audio', 'stereo');
        else await tl.AddTrack(kind);
      }
    };
    await ensureTracks('video', plan.video.length);
    await ensureTracks('audio', plan.audio.length);

    const items = new Map();
    const fileFps = new Map();
    const clips = [];
    const meta = [];
    for (const [kind, tracks] of [
      ['video', plan.video],
      ['audio', plan.audio],
    ]) {
      for (const [ti, pieces] of tracks.entries()) {
        for (const pc of pieces) {
          let item = items.get(pc.path);
          if (!item) {
            item = await importMedia(p, pc.path);
            items.set(pc.path, item);
            fileFps.set(pc.path, parseFloat(await clipProp(item, 'FPS')) || t.fps);
          }
          const ffps = fileFps.get(pc.path);
          const recordFrame = t.start + Math.round(pc.start * t.fps);
          const planEnd = Math.max(recordFrame + 1, t.start + Math.round(pc.end * t.fps));
          // Kaynak aralığı, zaman çizelgesindeki yuvayı tam dolduracak kadar kaynak karesi içerir
          const startFrame = Math.max(0, Math.round(pc.srcIn * ffps));
          const srcCount = Math.max(1, Math.round(((planEnd - recordFrame) * ffps) / t.fps));
          clips.push({
            mediaPoolItem: item,
            startFrame,
            endFrame: startFrame + srcCount - 1,
            trackIndex: ti + 1,
            recordFrame,
            mediaType: kind === 'video' ? 1 : 2,
          });
          meta.push({ ...pc, kind, planEnd, ffps });
        }
      }
    }
    if (!clips.length) throw new Error('Kurulacak parça yok');

    // Her parça PLANLANAN yerinde kalır (görüntü, ses, SFX ve altyazı birbirine göre kaymaz).
    // Resolve'un parçayı kaç kare uzunluğunda yerleştirdiği sürüme (bitiş karesi dahil/hariç) ve
    // kare hızı dönüşümüne göre değişir: her parça ölçülür, yuvasını doldurmuyorsa (ya da
    // taşıyorsa) silinip düzeltilmiş kaynak aralığıyla yeniden eklenir.
    const added = new Array(clips.length).fill(null);
    const adj = new Array(clips.length).fill(0); // parça başına bitiş düzeltmesi (kaynak karesi)
    const bias = new Map(); // dosya başına öğrenilen düzeltme
    const want = (i) => meta[i].planEnd - clips[i].recordFrame;
    const shaped = (i) => ({ ...clips[i], endFrame: Math.max(clips[i].startFrame, clips[i].endFrame + adj[i]) });
    const measure = async (it) => {
      try {
        const s = Number(await it.GetStart());
        const e = Number(await it.GetEnd());
        return Number.isFinite(s) && Number.isFinite(e) && e > s ? { s, e } : null;
      } catch {
        return null;
      }
    };
    const appendOne = async (i) => {
      const r = await pool.AppendToTimeline([shaped(i)]);
      added[i] = Array.isArray(r) ? r[0] ?? null : null;
      if (!r || (Array.isArray(r) && !r.length)) throw new Error('Parçalar zaman çizelgesine eklenemedi');
    };
    let canRepair = typeof tl.DeleteClips === 'function';
    const stats = { repaired: 0, gaps: 0, moved: 0 };
    /** Parçayı ölçer; yuvasını tam doldurana kadar (en çok 3 tur) düzeltir. true: tam oturdu. */
    const settle = async (i) => {
      let overshot = false;
      for (let round = 0; round < 3; round++) {
        const m = added[i] ? await measure(added[i]) : null;
        if (!m) return true; // ölçülemiyor: olduğu gibi bırak
        if (m.s !== clips[i].recordFrame) stats.moved++;
        const diff = want(i) - (m.e - m.s);
        if (!diff) return true;
        if (Math.abs(diff) > 3 || !canRepair) return false; // beklenmeyen fark: dokunma
        if (diff < 0) overshot = true;
        else if (overshot) return false; // tam uzunluk tutturulamıyor: taşmaktansa 1 kare kısa kalsın
        const step = round === 0 ? Math.max(1, Math.round((Math.abs(diff) * meta[i].ffps) / t.fps)) : 1;
        let deleted = false;
        try {
          deleted = Boolean(await tl.DeleteClips([added[i]]));
        } catch {
          deleted = false;
        }
        if (!deleted) {
          canRepair = false;
          return false;
        }
        adj[i] += Math.sign(diff) * step;
        await appendOne(i);
        stats.repaired++;
      }
      const m = added[i] ? await measure(added[i]) : null;
      return !m || m.e - m.s === want(i);
    };

    // 1) Her dosyadan bir parça tek başına eklenip ölçülür: o dosya için düzeltme öğrenilir
    const pilots = [];
    const seen = new Set();
    clips.forEach((_, i) => {
      if (seen.has(meta[i].path)) return;
      seen.add(meta[i].path);
      pilots.push(i);
    });
    for (const i of pilots) {
      await appendOne(i);
      const ok = await settle(i);
      if (ok) bias.set(meta[i].path, adj[i]);
      else stats.gaps++;
    }
    log?.(`parça ölçümü: ${pilots.map((i) => `${path.basename(meta[i].path)} ${adj[i] >= 0 ? '+' : ''}${adj[i]}`).join(', ')}`);

    // 2) Kalanlar öğrenilen düzeltmeyle tek seferde eklenir
    const rest = clips.map((_, i) => i).filter((i) => !pilots.includes(i));
    for (const i of rest) adj[i] = bias.get(meta[i].path) ?? 0;
    if (rest.length) {
      const r = await pool.AppendToTimeline(rest.map(shaped));
      if (Array.isArray(r) && r.length === rest.length) rest.forEach((i, k) => (added[i] = r[k] ?? null));
      else if (!r || (Array.isArray(r) && !r.length)) throw new Error('Parçalar zaman çizelgesine eklenemedi');
      // (uzunluğu tutmayan dönüş: hangi öğenin hangi parça olduğu bilinemez, ölçüm atlanır)
    }

    // 3) Hepsi ölçülür; yuvasını doldurmayanlar tek tek düzeltilir
    for (const i of rest) {
      if (!added[i]) continue;
      if (!(await settle(i))) stats.gaps++;
    }
    if (stats.repaired || stats.gaps || stats.moved) log?.(`uzunluk düzeltmesi: ${stats.repaired} yeniden ekleme, ${stats.gaps} parça tam oturmadı, ${stats.moved} parça farklı konumda`);
    buildStats = stats;
    // Jump cut yakınlaştırması ve devre dışı parçalar (ekleme sırası korunur)
    {
      for (const [i, item] of added.entries()) {
        if (!item) continue;
        const pc = meta[i];
        try {
          // XML ölçeği doğal piksele göre; Resolve ise görüntüyü önce çerçeveye sığdırır
          const fit = pc.srcWidth && pc.srcHeight ? Math.min(plan.width / pc.srcWidth, plan.height / pc.srcHeight) : 1;
          const zoom = (pc.scale || 100) / 100 / fit;
          if (Math.abs(zoom - 1) > 0.005) {
            await item.SetProperty('ZoomX', zoom);
            await item.SetProperty('ZoomY', zoom);
          }
          // Dikey kırpmada konuşanı ortala: x (0-1) kaynaktaki yatay konum
          const fr = pc.kind === 'video' && framing?.find((f) => Math.abs(f.start - pc.start) < 0.05);
          if (fr && fr.x != null && pc.srcWidth) {
            const shown = pc.srcWidth * ((pc.scale || 100) / 100);
            const room = Math.max(0, (shown - plan.width) / 2);
            const pan = Math.max(-room, Math.min(room, -(fr.x - 0.5) * shown));
            if (Math.abs(pan) > 1) await item.SetProperty('Pan', Math.round(pan));
          }
          if (pc.enabled === false && item.SetClipEnabled) await item.SetClipEnabled(false);
        } catch {
          /* özellik desteklenmiyorsa parça olduğu gibi kalır */
        }
      }
    }
    log?.(`zaman çizelgesi API ile kuruldu: "${name}", ${clips.length} parça`);
    return tl;
  }

  async function clipProp(item, key) {
    try {
      const v = await item.GetClipProperty(key);
      return v == null ? '' : String(v);
    } catch {
      return '';
    }
  }

  /**
   * Klibin kaynak dosyadaki başlangıcı (sn, dosyanın başından). API sürüme göre bunu saniye,
   * kare ya da kaynağın zaman koduna göre (ör. 04:12:00:00'dan başlayan kamera dosyası)
   * verebilir; dosya süresine sığmayan adaylar elenir.
   */
  async function sourceInSeconds(it, mpi, f, t, lenSec) {
    const num = async (fn) => {
      try {
        const v = Number(await fn());
        return Number.isFinite(v) ? v : null;
      } catch {
        return null;
      }
    };
    const startTc = await clipProp(mpi, 'Start TC');
    const tcSec = startTc ? timecodeToFrames(startTc, f.fps, startTc.includes(';')) / f.fps : 0;
    const fileDur = f.frames > 0 && f.fps > 0 ? f.frames / f.fps : null;
    const maxIn = fileDur != null ? Math.max(0, fileDur - lenSec) + 0.5 : Infinity;
    const cands = [];
    const st = await num(() => it.GetSourceStartTime());
    if (st != null) cands.push(['time', st], ['time-tc', st - tcSec]);
    const sf = await num(() => it.GetSourceStartFrame());
    if (sf != null) cands.push(['frame', sf / f.fps], ['frame-tc', sf / f.fps - tcSec]);
    const lo = await num(() => it.GetLeftOffset());
    if (lo != null) cands.push(['offset', lo / t.fps]);
    const pick = cands.find(([, v]) => v >= -0.02 && v <= maxIn);
    log?.(`kaynak başlangıcı ${f.name}: ${pick ? `${pick[0]}=${pick[1].toFixed(3)}` : 'bulunamadı → 0'} | adaylar ${JSON.stringify(cands)} | TC ${startTc || '-'} | süre ${fileDur ?? '?'}`);
    return pick ? Math.max(0, pick[1]) : 0;
  }

  /** Zaman çizelgesini motorun XML üretecine verilecek klip listesine çevirir. */
  async function describeForXml(tl, p, name) {
    const t = await timing(tl, p);
    const files = new Map();
    let skipped = 0;
    const readTracks = async (kind) => {
      const count = Number(await tl.GetTrackCount(kind)) || 0;
      const tracks = [];
      for (let i = 1; i <= count; i++) {
        const list = [];
        for (const it of (await tl.GetItemListInTrack(kind, i)) ?? []) {
          let mpi = null;
          try {
            mpi = await it.GetMediaPoolItem();
          } catch {
            mpi = null;
          }
          const file = mpi ? await clipProp(mpi, 'File Path') : '';
          if (!file) {
            // Başlık, üreteç, Fusion klibi gibi dosyasız öğeler
            skipped += 1;
            continue;
          }
          let f = files.get(file);
          if (!f) {
            const [w, h] = (await clipProp(mpi, 'Resolution')).split(/x/i).map((n) => parseInt(n, 10));
            f = {
              id: `file-${files.size + 1}`,
              path: file,
              name: path.basename(file),
              fps: parseFloat(await clipProp(mpi, 'FPS')) || t.fps,
              frames: parseInt(await clipProp(mpi, 'Frames'), 10) || 0,
              width: w || 0,
              height: h || 0,
              hasVideo: Boolean(w && h),
              audioChannels: parseInt(await clipProp(mpi, 'Audio Ch'), 10) || 0,
            };
            files.set(file, f);
          }
          if (kind === 'audio' && !f.audioChannels) f.audioChannels = 2;
          let enabled = true;
          try {
            if (it.GetClipEnabled) enabled = (await it.GetClipEnabled()) !== false;
          } catch {
            /* eski sürümler */
          }
          list.push({
            fileId: f.id,
            name: String(await it.GetName()),
            start: Number(await it.GetStart()) - t.start,
            end: Number(await it.GetEnd()) - t.start,
            sourceIn: await sourceInSeconds(it, mpi, f, t, (Number(await it.GetEnd()) - Number(await it.GetStart())) / t.fps),
            enabled,
          });
        }
        tracks.push(list);
      }
      return tracks;
    };
    const video = await readTracks('video');
    const audio = await readTracks('audio');
    return {
      name,
      fps: t.fps,
      width: parseInt(await tl.GetSetting('timelineResolutionWidth'), 10) || 1920,
      height: parseInt(await tl.GetSetting('timelineResolutionHeight'), 10) || 1080,
      duration: Number(await tl.GetEndFrame()) - t.start,
      files: [...files.values()],
      video,
      audio,
      skipped,
    };
  }

  /**
   * Şeffaf katman videosunda alfa kanalını açar ve sonucu okur. Resolve alfa kipini klip başına tutar
   * (Clip Attributes > Alpha Mode); "None" kalırsa katman siyah zeminle görünür.
   * @returns {Promise<string|null|undefined>} açılan kip; null: açılamadı; undefined: okunamadı (bilinmiyor)
   */
  async function enableAlpha(item) {
    let seen;
    for (const mode of ['Straight', 'Premultiplied']) {
      try {
        await item.SetClipProperty('Alpha mode', mode);
      } catch {
        /* özellik adı sürüme göre değişebilir */
      }
      try {
        seen = await item.GetClipProperty('Alpha mode');
      } catch {
        seen = undefined;
      }
      if (seen == null || seen === '') return undefined;
      if (!/^(none|yok)$/i.test(String(seen))) return String(seen);
    }
    log?.(`Alfa kipi açılamadı (okunan: ${seen})`);
    return null;
  }

  // --- Sürükleyip bırakılan geçişi kesime oturtma ---
  const isMakasClip = (name) => /Makas Gecis/i.test(String(name ?? ''));

  /** Zaman çizelgesinde bu dosyadan gelen öğeler (video ve ses parçalarında). */
  async function itemsOfFile(tl, file) {
    const out = [];
    for (const kind of ['video', 'audio']) {
      const count = Number(await tl.GetTrackCount(kind)) || 0;
      for (let i = 1; i <= count; i++) {
        for (const it of (await tl.GetItemListInTrack(kind, i)) ?? []) {
          // Önce ad (ucuz), sonra dosya yolu: uzun zaman çizelgelerinde her öğeye yol sorulmaz
          if (!isMakasClip(await it.GetName())) continue;
          let fp = '';
          try {
            const mpi = await it.GetMediaPoolItem();
            fp = mpi ? await mpi.GetClipProperty('File Path') : '';
          } catch {
            fp = '';
          }
          if (fp && samePath(fp, file)) out.push({ kind, track: i, item: it, start: Number(await it.GetStart()) });
        }
      }
    }
    return out;
  }
  const dropKey = (m) => `${m.kind}:${m.track}:${m.start}`;

  const host = {
    async ping() {
      const resolve = await getResolve();
      return { product: await resolve.GetProductName(), version: await resolve.GetVersionString() };
    },

    async getSequence() {
      const p = await project();
      const tl = await p.GetCurrentTimeline();
      if (!tl) return { ok: false };
      const t = await timing(tl, p);
      const id = String((tl.GetUniqueId ? await tl.GetUniqueId() : null) ?? (await tl.GetName()));
      const end = Number(await tl.GetEndFrame());
      // Klip listesi pahalıdır (her klip için ayrı istekler): yalnızca zaman çizelgesi değişince
      // (başka zaman çizelgesi, uzunluk ya da parça sayısı) yeniden okunur. Yoklama hafif kalır.
      const trackCounts = [Number(await tl.GetTrackCount('video')) || 0, Number(await tl.GetTrackCount('audio')) || 0];
      const key = `${id}:${end}:${trackCounts.join(',')}`;
      if (!clipCache || clipCache.key !== key) {
        clipCache = { key, at: Date.now(), video: await trackInfo(tl, 'video', t), audio: await trackInfo(tl, 'audio', t) };
      }
      // In–Out işaretleri (Resolve 18+): kare cinsinden, Out dahil
      let inOut = null;
      try {
        const m = tl.GetMarkInOut ? await tl.GetMarkInOut() : null;
        const v = m?.video?.in != null ? m.video : m?.audio;
        if (v && v.in != null && v.out != null) {
          let a = Number(v.in);
          let b = Number(v.out);
          if (t.start > 0 && a >= t.start) {
            a -= t.start;
            b -= t.start;
          }
          if (b > a) inOut = { start: round(a / t.fps), end: round((b + 1) / t.fps) };
        }
      } catch {
        inOut = null;
      }
      return {
        ok: true,
        id,
        inOut,
        name: String(await tl.GetName()),
        duration: round((end - t.start) / t.fps),
        fps: round(t.fps),
        width: parseInt(await tl.GetSetting('timelineResolutionWidth'), 10) || 1920,
        height: parseInt(await tl.GetSetting('timelineResolutionHeight'), 10) || 1080,
        playhead: round(await playheadSeconds(tl, t)),
        video: clipCache.video,
        audio: clipCache.audio,
      };
    },

    async exportSequence() {
      const resolve = await getResolve();
      const p = await project();
      const tl = await timeline(p);
      const name = String(await tl.GetName());
      // 1) Resolve'un kendi FCP 7 XML dışa aktarımı: yalnızca sabitler API'de varsa
      //    (JavaScript API'sinde çoğu sürümde yok; undefined gönderilirse "Unknown argument type" hatası verir)
      const type = await resolve.EXPORT_FCP_7_XML;
      if (typeof type === 'number') {
        try {
          fs.mkdirSync(cacheDir, { recursive: true });
          const out = path.join(cacheDir, `resolve-${Date.now()}.xml`);
          const sub = await resolve.EXPORT_NONE;
          const ok = await tl.Export(out, type, typeof sub === 'number' ? sub : 0);
          if (ok && fs.existsSync(out) && /<xmeml/.test(fs.readFileSync(out, 'utf8').slice(0, 4000))) return { xmlPath: out, name };
        } catch {
          /* aşağıdaki yönteme geç */
        }
      }
      // 2) Zaman çizelgesini klip klip okuyup XML'i motor üretir
      if (!buildXml) throw new Error('Zaman çizelgesi dışa aktarılamadı');
      const desc = await describeForXml(tl, p, name);
      if (!desc.video.flat().length && !desc.audio.flat().length) {
        throw new Error('Zaman çizelgesinde bir medya dosyasına bağlı klip bulunamadı');
      }
      const r = await buildXml(desc);
      log?.(`sekans "${name}": ${desc.fps} fps, ${desc.duration} kare, ${desc.video.length} video / ${desc.audio.length} ses parçası, ${desc.files.length} dosya, ${desc.skipped} atlandı → ${r.xmlPath}`);
      return { xmlPath: r.xmlPath, name, skipped: desc.skipped };
    },

    async importSequence({ path: file, name, framing = null }) {
      const p = await project();
      const pool = await p.GetMediaPool();
      const unique = await uniqueTimelineName(p, name || path.basename(file, path.extname(file)));
      // 1) Zaman çizelgesini API ile parça parça kur (Resolve XML içe aktarımı güvenilir değil)
      let firstError = null;
      if (planXml) {
        try {
          const plan = await planXml(file);
          const tl = await buildTimeline(p, pool, plan, unique, framing);
          return { name: String(await tl.GetName()), built: true, gaps: buildStats?.gaps ?? 0 };
        } catch (e) {
          firstError = e;
          log?.(`API ile kurulamadı, XML içe aktarma deneniyor: ${e.message}`);
        }
      }
      // 2) XML içe aktarma
      let tl = null;
      try {
        tl = await pool.ImportTimelineFromFile(file, { timelineName: unique, importSourceClips: true });
      } catch {
        tl = null;
      }
      if (!tl) {
        try {
          // Seçenek nesnesini kabul etmeyen sürümler: seçeneksiz içe aktar, sonra adlandır
          tl = await pool.ImportTimelineFromFile(file);
          if (tl) {
            try {
              await tl.SetName(unique);
            } catch {
              /* ad değiştirilemezse dosya adıyla kalır */
            }
          }
        } catch (e) {
          throw firstError ?? e;
        }
      }
      if (!tl) throw firstError ?? new Error('Zaman çizelgesi içe aktarılamadı');
      await p.SetCurrentTimeline(tl);
      return { name: String(await tl.GetName()) };
    },

    /** Kesilmiş zaman çizelgesini siler, orijinali açar (Makas'ın kendi "geri al"ı). */
    async revertSequence({ created, original }) {
      const p = await project();
      const pool = await p.GetMediaPool();
      let createdTl = null;
      let originalTl = null;
      const n = Number(await p.GetTimelineCount()) || 0;
      for (let i = 1; i <= n; i++) {
        const t = await p.GetTimelineByIndex(i);
        const nm = t ? String(await t.GetName()) : '';
        if (nm === created) createdTl = t;
        else if (nm === original) originalTl = t;
      }
      if (!createdTl) throw new Error(`"${created}" zaman çizelgesi bulunamadı`);
      if (originalTl) await p.SetCurrentTimeline(originalTl);
      const ok = await pool.DeleteTimelines([createdTl]);
      if (ok === false) throw new Error('Zaman çizelgesi silinemedi');
      return { deleted: true, restored: Boolean(originalTl) };
    },

    async addCaptions({ path: file }) {
      const p = await project();
      const tl = await timeline(p);
      const pool = await p.GetMediaPool();
      const items = await pool.ImportMedia([file]);
      if (!items || !items.length) throw new Error('Altyazı dosyası içe aktarılamadı');
      if ((Number(await tl.GetTrackCount('subtitle')) || 0) === 0) await tl.AddTrack('subtitle');
      let placed = false;
      try {
        const r = await pool.AppendToTimeline([{ mediaPoolItem: items[0], recordFrame: Number(await tl.GetStartFrame()) || 0 }]);
        placed = Boolean(r && (!Array.isArray(r) || r.length));
      } catch {
        placed = false;
      }
      return { placed };
    },

    /**
     * LUT'u (.cube) ilk görüntü parçasındaki kliplerin ilk düğümüne uygular.
     * Resolve yalnızca kendi LUT klasörlerinde bulup listelediği dosyaları kabul eder; bu yüzden
     * dosya önce oraya (Makas alt klasörüne, sade bir adla) kopyalanır ve liste yenilenir.
     */
    async applyLut({ path: file, stages = [], template, fxNodes = null }) {
      const p = await project();
      const tl = await timeline(p);
      const { install, lutDir } = makeLutInstaller(log);
      const whole = install(file);
      const parts = stages.map((st) => ({ ...st, candidates: install(st.path) }));
      try {
        await p.RefreshLUTList();
      } catch {
        /* eski sürüm */
      }
      const setLut = async (target, index, candidates) => {
        if (!target?.SetLUT) return false;
        for (const c of candidates) {
          try {
            if (await target.SetLUT(index, c)) return true;
          } catch {
            /* sıradaki yol */
          }
        }
        return false;
      };
      // Şablon: kullanıcının seçtiği, yoksa eklentiyle gelen
      const ALL_STAGE_NAMES = ['WB/SAT', 'WB', 'BALANCE', 'PRIMARIES', 'EXP', 'SAT', 'CONTRAST', 'KONTRAST', 'CST TO DWG', 'CST IN', 'IDT', 'CST 1', 'CST TO REC', 'CST OUT', 'ODT', 'CST 2', 'LOOK 1', 'LOOK 2', 'LOOK'];
      const bundled = path.join(__dirname, 'sablon', 'makas-renk.drx');
      const drx = template && fs.existsSync(template) ? template : stages.length && fs.existsSync(bundled) ? bundled : null;
      const items = (await tl.GetItemListInTrack('video', 1)) ?? [];
      let applied = 0;
      let asNodes = 0;
      let why = '';
      const FX_NODE_KEYS = [
        ['halation', /^HALATION/],
        ['bloom', /^(BLOOM|GLOW)/],
        ['grain', /^(FILM GRAIN|GRAIN)/],
        ['vignette', /^VIGNETTE/],
      ];
      const fx = { enabled: new Set(), empty: new Set(), missing: new Set(), failed: new Set() };
      for (const it of items) {
        let ok = false;
        let graph = null;
        why = '';
        try {
          graph = it.GetNodeGraph ? await it.GetNodeGraph() : null;
        } catch {
          graph = null;
        }
        // Düğüm düğüm: şablon (.drx) kurulur; her adım kendi adını taşıyan düğüme (yoksa sıradaki boş düğüme) konur
        if (parts.length) {
          try {
            if (drx && graph?.ApplyGradeFromDRX) await graph.ApplyGradeFromDRX(drx, 0);
            // Düğüm bilgisi sürüme göre grafikten ya da klibin kendisinden okunur
            const call = async (name, ...args) => {
              for (const t of [graph, it]) {
                if (!t || typeof t[name] !== 'function') continue;
                try {
                  const v = await t[name](...args);
                  if (v !== undefined && v !== null && v !== false) return { v, t };
                } catch {
                  /* diğer hedef */
                }
              }
              return { v: null, t: null };
            };
            const num = await call('GetNumNodes');
            const n = Number(num.v) || 0;
            const target = num.t ?? graph ?? it;
            if (n < parts.length || (n < 2 && !drx)) {
              why = `klipte ${n} düğüm var, ${parts.length} gerekli`;
            } else {
              const labels = [];
              for (let i = 1; i <= n; i++) labels.push(String((await call('GetNodeLabel', i)).v ?? '').trim().toUpperCase());
              const used = new Set();
              const fits = (l, keys) => keys.some((k) => l === k || l.startsWith(k));
              // 1) Adı uyan düğüm
              const slot = parts.map((part) => {
                const idx = labels.findIndex((l, i) => !used.has(i) && l && fits(l, part.match ?? [part.label]));
                if (idx >= 0) used.add(idx);
                return idx;
              });
              const named = slot.some((i) => i >= 0);
              let cursor = 0;
              for (let k = 0; k < parts.length && !named; k++) {
                // Adsız ağaç: adımlar sırayla ilk düğümlere
                const idx = labels.findIndex((l, i) => i >= cursor && !used.has(i));
                if (idx >= 0) used.add(idx);
                slot[k] = idx;
                cursor = idx + 1;
              }
              log?.(`Düğümler: [${labels.join(' | ')}] → ${parts.map((x, k) => `${x.label}:${slot[k] + 1}`).join(', ')}`);
              // Karşılığı olmayan adım varsa hiçbir düğüme dokunulmaz, tek LUT'a dönülür (yarım renk kalmasın)
              const missing = parts.filter((_, k) => slot[k] < 0).map((x) => (x.match ?? [x.label])[0]);
              if (missing.length) {
                why = `şu adda düğüm yok: ${missing.join(', ')}`;
              } else {
                // Önceki uygulamadan kalan LUT'lar (kullanılmayan adım düğümleri ve ilk düğümdeki tek LUT) temizlenir
                for (let i = 0; i < n; i++) {
                  if (used.has(i) || !labels[i] || !fits(labels[i], ALL_STAGE_NAMES)) continue;
                  try {
                    if (await target.GetLUT(i + 1)) await target.SetLUT(i + 1, '');
                  } catch {
                    /* boşaltılamadı: olduğu gibi kalır */
                  }
                }
                const failed = [];
                for (let k = 0; k < parts.length; k++) if (!(await setLut(target, slot[k] + 1, parts[k].candidates))) failed.push(`${parts[k].label} (düğüm ${slot[k] + 1})`);
                if (failed.length) {
                  why = `Resolve şu düğümlere LUT koymayı reddetti: ${failed.join(', ')}`;
                  // Yarım kalmasın: konanlar geri alınır
                  for (let k = 0; k < parts.length; k++) {
                    try {
                      await target.SetLUT(slot[k] + 1, '');
                    } catch {
                      /* yoksay */
                    }
                  }
                } else {
                  ok = true;
                  asNodes++;
                }
              }
            }
          } catch (e) {
            why = e.message;
          }
          if (why) log?.(`Düğümlere ayrılamadı: ${why}`);
        }
        if (!ok) ok = await setLut(graph, 1, whole);
        if (!ok) ok = await setLut(it, 1, whole);
        if (ok) applied++;
        // Film efektleri: Resolve'da efektin kendisi (Halation, Glow, Film Grain, Vignette) düğümde durur;
        // Makas yalnızca adı uyan düğümü açar ya da kapatır. Düğüm boşsa bildirir.
        if (fxNodes && graph?.GetNumNodes) {
          try {
            const n = Number(await graph.GetNumNodes()) || 0;
            const seen = new Set();
            for (let i = 1; i <= n; i++) {
              const label = String((await graph.GetNodeLabel(i)) ?? '').trim().toUpperCase();
              const key = FX_NODE_KEYS.find(([, re]) => re.test(label))?.[0];
              if (!key || seen.has(key)) continue;
              seen.add(key);
              let tools = null;
              try {
                tools = await graph.GetToolsInNode(i);
              } catch {
                tools = null;
              }
              const has = Array.isArray(tools) ? tools.length > 0 : tools != null && Object.keys(tools).length > 0;
              let set = false;
              try {
                set = Boolean(await graph.SetNodeEnabled(i, Boolean(fxNodes[key])));
              } catch {
                set = false;
              }
              if (!fxNodes[key]) continue;
              if (!set) fx.failed.add(key);
              else if (!has) fx.empty.add(key);
              else fx.enabled.add(key);
            }
            for (const [key] of FX_NODE_KEYS) if (fxNodes[key] && !seen.has(key)) fx.missing.add(key);
          } catch (e) {
            log?.(`Efekt düğümleri ayarlanamadı: ${e.message}`);
          }
        }
      }
      log?.(`LUT: ${applied}/${items.length} klip, ${asNodes} klipte ${parts.length} düğüme ayrıldı (${whole.join(' | ')})`);
      if (!applied) {
        const where = lutDir ? 'LUT, Resolve’un LUT listesine “Makas” klasörü altında eklendi: Color sayfasında LUTs panelinden klibe sürükleyin.' : 'Color sayfasında bir düğüme sağ tıklayıp LUT > Browse ile dosyayı seçin.';
        throw new Error(`LUT kliplere otomatik uygulanamadı. ${where}`);
      }
      if (fxNodes) log?.(`Efekt düğümleri: açık [${[...fx.enabled]}] boş [${[...fx.empty]}] yok [${[...fx.missing]}] ayarlanamadı [${[...fx.failed]}]`);
      return { applied, total: items.length, asNodes, stages: parts.length, template: Boolean(drx), why, fx: { enabled: [...fx.enabled], empty: [...fx.empty], missing: [...fx.missing], failed: [...fx.failed] } };
    },

    /**
     * Klipleri eşitleme: her kaynak dosyanın kliplerine kendi LUT'unu koyar.
     * Hedef düğüm: adı MATCH / EŞİTLE ile başlayan düğüm; yoksa ilk düğüm (boşsa ya da önceki eşitleme LUT'u varsa).
     * @param luts [{ file: kaynak dosya yolu, path: LUT yolu }]
     */
    async applyLutsByFile({ luts = [] }) {
      const p = await project();
      const tl = await timeline(p);
      const { install } = makeLutInstaller(log);
      const norm = (f) => String(f ?? '').replace(/\\/g, '/').toLowerCase();
      const byFile = new Map(luts.map((l) => [norm(l.file), install(l.path)]));
      try {
        await p.RefreshLUTList();
      } catch {
        /* eski sürüm */
      }
      const items = (await tl.GetItemListInTrack('video', 1)) ?? [];
      let applied = 0;
      let skipped = 0;
      let why = '';
      for (const it of items) {
        let file = '';
        try {
          const mpi = await it.GetMediaPoolItem();
          file = mpi ? await mpi.GetClipProperty('File Path') : '';
        } catch {
          file = '';
        }
        const candidates = byFile.get(norm(file));
        if (!candidates) continue;
        let graph = null;
        try {
          graph = it.GetNodeGraph ? await it.GetNodeGraph() : null;
        } catch {
          graph = null;
        }
        const target = graph?.SetLUT ? graph : it;
        let index = 1;
        try {
          const n = Number(await (graph?.GetNumNodes ? graph.GetNumNodes() : it.GetNumNodes())) || 1;
          let named = 0;
          for (let i = 1; i <= n && !named; i++) {
            const l = String((await (graph?.GetNodeLabel ? graph.GetNodeLabel(i) : it.GetNodeLabel(i))) ?? '').trim().toUpperCase();
            if (/^(MATCH|SHOT MATCH|EŞİTLE|ESITLE)/.test(l)) named = i;
          }
          if (named) index = named;
          else {
            const cur = String((await target.GetLUT(1)) ?? '');
            if (cur && !/Esitle/i.test(cur)) {
              skipped++;
              why = 'ilk düğümde başka bir LUT var; “MATCH” adlı boş bir düğüm ekleyin';
              continue;
            }
          }
        } catch {
          index = 1;
        }
        let ok = false;
        for (const c of candidates) {
          try {
            if (await target.SetLUT(index, c)) {
              ok = true;
              break;
            }
          } catch {
            /* sıradaki yol */
          }
        }
        if (ok) applied++;
        else {
          skipped++;
          why = why || 'Resolve LUT koymayı reddetti';
        }
      }
      log?.(`Klip eşitleme: ${applied} klibe uygulandı, ${skipped} atlandı${why ? ` (${why})` : ''}`);
      if (!applied) throw new Error(`Eşitleme LUT'ları uygulanamadı${why ? `: ${why}` : ''}.`);
      return { applied, skipped, why };
    },

    /** Sürükleme başlarken: bu dosyadan zaman çizelgesinde zaten duran öğeler (sonradan bırakılan ayırt edilsin). */
    async beginDrop({ file }) {
      const p = await project();
      const tl = await timeline(p);
      return { known: (await itemsOfFile(tl, file)).map(dropKey) };
    },

    /**
     * Bırakılan geçişi bulur ve en yakın kesime oturtur. Kullanıcı geçişi kabaca bir kesimin yakınına bırakır;
     * Resolve'da öğe taşıma işlevi olmadığından bırakılan öğe kaldırılır ve aynı geçiş, "Ekle" düğmesinin
     * kullandığı yolla tam kesime (görüntü üst parçaya, ses boş bir ses parçasına) yeniden konur.
     * @returns {{state:'waiting'}|{state:'kept',reason:string,time:number}|{state:'placed',time:number,track:number}}
     */
    async settleDrop({ file, videoPath, audioPath, mid = 0, known = [], reach = 2.5 }) {
      const p = await project();
      const tl = await timeline(p);
      const t = await timing(tl, p);
      const fresh = (await itemsOfFile(tl, file)).filter((m) => !known.includes(dropKey(m)));
      const video = fresh.find((m) => m.kind === 'video');
      if (!video) return { state: 'waiting' };
      const dropped = (video.start - t.start) / t.fps;
      // Kesimler: ilk dört video parçasındaki, Makas geçişi olmayan kliplerin başlangıçları
      let cut = null;
      const center = dropped + Number(mid);
      const count = Math.min(4, Number(await tl.GetTrackCount('video')) || 0);
      for (let i = 1; i <= count; i++) {
        for (const it of ((await tl.GetItemListInTrack('video', i)) ?? []).slice(0, 3000)) {
          if (isMakasClip(await it.GetName())) continue;
          const s = (Number(await it.GetStart()) - t.start) / t.fps;
          if (s > 0.05 && (cut == null || Math.abs(s - center) < Math.abs(cut - center))) cut = s;
        }
      }
      if (cut == null || Math.abs(cut - center) > Number(reach)) return { state: 'kept', reason: 'no-cut', time: round(dropped) };
      if (typeof tl.DeleteClips !== 'function') return { state: 'kept', reason: 'no-delete', time: round(dropped) };
      let deleted = false;
      try {
        deleted = Boolean(await tl.DeleteClips(fresh.map((m) => m.item), false));
      } catch {
        deleted = false;
      }
      if (!deleted) return { state: 'kept', reason: 'no-delete', time: round(dropped) };
      const at = Math.max(0, cut - Number(mid));
      try {
        const v = await host.placeOverlay({ path: videoPath || file, at });
        if (audioPath) await host.insertClip({ path: audioPath, kind: 'audio', at });
        log?.(`Bırakılan geçiş kesime oturtuldu: ${round(dropped)} sn → ${round(cut)} sn`);
        return { state: 'placed', time: round(cut), track: v.track, ...(v.alpha === false ? { alpha: false } : {}) };
      } catch (e) {
        // Yeniden yerleştirilemediyse bırakılan öğeyi eski yerine geri koymayı dene (kullanıcı geçişini kaybetmesin)
        try {
          const item = await importMedia(p, file);
          const frames = await clipFrames(item, t.fps);
          await append(p, { mediaPoolItem: item, startFrame: 0, endFrame: frames - 1, trackIndex: video.track, recordFrame: video.start, mediaType: 1 });
        } catch {
          /* geri konamadı */
        }
        throw e;
      }
    },

    /** Kesim yerleri: ilk dört video parçasındaki klip başlangıçları (sn); getSequence'teki klip sınırına takılmaz. */
    async getCuts() {
      const p = await project();
      const tl = await timeline(p);
      const t = await timing(tl, p);
      const count = Math.min(4, Number(await tl.GetTrackCount('video')) || 0);
      const tracks = [];
      for (let i = 1; i <= count; i++) {
        const items = (await tl.GetItemListInTrack('video', i)) ?? [];
        const starts = [];
        for (const it of items.slice(0, 3000)) starts.push(round((Number(await it.GetStart()) - t.start) / t.fps));
        tracks.push(starts);
      }
      return { tracks };
    },

    /** @param at sekansın başından saniye (efektler belirli bir ana eklenir); varsayılan 0 */
    async placeOverlay({ path: file, at = 0 }) {
      const p = await project();
      const tl = await timeline(p);
      const t = await timing(tl, p);
      const item = await importMedia(p, file);
      // ProRes 4444 katman videosu düz (premultiplied olmayan) alfa taşır; kip açılır ve doğrulanır
      const alpha = await enableAlpha(item);
      const frames = await clipFrames(item, t.fps);
      const rec = t.start + Math.max(0, Math.round((Number(at) || 0) * t.fps));
      const track = await freeTrack(tl, 'video', rec, rec + frames, 2);
      await append(p, { mediaPoolItem: item, startFrame: 0, endFrame: frames - 1, trackIndex: track, recordFrame: rec, mediaType: 1 });
      return { track, time: (rec - t.start) / t.fps, ...(alpha === null ? { alpha: false } : {}) };
    },

    /** @param at sekansın başından saniye; verilmezse oynatma kafası */
    async insertClip({ path: file, kind, at: when = null }) {
      const p = await project();
      const tl = await timeline(p);
      const t = await timing(tl, p);
      const item = await importMedia(p, file);
      const frames = await clipFrames(item, t.fps);
      const sec = when !== null && when !== undefined && Number(when) >= 0 ? Number(when) : await playheadSeconds(tl, t);
      const at = t.start + Math.round(sec * t.fps);
      const audio = kind === 'audio';
      const track = await freeTrack(tl, audio ? 'audio' : 'video', at, at + frames, audio ? 1 : 2);
      await append(p, { mediaPoolItem: item, startFrame: 0, endFrame: frames - 1, trackIndex: track, recordFrame: at, mediaType: audio ? 2 : 1 });
      return { track, time: round((at - t.start) / t.fps) };
    },

    async setPlayhead({ seconds }) {
      const p = await project();
      const tl = await timeline(p);
      const t = await timing(tl, p);
      const ok = await tl.SetCurrentTimecode(framesToTimecode(t.start + Number(seconds) * t.fps, t.fps, t.df));
      return { ok: ok !== false };
    },

    pickFiles: (opts) => (ui.pickFiles ? ui.pickFiles(opts ?? {}) : []),
    pickFolder: (opts) => (ui.pickFolder ? ui.pickFolder(opts ?? {}) : null),
    openUrl: ({ url }) => ui.openUrl?.(url),
    setPinned: ({ pinned }) => ui.setPinned?.(Boolean(pinned)),
    quit: () => ui.quit?.(),
  };
  return host;
}

module.exports = { createResolveHost, timecodeToFrames, framesToTimecode };
