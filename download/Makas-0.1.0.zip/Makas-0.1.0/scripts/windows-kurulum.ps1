﻿# Makas — Windows kurulumu
#
# Makas'ı Premiere Pro ve DaVinci Resolve'un İÇİNE eklenti olarak kurar:
#   Premiere Pro:     Pencere (Window) > Uzantılar (Eski) / Extensions (Legacy) > Makas
#   DaVinci Resolve:  Çalışma Alanı (Workspace) > Workflow Integrations > Makas
# ffmpeg ve whisper.cpp, %APPDATA%\Makas\tools\bin klasörüne indirilir.
#
# Makas-Windows-Kurulum.bat dosyasına çift tıklayarak çalıştırın (yönetici izni ister).

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Adim($m) { Write-Host "`n> $m" -ForegroundColor Magenta }
function Tamam($m) { Write-Host "  + $m" -ForegroundColor Green }
function Uyari($m) { Write-Host "  ! $m" -ForegroundColor Yellow }
function Hata($m) { Write-Host "`nX $m" -ForegroundColor Red; exit 1 }

$Root = Split-Path -Parent $PSScriptRoot
$PremiereSrc = Join-Path $Root 'dist\premiere\com.makas.panel'
$ResolveSrc = Join-Path $Root 'dist\resolve\Makas'
$Kaynak = (Test-Path (Join-Path $Root 'package.json')) -and (Test-Path (Join-Path $Root 'ui\src'))
$Data = Join-Path $env:APPDATA 'Makas'
$ToolsBin = Join-Path $Data 'tools\bin'
$Tmp = Join-Path $env:TEMP 'makas-kurulum'

Write-Host "`n  Makas kurulumu" -ForegroundColor White
Write-Host "  Sessizlik ve iii kesimi - Turkce altyazi - SFX Lab - MultiCam`n"

New-Item -ItemType Directory -Force -Path $ToolsBin, $Tmp | Out-Null

function Indir($url, $hedef) {
  Write-Host "  indiriliyor: $url"
  Invoke-WebRequest -Uri $url -OutFile $hedef -UseBasicParsing -Headers @{ 'User-Agent' = 'Makas-Kurulum' }
}

# Bir zip içindeki, verilen programın bulunduğu klasördeki tüm dosyaları tools\bin'e kopyalar
function ZiptenKur($zip, $program) {
  $acik = Join-Path $Tmp ([IO.Path]::GetFileNameWithoutExtension($zip))
  if (Test-Path $acik) { Remove-Item -Recurse -Force $acik }
  Expand-Archive -Path $zip -DestinationPath $acik -Force
  $exe = Get-ChildItem -Path $acik -Recurse -Filter $program | Select-Object -First 1
  if (-not $exe) { Hata "$program arşivde bulunamadı" }
  Copy-Item -Path (Join-Path $exe.DirectoryName '*') -Destination $ToolsBin -Recurse -Force
}

# 1) ffmpeg
Adim 'ffmpeg denetleniyor'
if ((Test-Path (Join-Path $ToolsBin 'ffmpeg.exe')) -or (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
  Tamam 'ffmpeg hazır'
} else {
  $zip = Join-Path $Tmp 'ffmpeg.zip'
  Indir 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' $zip
  ZiptenKur $zip 'ffmpeg.exe'
  Tamam "ffmpeg kuruldu: $ToolsBin"
}

# 2) whisper.cpp (konuşma tanıma)
Adim 'whisper.cpp denetleniyor'
if (Test-Path (Join-Path $ToolsBin 'whisper-cli.exe')) {
  Tamam 'whisper.cpp hazır'
} else {
  $rel = Invoke-RestMethod -Uri 'https://api.github.com/repos/ggml-org/whisper.cpp/releases/latest' -Headers @{ 'User-Agent' = 'Makas-Kurulum' }
  $asset = $rel.assets | Where-Object { $_.name -eq 'whisper-bin-x64.zip' } | Select-Object -First 1
  if (-not $asset) { Hata 'whisper.cpp Windows paketi bulunamadı (whisper-bin-x64.zip)' }
  $zip = Join-Path $Tmp 'whisper.zip'
  Indir $asset.browser_download_url $zip
  ZiptenKur $zip 'whisper-cli.exe'
  Tamam "whisper.cpp $($rel.tag_name) kuruldu"
}

# 3) Kaynak koddan derleme
if ($Kaynak) {
  Adim 'Makas derleniyor'
  if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
      winget install --id OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
      $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
    }
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Hata 'Node.js bulunamadı. nodejs.org adresinden LTS sürümünü kurup yeniden deneyin.' }
  }
  Push-Location $Root
  try {
    if (-not (Test-Path (Join-Path $Root 'node_modules\esbuild'))) {
      npm install --no-audit --no-fund
      if ($LASTEXITCODE -ne 0) { Hata 'npm install başarısız' }
    }
    node scripts/build.mjs
    if ($LASTEXITCODE -ne 0) { Hata 'Derleme başarısız' }
  } finally { Pop-Location }
  Tamam 'Derlendi'
}
if (-not (Test-Path $PremiereSrc)) { Hata "Premiere eklentisi bulunamadı: $PremiereSrc" }

# 4) Premiere Pro (CEP)
Adim 'Premiere Pro eklentisi kuruluyor'
$Cep = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.makas.panel'
if (Test-Path $Cep) { Remove-Item -Recurse -Force $Cep }
New-Item -ItemType Directory -Force -Path (Split-Path $Cep) | Out-Null
Copy-Item -Path $PremiereSrc -Destination $Cep -Recurse -Force
# İmzasız eklentilerin yüklenmesine izin ver (Premiere 2022–2026 → CSXS 11/12)
foreach ($v in 9..13) {
  $key = "HKCU:\Software\Adobe\CSXS.$v"
  New-Item -Path $key -Force | Out-Null
  New-ItemProperty -Path $key -Name 'PlayerDebugMode' -Value '1' -PropertyType String -Force | Out-Null
}
Tamam "Kuruldu: $Cep"
Tamam "Premiere'i yeniden başlatın: Pencere > Uzantılar (Eski) > Makas"

# 5) DaVinci Resolve (Workflow Integration)
$ResolveExe = Join-Path $env:ProgramFiles 'Blackmagic Design\DaVinci Resolve\Resolve.exe'
if ((Test-Path $ResolveExe) -and (Test-Path $ResolveSrc)) {
  Adim 'DaVinci Resolve eklentisi kuruluyor'
  $Bmd = Join-Path $env:ProgramData 'Blackmagic Design\DaVinci Resolve\Support'
  $WiDir = Join-Path $Bmd 'Workflow Integration Plugins\Makas'
  if (Test-Path $WiDir) { Remove-Item -Recurse -Force $WiDir }
  New-Item -ItemType Directory -Force -Path (Split-Path $WiDir) | Out-Null
  Copy-Item -Path $ResolveSrc -Destination $WiDir -Recurse -Force
  $node = Get-ChildItem -Path (Join-Path $Bmd 'Developer'), (Split-Path $ResolveExe) -Recurse -Filter 'WorkflowIntegration.node' -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($node) {
    Copy-Item -Path $node.FullName -Destination (Join-Path $WiDir 'WorkflowIntegration.node') -Force
  } else {
    Uyari "WorkflowIntegration.node bulunamadı. Resolve > Yardım > Dokümantasyon > Geliştirici klasöründeki"
    Uyari "Workflow Integrations\Examples içindeki dosyayı şuraya kopyalayın: $WiDir"
  }
  # Kullanıcılar grubuna değiştirme izni: Makas kendini uygulama içinden güncelleyebilsin
  & icacls $WiDir /grant '*S-1-5-32-545:(OI)(CI)M' /T /Q | Out-Null
  Tamam "Kuruldu: $WiDir"
  Tamam "Resolve'u yeniden başlatın: Çalışma Alanı > Workflow Integrations > Makas"
  Uyari 'Workflow Integration eklentileri DaVinci Resolve Studio gerektirir.'
} else {
  Uyari 'DaVinci Resolve bulunamadı; Resolve eklentisi atlandı.'
}

Adim 'Kurulum tamamlandı'
Write-Host "  İlk açılışta Makas > Ayarlar'dan konuşma modelini (Turbo, 547 MB) indirin."
Write-Host "  Ardından Ana sayfa > 'Kurguyu başlat' ile ham videonuzu tek tıkla kurgulayın.`n"
