#!/bin/bash
# Makas — macOS kurulumu
#
# Makas'ı Premiere Pro ve DaVinci Resolve'un İÇİNE eklenti olarak kurar:
#   Premiere Pro:     Pencere (Window) > Uzantılar (Eski) / Extensions (Legacy) > Makas
#   DaVinci Resolve:  Çalışma Alanı (Workspace) > Workflow Integrations > Makas
#
# Gerekenleri de kurar: ffmpeg (ses/görüntü işleme) ve whisper.cpp (konuşma tanıma).
# Kaynak koddan çalıştırılıyorsa Node.js ile derler; hazır paketten çalıştırılıyorsa derlemez.
#
# Çalıştırma: Terminal'e "bash " yazıp (sonunda boşluk) bu dosyayı pencereye sürükleyin ve
# Enter'a basın. (İmzasız olduğu için çift tıklamada macOS "Açılmadı" uyarısı verebilir.)
# Güncellemek için yeniden çalıştırın.

cd "$(dirname "$0")" || exit 1
ROOT="$(pwd)"

adim() { printf "\n\033[1;35m▶ %s\033[0m\n" "$1"; }
tamam() { printf "  \033[1;32m✔\033[0m %s\n" "$1"; }
uyari() { printf "  \033[1;33m!\033[0m %s\n" "$1"; }
hata() {
  printf "\n\033[1;31m✖ %s\033[0m\n" "$1"
  printf "Bu pencereyi kapatabilirsiniz.\n"
  exit 1
}

[ "$(uname)" = "Darwin" ] || hata "Bu kurulum yalnızca macOS içindir."

printf "\n\033[1m  ✂  Makas kurulumu\033[0m\n"
printf "  Sessizlik ve ııı kesimi · Türkçe altyazı · SFX Lab · MultiCam\n"

# Hazır paket (dist/ içinde derlenmiş eklentiler) mi, kaynak kod mu?
PREMIERE_SRC="$ROOT/dist/premiere/com.makas.panel"
RESOLVE_SRC="$ROOT/dist/resolve/Makas"
KAYNAK=0
[ -f "$ROOT/package.json" ] && [ -d "$ROOT/ui/src" ] && KAYNAK=1

brew_path() {
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do
    if [ -x "$b" ]; then
      eval "$("$b" shellenv)"
      return 0
    fi
  done
  return 1
}

# 1) Homebrew
if ! brew_path; then
  adim "Homebrew kuruluyor (Mac için program yöneticisi)"
  printf "  Mac şifreniz sorulacak; yazarken ekranda görünmez, bu normaldir.\n"
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || hata "Homebrew kurulamadı."
  brew_path || hata "Homebrew kuruldu ama bulunamadı. Terminal'i kapatıp bu dosyayı yeniden çalıştırın."
fi

# 2) ffmpeg, whisper.cpp (ve kaynak koddan kurulumda Node.js)
adim "Gerekli programlar denetleniyor"
eksik=()
# Homebrew'un "ffmpeg" paketi 8. sürümden beri altyazı çizemiyor (libass yok); animasyonlu
# altyazı için tam sürüm "ffmpeg-full" gerekir. Makas onu kendi klasöründen bulur.
FFMPEG_FULL="$(brew --prefix)/opt/ffmpeg-full/bin/ffmpeg"
altyazi_destekli() { "$1" -hide_banner -filters 2>/dev/null | grep -qE '^ *[TSC.]+ +ass '; }
if [ -x "$FFMPEG_FULL" ]; then
  FFMPEG_BIN="$FFMPEG_FULL"
elif command -v ffmpeg >/dev/null 2>&1 && altyazi_destekli "$(command -v ffmpeg)"; then
  FFMPEG_BIN="$(command -v ffmpeg)"
else
  eksik+=(ffmpeg-full)
  FFMPEG_BIN="$FFMPEG_FULL"
fi
if ! command -v whisper-cli >/dev/null 2>&1 && ! command -v whisper-cpp >/dev/null 2>&1; then
  eksik+=(whisper-cpp)
fi
if [ "$KAYNAK" = 1 ]; then
  command -v node >/dev/null 2>&1 || eksik+=(node)
fi
if [ ${#eksik[@]} -gt 0 ]; then
  printf "  Kuruluyor: %s (ilk seferde 5-15 dakika sürebilir)\n" "${eksik[*]}"
  brew install "${eksik[@]}" || hata "Kurulum başarısız: ${eksik[*]}"
fi
altyazi_destekli "$FFMPEG_BIN" || uyari "ffmpeg altyazı çizemiyor; animasyonlu altyazı yerine altyazı izi kullanılacak."
tamam "ffmpeg: $FFMPEG_BIN"
tamam "whisper.cpp: $(command -v whisper-cli || command -v whisper-cpp)"

# 3) Kaynak koddan derleme
if [ "$KAYNAK" = 1 ]; then
  if ! node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 20 ? 0 : 1)'; then
    adim "Node.js güncelleniyor"
    brew upgrade node || hata "Node.js güncellenemedi."
  fi
  adim "Makas derleniyor"
  if [ ! -d "$ROOT/node_modules/esbuild" ] || [ "$ROOT/package.json" -nt "$ROOT/node_modules/.package-lock.json" ]; then
    npm install --no-audit --no-fund || hata "npm install başarısız."
  fi
  if ! cikti="$(node scripts/build.mjs 2>&1)"; then
    printf "%s\n" "$cikti"
    hata "Derleme başarısız."
  fi
  tamam "Derlendi"
fi
[ -d "$PREMIERE_SRC" ] || hata "Premiere eklentisi bulunamadı: $PREMIERE_SRC"

# 4) Premiere Pro eklentisi (CEP)
adim "Premiere Pro eklentisi kuruluyor"
CEP_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions"
mkdir -p "$CEP_DIR" || hata "Klasör oluşturulamadı: $CEP_DIR"
rm -rf "$CEP_DIR/com.makas.panel"
cp -R "$PREMIERE_SRC" "$CEP_DIR/com.makas.panel" || hata "Premiere eklentisi kopyalanamadı."
# İmzasız eklentilerin yüklenmesine izin ver (Premiere 2022–2026 → CSXS 11/12)
for v in 9 10 11 12 13; do
  defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1 >/dev/null 2>&1
done
tamam "Kuruldu: $CEP_DIR/com.makas.panel"
if ls -d /Applications/Adobe\ Premiere* >/dev/null 2>&1; then
  tamam "Premiere'i yeniden başlatın → Pencere > Uzantılar (Eski) > Makas"
else
  uyari "Premiere Pro bulunamadı; kurulduğunda eklenti hazır olacak."
fi

# 5) DaVinci Resolve eklentisi (Workflow Integration)
RESOLVE_APP=""
for a in "/Applications/DaVinci Resolve/DaVinci Resolve.app" "/Applications/DaVinci Resolve Studio/DaVinci Resolve.app"; do
  [ -d "$a" ] && RESOLVE_APP="$a"
done
if [ -n "$RESOLVE_APP" ] && [ -d "$RESOLVE_SRC" ]; then
  adim "DaVinci Resolve eklentisi kuruluyor"
  BMD="/Library/Application Support/Blackmagic Design/DaVinci Resolve"
  WI_DIR="$BMD/Workflow Integration Plugins"
  # Resolve'un bağlantı modülü kendi örnek eklentisiyle gelir
  WI_NODE="$(find "$BMD/Developer" "$RESOLVE_APP/Contents" -name WorkflowIntegration.node 2>/dev/null | head -n 1)"
  if [ -z "$WI_NODE" ]; then
    uyari "WorkflowIntegration.node bulunamadı. Resolve'da Yardım > Dokümantasyon > Geliştirici klasörünü açıp"
    uyari "Workflow Integrations/Examples içindeki dosyayı şuraya kopyalayın: $WI_DIR/Makas/"
  fi
  printf "  Sistem klasörüne yazmak için Mac şifreniz sorulabilir.\n"
  sudo mkdir -p "$WI_DIR" &&
    sudo rm -rf "$WI_DIR/Makas" &&
    sudo cp -R "$RESOLVE_SRC" "$WI_DIR/Makas" || hata "Resolve eklentisi kopyalanamadı."
  [ -n "$WI_NODE" ] && sudo cp "$WI_NODE" "$WI_DIR/Makas/WorkflowIntegration.node"
  # Klasör kullanıcıya ait olsun: Makas kendini uygulama içinden güncelleyebilsin
  sudo chown -R "$(id -un)" "$WI_DIR/Makas"
  sudo chmod -R u+rwX,go+rX "$WI_DIR/Makas"
  tamam "Kuruldu: $WI_DIR/Makas"
  tamam "Resolve'u yeniden başlatın → Çalışma Alanı > Workflow Integrations > Makas"
  uyari "Workflow Integration eklentileri DaVinci Resolve Studio gerektirir."
  # Eski Python köprüsü artık gerekmiyor
  rm -f "$HOME/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility/Eklenti_Kopru.py" 2>/dev/null
else
  uyari "DaVinci Resolve bulunamadı; Resolve eklentisi atlandı."
fi

adim "Kurulum tamamlandı ✨"
printf "  İlk açılışta Makas > Ayarlar'dan konuşma modelini (Turbo, 547 MB) indirin.\n"
printf "  Ardından Ana sayfa > 'Kurguyu başlat' ile ham videonuzu tek tıkla kurgulayın.\n\n"
