@echo off
rem Makas — Windows kurulumu. Çift tıklayın; Resolve klasörüne yazmak için yönetici izni istenir.
chcp 65001 >nul
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\windows-kurulum.ps1"
echo.
pause
